<?php
// session_start();
define("TITLE", "Trend Report");
define("PAGE", "Trend Report");
include 'connection.php';
include 'header.php';

?>
<style>
  .mm {
    margin-top: 150px;
  }

  .mn {
    margin-top: -40px;
  }
</style>

<div class="body-section">
  <div class="container ">
    <div class="card mm">
      <div class="card-header border-0">
        <h3 class="card-title">Trend Report</h3>
        <!-- Button trigger modal -->

        <div class="container mt-1">

          <form action="" method="POST" class="d-print-none">
          <div class="row">
              <div class="col-6">
                <label for="form">From</label>
                <input type="date" class="form-control" id="startdate" name="startdate">

              </div>
              <div class="col-6">
                <label for="to">To</label>
                <input type="date" class="form-control" id="enddate" name="enddate">

              </div>
            </div>
            <div class="form-group">
              <input type="submit" class="btn btn-primary mt-2" name="searchsubmit" value="Search">
            </div>

          </form>
          <?php
          if (isset($_REQUEST['searchsubmit'])) {

            $startdate = $_REQUEST['startdate'];
            $enddate = $_REQUEST['enddate'];
          ?>
            <table>
              <tr>
                <td><a href="trendbill.php" class="btn btn-danger mt-2">Print </a></td>
              </tr>
            </table>

            <?php
            $query_product = mysqli_query($conn, "select * from product");
            while ($row_product = mysqli_fetch_assoc($query_product)) {
              $product = $row_product['product_name'];

              $sql = "SELECT quantity FROM sale_items WHERE item_name='$product' AND date BETWEEN '$startdate' AND '$enddate' and `status` != 'returned'";
              $result = $conn->query($sql);

              if ($result->num_rows > 0) {

                $total = 0;
                while ($row = mysqli_fetch_assoc($result)) {

                  $quantity = $row['quantity'];
                  $total = $total + $quantity;
                  $_SESSION['product'] = $product;
                  $_SESSION['total'] = $total;
                }
            ?>

                <table class="table mt-3">
                  <tr>
                    <td>
                      <h5><?php echo $product; ?></h5>
                    </td>
                    <td>
                      <h5><?php echo $total; ?></h5>
                    </td>
                  </tr>
                  </tbody>

                </table>
          <?php

              }
            }
          } else {
            echo "<div class='alert alert-warning col-sm-6 ml-5 mt-2' role='alert'> No Records Found ! </div>";
          }

          ?>


          <hr>
          <div class="card-body table-responsive">
            <table id="table" class="table table-bordered pt-2">

            </table>
          </div>
        </div>




      </div>
      <!-- flex-item -->
    </div>
    <!-- /flex-container -->
  </div>
</div>
<!-- flex-item -->
</div>
<!-- /flex-container -->
</div>
</div>

</div>

</div>




</div>







<?php
include 'footer.php';

?>