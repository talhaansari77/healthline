<?php

include_once("header.php");
include_once("connection.php");

$username = $_GET['username'];
$result = $conn->query("SELECT quantity ,sale_product_details.billmaker,sale_items.date as solddate, product.* FROM `sale_product_details`, product, sale_items WHERE sale_items.bill_id=sale_product_details.bill_id AND product.product_name=sale_items.item_name AND sale_product_details.billmaker='$username'");
$rowno = 0;
$totalqty = 0;
$total = 0;

?>
<div class="body-section">
    <div class="container mt-5">

        <div class="container">
            <h2>Name : <?php echo $username ?>
                &nbsp;

            </h2>



            <!-- here the table -->
            <table class='table table-striped'>
                <thead>
                    <tr>

                        <th>#</th>
                        <th>Product Name</th>
                        <th>Quantity</th>
                        <th>Commission</th>
                        <th>Date</th>
                        <!-- <th>Action</th> -->
                    </tr>
                </thead>
                <tbody>


                    <?php
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            $rowno += 1;
                            $totalqty += intval($row['quantity']);

                    ?>
                            <tr>
                                <td><?php echo $rowno ?></td>
                                <td><?php echo $row['product_name'] ?></td>
                                <td><?php echo intval($row['quantity']) ?></td>


                                <td>
                                    <?php echo $row['comission'] ?>
                                    <i class="text-danger">
                                        (
                                        <?php
                                        if (strpos($row["comission"], "%")) {
                                            // echo $row["quantity"] ; 
                                            $total += $row["quantity"] * ($row["selling_price"] / 100 * explode('%', $row["comission"])[0]);
                                            echo $row["quantity"] * ($row["selling_price"] / 100 * explode('%', $row["comission"])[0]);
                                        } else if (strpos($row["comission"], "Rs")) {
                                            $total += $row["quantity"] * explode('Rs', $row["comission"])[0];
                                            echo $row["quantity"] * explode('Rs', $row["comission"])[0];

                                            // echo $userCommission;
                                        } ?>
                                        )
                                    </i>
                                </td>




                                <td><?php echo $row['solddate'] ?></td>
                            </tr>

                    <?php

                        }
                    }
                    ?>

                    <tr class="bg-secondary fw-bold text-light">
                        <td>--------</td>
                        <td>--------</td>
                        <td><?php echo $totalqty ?></td>
                        <td><?php echo $total ?> .Rs</td>
                        <td>--------</td>
                    </tr>
                </tbody>
            </table>
            <div>
                <a href="user.php" class="btn btn-primary">Back</a>
            </div>
        </div>
    </div>
</div>



<?php
include_once("footer.php");
?>