<?php
define("TITLE", "Products");
define("PAGE", "Products");
include 'connection.php';
include 'header.php';
$id = $_GET['idv'];

$query = mysqli_query($conn, "Select * from supplier where id='$id'");
$row = mysqli_fetch_assoc($query);
$name = $row['name'];
$address = $row['address'];
$bname = $row['business_name'];
$mobile = $row['mobile'];
?>


<div class="body-section">
  <div class="container">
    <div class="card">
      <div class="card-header border-0">
        <h3 class="card-title">Supplier View</h3>
        <hr>
        <div class="container mt-1">
          <div class="card">
            <div class="row m-3">
              <div class="col-lg-7">
                <h6><i class="far fa-user"></i> Supplier</h6>
                <span class=" ms-4"><?php echo $name; ?></span>
                <h6 class="mt-2"><i class="fas fa-map-marker-alt"></i> Address</h6>
                <span class=" ms-4" class=" ms-4"><?php echo $address; ?></span>
                <h6 class="mt-2"><i class="fas fa-briefcase"></i> Business Name</h6>
                <span class=" ms-4"><?php echo $bname; ?></span>
                <h6 class="mt-2"><i class="fas fa-mobile"></i> Mobile</h6>
                <span class=" ms-4"><?php echo $mobile; ?></span>
              </div>
              <div class="col-lg-5">
                <h6><i class="fas fa-info"></i> Tax Number</h6>
                <span class=" ms-4">1818152</span>
              </div>
            </div>
          </div>
          <div class="container mt-5">

            <div class="row">
              <div class="col-lg-12">
                <ul class="nav nav-tabs" id="myTab" role="tablist">
                  <li class="nav-item" role="presentation">
                    <button class="nav-link active fw-bold" style="color: #00A54F" id="home-tab" data-bs-toggle="tab" data-bs-target="#home" type="button" role="tab" aria-controls="home" aria-selected="true"><i class="fas fa-scroll"></i> Ledger</button>
                  </li>
                  <li class="nav-item" role="presentation">
                    <button class="nav-link fw-bold" style="color: #00A54F" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile" type="button" role="tab" aria-controls="profile" aria-selected="false"><i class="fas fa-store"></i> Purchases</button>
                  </li>
                  <li class="nav-item" role="presentation">
                    <button class="nav-link fw-bold" style="color: #00A54F" id="contact-tab" data-bs-toggle="tab" data-bs-target="#contact" type="button" role="tab" aria-controls="contact" aria-selected="false"><i class="fas fa-hourglass-half"></i> Stock Report</button>
                  </li>
                  <li class="nav-item" role="presentation">
                    <button class="nav-link fw-bold" style="color: #00A54F" id="doc-tab" data-bs-toggle="tab" data-bs-target="#doc" type="button" role="tab" aria-controls="contact" aria-selected="false"> <i class="fas fa-paperclip"></i> Documents & Notes</button>
                  </li>
                  <li class="nav-item" role="presentation">
                    <button class="nav-link fw-bold" style="color: #00A54F" id="pay-tab" data-bs-toggle="tab" data-bs-target="#payment" type="button" role="tab" aria-controls="contact" aria-selected="false"><i class="fas fa-money-bill-alt"></i> Payment</button>
                  </li>
                </ul>
                <div class="tab-content" id="myTabContent">
                  <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                    <div class="container">
                      <div class="row">
                        <div class="col-lg-4">
                          <table class="table table-responsive table-stripped mt-5">
                            <thead style="background-color: #00A54F; color:white;">
                              <th>To</th>
                            </thead>
                            <tbody>
                              <tr class="mt-5">
                                <td><?php echo $name ?> <br><br>

                                  Mobile: <?php echo $mobile ?></td>
                              </tr>
                            </tbody>

                          </table>
                        </div>
                        <div class="col-lg-2">

                        </div>
                        <div class="col-lg-6">
                          <div class="text-center mt-5">
                            <h4 style="background-color:#00A54F; color: white; padding: 7px;">Account Summary</h4>

                          </div>
                          <?php

                          $sqlG = "SELECT SUM(grand_total) as grand_total, SUM(paid) as paid, SUM(remaining) as remaining FROM products_detail WHERE supplier= '$name'";
                          $resultG = $conn->query($sqlG);
                          if ($resultG->num_rows > 0) {
                            $supplier_total = $resultG->fetch_assoc();
                          }

                          ?>
                          <table class="table table-responsive table-condensed ">
                            <!-- <tr>
                          <td>Opening Balance</td>
                          <td class="text-end">₨ 0.00</td>
                      </tr> -->
                            <tr>
                              <td>Total Purchase</td>
                              <td class="text-end">₨ <?php echo $supplier_total['grand_total'] ?></td>
                            </tr>
                            <tr>
                              <td>Total paid</td>
                              <td class="text-end">₨ <?php echo $supplier_total['paid'] ?></td>
                            </tr>
                            <!-- <tr>
                          <td>Advance Balance</td>
                          <td class="text-end">₨ 0.00</td>
                      </tr> -->
                            <tr>
                              <td><b>Balance due</b></td>
                              <td class="text-end">₨ <?php echo $supplier_total['remaining'] ?></td>
                            </tr>


                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                    <div class="container">
                      <div class="row mt-5">
                        <div class="col-lg-9">
                          <div class="input-group ">
                            <div class="form-outline">
                              <input type="search" id="form1" class="form-control" placeholder="Search">

                            </div>
                            <button type="button" class="btn" id="button-addon2">
                              <i class="fas fa-search"></i>
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>




                    <div class="container">
                      <div class="row mt-5">
                        <div class="col-lg-12">
                          <table id="example" class="table table-striped table-bordered  mx-10">

                            <thead>
                              <tr>
                                <th>ID</th>
                                <th>Date</th>
                                <th>Reference No.</th>
                                <!-- <th>Location</th> -->
                                <th>Supplier</th>
                                <!-- <th>Purchase Status</th> -->
                                <th>Payment Method </th>
                                <th>Grand Total</th>
                                <th>Payment Due </th>
                                <!-- <th>Added By</th> -->
                                <!-- <th>Operations</th> -->
                              </tr>
                            </thead>
                            <tbody>
                              <?php
                              // $result1 = $conn->query("SELECT * FROM products_detail WHERE supplier = '$name' and `status`!='returned' group by `supplier`");

                              $sqlG = "SELECT * FROM products_detail WHERE supplier = '$name'";
                              $resultG = $conn->query($sqlG);
                              while ($row = $resultG->fetch_assoc()) {
                              ?>


                                <tr>
                                  <td><?php echo $row['id'] ?></td>
                                  <td><?php echo $row['date'] ?></td>
                                  <td><?php echo $row['bill_id'] ?></td>
                                  <!-- <td>---------------</td> -->
                                  <td><?php echo $row['supplier'] ?></td>
                                  <!-- <td>Recieved</td> -->
                                  <td>
                                    <?php if ($row['paid'] > 0) {
                                      echo "Paid";
                                    } else {
                                      echo "Unpaid";
                                    } ?>
                                  </td>
                                  <td>RS <?php echo $row['grand_total'] ?></td>
                                  <td>RS <?php echo $row['remaining'] ?></td>
                                  <!-- <td>RS 0.00</td> -->


                                  <td class="text-center">

                                    <div class="action">
                                      <button class="btn btn-success btn-sm dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                        Action
                                      </button>
                                      <ul class="dropdown-menu p-0">
                                        <a href="bill_viewp.php?bill_no=<?php echo $row['bill_id'] ?>" style="text-decoration: none; color: black;">
                                          <li class="dropdown-item"><i class="far fa-eye"></i> View </li>
                                        </a>
                                        <a href="deleteBill.php?bill_no=<?php echo $row['bill_id'] . "&idv=" . $_GET['idv'] ?>" style="text-decoration: none; color: black;">
                                          <li class="dropdown-item"><i class="far fa-trash"></i> Delete </li>
                                        </a>
                                        <!-- <li class="dropdown-item" data-bs-toggle="modal" data-bs-target="#myModalEdit"> <i class="far fa-edit"></i> Edit</li> -->
                                        <!-- <li style="cursor: pointer;" data-sid="<?php echo $row['bill_id'] ?>"  class="dropdown-item" data-bs-toggle="modal" data-bs-target="#myModalDelete"><i class="fas fa-trash-alt"></i> Delete</li> -->
                                        <!-- <li class="dropdown-item" data-bs-toggle="modal" data-bs-target="#myModalPay"><i class="fas fa-money-bill-alt"></i> Pay</li> -->

                                      </ul>
                                    </div>




                                  </td>
                                </tr>

                              <?php
                              }
                              ?>

                            </tbody>
                          </table>


                          <div class="row mt-2">
                            <div class="col-lg-4">
                              <p>Showing 1 to 5 of 5 entries</p>
                            </div>
                            <div class="col-lg-8">
                              <nav aria-label="Page navigation example">
                                <ul class="pagination">
                                  <li class="page-item"><a class="page-link" href="#">Previous</a></li>
                                  <li class="page-item"><a class="page-link" href="#">1</a></li>
                                  <li class="page-item"><a class="page-link" href="#">2</a></li>
                                  <li class="page-item"><a class="page-link" href="#">3</a></li>
                                  <li class="page-item"><a class="page-link" href="#">Next</a></li>
                                </ul>
                              </nav>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>


                  </div>
                  <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">
                    <div class="container">
                      <div class="row mt-5">
                        <div class="col-lg-9">
                          <div class="input-group ">
                            <div class="form-outline">
                              <input type="search" id="form1" class="form-control" placeholder="Search">

                            </div>
                            <button type="button" class="btn" id="button-addon2">
                              <i class="fas fa-search"></i>
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>




                    <div class="container">
                      <div class="row mt-5">
                        <div class="col-lg-12">
                          <table id="example" class="table table-striped table-bordered  mx-10">

                            <thead>
                              <tr>
                                <th>ID</th>
                                <th>Product</th>
                                <!-- <th>SKU</th>

                                <th>Purchase Quantity</th> -->
                                <th>Total Sold </th>
                                <!-- <th>Total Returned</th> -->
                                <th>Remaining Stock </th>
                                <th>Remaining Stock Value</th>
                                <th>Total Purchase Stock</th>
                                <!-- <th>Operations</th> -->
                              </tr>
                            </thead>
                            <tbody>

                              <?php
                              $result = $conn->query("SELECT * FROM stock WHERE supplier_name='$name'");
                              $rowno = 0;
                              if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                  $rowno += 1;
                              ?>
                                  <tr>
                                    <td><?php echo $rowno ?></td>
                                    <td><?php echo $row['product_name'] ?></td>


                                    <?php
                                    $pname = $row['product_name'];
                                    $sold_stock = $conn->query("SELECT SUM(quantity) as quantity from  sale_items WHERE item_name ='$pname'");
                                    if ($sold_stock->num_rows > 0) {
                                      $sold_stock = $sold_stock->fetch_assoc();
                                    }
                                    ?>
                                    <td><?php echo intval($sold_stock['quantity']) ?></td>
                                    <td><?php echo $row['quantity'] ?></td>

                                    <?php
                                    // echo $pname;
                                    $innerResult = $conn->query("SELECT * FROM `product` WHERE product_name='$pname'");
                                    // if ($innerResult->num_rows > 0) {
                                      $innerResult = $innerResult->fetch_assoc();
                                    // }
                                    ?>
                                    <td>Rs.<?php echo intval($row['quantity'])*$innerResult['purchase_price'] ?></td>
                                    <td><?php echo $innerResult['total_purchase'] ?></td>

                                  </tr>
                              <?php
                                }
                              }
                              ?>


                            </tbody>
                          </table>


                          <div class="row mt-2">
                            <div class="col-lg-4">
                              <p>Showing 1 to 5 of 5 entries</p>
                            </div>
                            <div class="col-lg-8">
                              <nav aria-label="Page navigation example">
                                <ul class="pagination">
                                  <li class="page-item"><a class="page-link" href="#">Previous</a></li>
                                  <li class="page-item"><a class="page-link" href="#">1</a></li>
                                  <li class="page-item"><a class="page-link" href="#">2</a></li>
                                  <li class="page-item"><a class="page-link" href="#">3</a></li>
                                  <li class="page-item"><a class="page-link" href="#">Next</a></li>
                                </ul>
                              </nav>
                            </div>
                          </div>

                        </div>

                      </div>
                    </div>


                  </div>
                  <div class="tab-pane fade" id="doc" role="tabpanel" aria-labelledby="doc-tab">
                    <div class="container">
                      <div class="row mt-5">
                        <div class="col-lg-9">
                          <div class="input-group ">
                            <div class="form-outline">
                              <input type="search" id="form1" class="form-control" placeholder="Search">

                            </div>
                            <button type="button" class="btn" id="button-addon2">
                              <i class="fas fa-search"></i>
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>




                    <div class="container">
                      <div class="row mt-5">
                        <div class="col-lg-12">
                          <table id="example" class="table table-striped table-bordered  mx-10">

                            <thead>
                              <tr>
                                <th>ID</th>
                                <th>Action</th>
                                <th>Heading</th>

                                <th>Added By</th>
                                <th>Created At </th>

                              </tr>
                            </thead>
                            <tbody>

                              <tr>
                                <td>1</td>
                                <td>Lopric</td>
                                <td>12344</td>
                                <td>---------------</td>
                                <td>abcd provider</td>


                              </tr>



                            </tbody>
                          </table>


                          <div class="row mt-2">
                            <div class="col-lg-4">
                              <p>Showing 1 to 5 of 5 entries</p>
                            </div>
                            <div class="col-lg-8">
                              <nav aria-label="Page navigation example">
                                <ul class="pagination">
                                  <li class="page-item"><a class="page-link" href="#">Previous</a></li>
                                  <li class="page-item"><a class="page-link" href="#">1</a></li>
                                  <li class="page-item"><a class="page-link" href="#">2</a></li>
                                  <li class="page-item"><a class="page-link" href="#">3</a></li>
                                  <li class="page-item"><a class="page-link" href="#">Next</a></li>
                                </ul>
                              </nav>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                  </div>
                  <div class="tab-pane fade show active" id="payment" role="tabpanel" aria-labelledby="payment-tab">
                    <div class="container">
                      <div class="row">
                        <div class="col-lg-12">
                          <table id="example" class="table table-striped table-bordered  mx-10">

                            <thead>
                              <tr>
                                <th>ID</th>
                                <th>Paid On</th>
                                <th>Reference No.</th>

                                <th>Ammount</th>
                                <th>Payment Method </th>
                                <th>Payment For</th>

                                <th>Operations</th>
                              </tr>
                            </thead>
                            <tbody>

                              <tr>
                                <td>1</td>
                                <td>Lopric</td>
                                <td>12344</td>
                                <td>---------------</td>
                                <td>abcd provider</td>

                                <td>RS 0.00</td>



                                <td class="text-center">

                                  <div class="action">
                                    <button class="btn btn-success btn-sm dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                      Action
                                    </button>
                                    <ul class="dropdown-menu p-0">
                                      <a href="view.php" style="text-decoration: none; color: black;">
                                        <li class="dropdown-item"><i class="far fa-eye"></i> View </li>
                                      </a>
                                      <li class="dropdown-item" data-bs-toggle="modal" data-bs-target="#myModalEdit"> <i class="far fa-edit"></i> Edit</li>
                                      <li class="dropdown-item" data-bs-toggle="modal" data-bs-target="#myModalDelete"><i class="fas fa-trash-alt"></i> Delete</li>
                                      <li class="dropdown-item" data-bs-toggle="modal" data-bs-target="#myModalPay"><i class="fas fa-money-bill-alt"></i> Pay</li>

                                    </ul>
                                  </div>




                                </td>
                              </tr>



                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>



                  </div>
                </div>




              </div>
            </div>


            <div class="card-body table-responsive p-0">






            </div>
            <!-- flex-item -->
          </div>
          <!-- /flex-container -->
        </div>
      </div>
      <!-- flex-item -->
    </div>
    <!-- /flex-container -->
  </div>
</div>

<!-- ============================================================== -->
<!-- End Container fluid  -->
<!-- ============================================================== -->
</div>
<!-- ============================================================== -->
<!-- End Page wrapper  -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- footer -->
<!-- ============================================================== -->
<!--  <footer class="footer fixed">
            © 2020 Elegent Admin by <a href="https://www.wrappixel.com/">wrappixel.com</a>
        </footer> -->
<!-- ============================================================== -->
<!-- End footer -->
<!-- ============================================================== -->
</div>
<!-- ============================================================== -->
<!-- End Wrapper -->
<!-- ============================================================== -->
<!-- ============================================================== -->






</div>






<?php


include 'footer.php';

?>