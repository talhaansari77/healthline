function mulqtyprice() {
    var price = parseFloat($('#pprice').val());
    var qty = parseFloat($('#pqty').val());


    var total = price * qty;
    $('#billtotal').text(total);
    $('#subtotal').val(total);

}

function makediscount(){
    var value = parseFloat($('#sub2').val());
    var percent = parseInt($('#discount').val());
    var discount = value - ((value * percent) / 100);

    $("#distotal").val(discount);
}
function addTax(){
    var vg = parseFloat($('#distotal').val());
    var vp = parseFloat($('#gst').val());
    var discount = vg + ((vg * vp) / 100);

    $("#grandtotal").val(discount);
}

function getbilldata() {
    // getting data from form
    var formData = {};
    formData["pprice"] = parseFloat($('#pprice').val());
    formData["pqty"] = parseInt($('#pqty').val());
    formData["subtotal"] = parseFloat($('#subtotal').val());
    formData["bill_no"] = $('#bill_no').val();
    formData["cus_name"] = $('#cus_name').find(":selected").val();    
    formData["pname"] = $('#pname').find(":selected").text();
    formData["batchNo"] = $('#batchno').find(":selected").val();


    return formData;
}

function add_bill_items() {

    var formdata = getbilldata();

    $.ajax({
        url: "add_bill_items.php",
        type: "POST",
        data: {formdata:formdata},
        success: function (data) {
            $("#data_reload").html(data);
            // mulqtyprice();
            // $("#pname").val(0);
            // $("#pprice").val(0);
            // $("#subtotal").val(0);
            // $("#pqty").val(1);

        }
    });
}
