<?php
define("TITLE", "Products");
define("PAGE", "Products");
include 'connection.php';
include 'header.php';

?>



<div class="body-section">
  <div class="container">
    <div class="card">
      <div class="card-header border-0">
        <h3 class="card-title">Products</h3>
        <hr>
        <div class="container mt-1">
          <!-- Button trigger modal -->
          <div class="row ">
            <div class="col-lg-9 mt-2">
              <div class="input-group ">

                <div>

                </div>
              </div>
            </div>
            <div class="col-lg-3 mt-2">

              <a href="addproduct.php"><button type="button" id="button-addon2" class="btn  float-right mb-3">
                  <i class="fas fa-plus"></i> Add Products
                </button></a>
            </div>
          </div>


          <div class="card-body table-responsive p-0">
            <div class="row">
              <div class="col-lg-12 ">
                <table id="table" class="table table-striped  pt-3">

                  <thead class="table-dark">
                    <tr>
                      <th>#</th>
                      <th>Name</th>
                      <th>Category</th>
                      <th>Sub Category</th>
                      <th>Pieces</th>
                      <th>Batch #</th>
                      <th>Re-Order level</th>
                      <th>Purchase Price</th>
                      <th>Sale Price</th>
                      <th>Stock</th>
                      <th>Expiry Date</th>
                      <th>Operations</th>

                    </tr>
                  </thead>
                  <tbody>
                    <?php
                    $squery = "select * from product";
                    $run = mysqli_query($conn, $squery);
                    while ($row = mysqli_fetch_assoc($run)) {
                      $product_name = $row['product_name'];
                    ?>
                      <tr>
                        <td><?php echo $row['id']; ?></td>
                        <td><?php echo $row['product_name']; ?></td>
                        <td><?php echo $row['catgories']; ?></td>
                        <td><?php echo $row['subcategories']; ?></td>
                        <td><?php echo $row['pieces']; ?></td>
                        <td><?php echo $row['batchno']; ?></td>
                        <td><?php echo $row['reorder_lvl']; ?></td>
                        <td><?php
                            if (isset($row['purchase_price'])) {
                              echo $row['purchase_price'];
                            }
                            ?>
                        </td>
                        <td><?php
                            if (isset($row['selling_price'])) {
                              echo $row['selling_price'];
                            } ?></td>
                        <?php
                        // $query = mysqli_query($conn, "select * from product where product_name='$product_name'");
                        // while ($rowp = mysqli_fetch_assoc($query)) {

                        //   $product_stock = $rowp['opening_stock'];
                        //   $stock = mysqli_query($conn, "select * from stock where product_name='$product_name'");

                        //   $total = 0;
                        //   while ($rows = mysqli_fetch_assoc($stock)) {
                        //     $quantity = intval($rows['quantity']);
                        //     $total += $quantity;
                        //   }
                        //   $total_stock = $product_stock + $total;
                        // }
                        ?>
                        <td>
                        <?php echo $row['opening_stock']; ?>
                          <?php
                            // if (isset($total_stock)) {
                            //   echo $total_stock;
                            // }
                            ?></td>
                            <td>
                            <?php echo $row['exp_date']; ?>
                            </td>
                           
                        <td>
                          <a href="editproduct.php?ide=<?php echo $row['id']; ?>" type="button" class="btn btn-success btn-sm "><i class="fas fa-edit"></i></a>
                          <input type="hidden" class="delete_id_value" value="<?php echo $row['id']; ?>">
                          <a href="javascript:void(0)" type="button" class="delete_btn_ajax btn btn-sm btn-danger"><i class="fas fa-trash"></i></a>
                        </td>
                      </tr>
                    <?php } ?>
                  </tbody>

                </table>
              </div>
            </div>



          </div>
        </div>




      </div>
      <!-- flex-item -->
    </div>
    <!-- /flex-container -->
  </div>
</div>
<!-- flex-item -->
</div>
<!-- /flex-container -->
</div>
</div>

<!-- ============================================================== -->
<!-- End Container fluid  -->
<!-- ============================================================== -->
</div>
<!-- ============================================================== -->
<!-- End Page wrapper  -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- footer -->
<!-- ============================================================== -->
<!--  <footer class="footer fixed">
            © 2020 Elegent Admin by <a href="https://www.wrappixel.com/">wrappixel.com</a>
        </footer> -->
<!-- ============================================================== -->
<!-- End footer -->
<!-- ============================================================== -->
</div>
<!-- ============================================================== -->
<!-- End Wrapper -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<div class="modal fade" id="myModalEdit" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Edit Product</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="container">


          <form method="POST">
            <input type="hidden" name="update_id" id="update_id" />
            <div class="form-group">
              <label class="form-label" for="pname">Product Name</label>
              <input type="text" class="form-control" placeholder="Product Name" name="pname" id="pname">
            </div>
            <div class="form-group">
              <label class="form-label" for="cat">Category</label>
              <select name="cat" class="form-select" id="cat">
                <option disabled>Select Category</option>

              </select>
            </div>
            <div class="form-group">
              <label class="form-label" for="unit">Unit</label>
              <select name="unit" class="form-select" id="unit">
                <option disabled>Select Unit</option>

              </select>
            </div>
            <div class="form-group">
              <label for="estatus" class="form-label">Status:</label>
              <select name="estatus" id="estatus" class="form-select">
                <option value="active">active</option>
                <option value="inactive">inactive</option>
              </select>
            </div>


          </form>
        </div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn " id="button-addon2">Edit</button>
      </div>
    </div>
  </div>
</div>



<!--delete-->
<script>
  $(document).ready(function() {
    $(".delete_btn_ajax").click(function(e) {
      e.preventDefault();
      var deleteid = $(this).closest('tr').find('.delete_id_value').val();
      // alert(deleteid);
      swal({
          title: "Are you sure?",
          text: "Once deleted, you will not be able to recover this Data!",
          icon: "warning",
          buttons: true,
          dangerMode: true,
        })
        .then((willDelete) => {
          if (willDelete) {
            $.ajax({
              type: "POST",
              url: "deleteproduct.php",
              data: {
                "delete_btn_set": 1,
                "deleteid": deleteid,
              },
              success: function(response) {
                swal("Deleted!", "Your Data is Deleted", "success", {
                  button: "Ok!",
                }).then((result) => {
                  location.reload();
                });

              }
            });
          }
        });

    });
  });
</script>


</div>





<?php


include 'footer.php';

?>