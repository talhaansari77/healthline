<?php 
session_start();
include 'connection.php';
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Allison&display=swap" rel="stylesheet">
    <title>Bill</title>
    <style>
        img{
            width:400px;
            height:400px;
            
        }
        .st{
            font-family: 'Allison', cursive;
            letter-spacing:1px;
        }
        .mar{
            margin-top:20px;
        }
    </style>
</head>
<body>
    <div class="container">
    <a href="purchase.php" class="btn btn-sm btn-primary d-print-none mt-3">Back</a>
    <div class="row">
    <table class="table">
                <tr>
                   <td>
                    <div class="col-md-6 bg-dark ml-5">
                        
                    <img src="images/logo.png" alt="" style="width:250px; height:200px;">
                    </div>
                    </td>
                    
                </tr>
            </table>
    </div>
    </div>
    <div class="container" style="margin-top:-100px;">
        <div class="row mt-5">
            <div class="col-md-10 mt-5">
            <?php
                   
                   $bill_id=$_GET['sid'];
                   
                   $sqli=mysqli_query($conn,"select * from items where bill_id='$bill_id'");
                   $sqli_row=mysqli_fetch_assoc($sqli);
                   $datei=$sqli_row['date'];
                   $query=mysqli_query($conn,"SELECT * FROM products_detail WHERE bill_id='$bill_id'");
                   $total=0;
                   $row=mysqli_fetch_assoc($query);
                       $amount=$row["grand_total"];
                       $customer=$row["supplier"];
                       $status=$row["status"];
                       $remaining=$row["remaining"];
                       $paid=$row["paid"];
                  
                   ?>
                <h5>Bill No:&nbsp; <?php echo $bill_id?></h5>
                <h5>Supplier Name: &nbsp;<?php echo $customer?></h5>
                <h5>Date: &nbsp;<?php echo $datei?></h5>
                <br>
            <table id="table" class="table table-bordered pt-2">
                    <thead class="table-dark">
                    <tr>                        
                        
                        <th scope="col">Products</th>
                        <th scope="col">Quantity</th>
                        <th scope="col">Price Per Product</th>
                        <th scope="col">Status</th>
                      
                        
                        
                    </tr>
                    </thead>
                <tbody class="table-light">
                   <?php
                    $sql=mysqli_query($conn,"select * from items where bill_id='$bill_id'");
                    $total=0;
                    while($rsql=mysqli_fetch_assoc($sql)){
                        $product=$rsql['item_name'];
                        $quantity=$rsql['quantity'];
                        $price=$rsql['price'];
                        $date=$rsql['date'];
                        $total=$quantity*$price;
                   ?>
                    <tr>
                        <td><?php echo $product; ?></td>
                        <td><?php echo $quantity; ?></td>
                        <td><?php echo $price; ?></td>
                        <td><?php echo $status; ?></td>
                        
                      
                    
                        
                      
                        
                    </tr>
                <?php
                }
                ?>                    

        <tr></tr>
              
                    
                    
                </tbody>
                

            </table>
            <div class="float-end">
            <h5>Total: <?php echo $amount; ?></h5>
            <h5>Paid: <?php echo $paid; ?></h5>
            <h5>Remaining: <?php echo $remaining; ?></h5>
            </div>
            
            </div>
        </div>
    </div>
       
    
</body>
</html>
<script>
    window.print();
</script>