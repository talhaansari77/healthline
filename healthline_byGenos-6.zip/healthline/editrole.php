<?php 
define("TITLE","Add Role");
define("PAGE","Add Role");

include 'header.php';

?>


<div class="body-section">
<div class="container ">
         <div class="card ">
              <div class="card-header border-0">
                <h3 class="card-title">Edit Role</h3>
                <hr>
      <div class="container mt-1">
      <form id="contact-form" class="studentform" method="POST">
                        <div class="row">
                            <div class="col-md-6 ">
                                <label for="exampleInputRole" class="form-label">Role Name:</label>
                                <input type="text" class="form-control  " id="exampleInputRole "
                                    name="Role" placeholder="Role Name">
                            </div>
                           
                            
                            
                        </div>
                        <hr>
                        <div class="row">
                            <h6>Permissions</h6>
                        </div>
                        <div class="row mt-5">
                            <div class="col-lg-3 ">
                                <h5>User</h5>
                            </div>
                            <div class="col-lg-9">
                            <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                   View User
                                 </label>
                                </div>
                                <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                   Add User
                                 </label>
                                </div>
                                <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                   Edit User
                                 </label>
                                </div>
                                <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                   Delete User
                                 </label>
                                </div>

                            </div>
                        </div>
                        <hr>
                        <div class="row mt-5">
                            <div class="col-lg-3 ">
                                <h5>Roles</h5>
                            </div>
                            <div class="col-lg-9">
                            <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                   View Role
                                 </label>
                                </div>
                                <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                   Add Role
                                 </label>
                                </div>
                                <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                   Edit Role
                                 </label>
                                </div>
                                <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                   Delete Role
                                 </label>
                                </div>

                            </div>
                        </div>
                        <hr>
                        <div class="row mt-5">
                            <div class="col-lg-3 ">
                                <h5>Supplier</h5>
                            </div>
                            <div class="col-lg-9">
                            <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                   View all supplier
                                 </label>
                                </div>
                                <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                   View own supplier
                                 </label>
                                </div>
                                <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                   Add Supplier
                                 </label>
                                </div>
                                <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                   Edit Supplier
                                 </label>
                                </div>
                                <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                   Delete Supplier
                                 </label>
                                </div>

                            </div>
                        </div>
                        <hr>
                        <div class="row mt-5">
                            <div class="col-lg-3 ">
                                <h5>Customer</h5>
                            </div>
                            <div class="col-lg-9">
                            <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                   View all customer
                                 </label>
                                </div>
                                <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                   View own customer
                                 </label>
                                </div>
                                <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                   Add customer
                                 </label>
                                </div>
                                <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                   Edit customer
                                 </label>
                                </div>
                                <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                   Delete customer
                                 </label>
                                </div>

                            </div>
                        </div>
                        <hr>
                        <div class="row mt-5">
                            <div class="col-lg-3 ">
                                <h5>Product</h5>
                            </div>
                            <div class="col-lg-9">
                            <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                   View Product
                                 </label>
                                </div>
                                
                                <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                   Add Product
                                 </label>
                                </div>
                                <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                   Edit Product
                                 </label>
                                </div>
                                <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                   Delete Product
                                 </label>
                                </div>
                                <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                   Add Opening Stock
                                 </label>
                                </div>
                                <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                   View Purchse Price
                                 </label>
                                </div>

                            </div>
                        </div>
                        <hr>
                        <div class="row mt-5">
                            <div class="col-lg-3 ">
                                <h5>Purchase & Stock Adjustment</h5>
                            </div>
                            <div class="col-lg-9">
                            <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                   View Purchase & Stock Adjustment
                                 </label>
                                </div>
                                
                                <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                   Add Purchase & Stock Adjustment
                                 </label>
                                </div>
                                <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                   Edit Purchase & Stock Adjustment
                                 </label>
                                </div>
                                <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                   Delete Purchase & Stock Adjustment
                                 </label>
                                </div>
                                <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                  Add/Edit/Delete Payments 
                                 </label>
                                </div>
                                <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                  Update Status
                                 </label>
                                </div>
                                <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                  View own purchase only
                                 </label>
                                </div>

                            </div>
                        </div>
                        <hr>
                        <div class="row mt-5">
                            <div class="col-lg-3 ">
                                <h5>Sell</h5>
                            </div>
                            <div class="col-lg-9">
                            <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                   Access Sell
                                 </label>
                                </div>
                                
                                <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                  Delete Sell
                                 </label>
                                </div>
                                <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                  List Drafts
                                 </label>
                                </div>
                                <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                  List quotations
                                 </label>
                                </div>
                                <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                  View own sell only 
                                 </label>
                                </div>
                                <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                  Commission agent can view their own sell
                                 </label>
                                </div>
                                <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                  Add/Edit/Delete Payments
                                 </label>
                                </div>
                                <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                  Edit product price from sales screen
                                 </label>
                                </div>
                                <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                  Edit product discount from Sale screen
                                 </label>
                                </div>
                                <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                  Add/Edit/Delete Discount
                                 </label>
                                </div>
                                <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                  Access sell return
                                 </label>
                                </div>
                                <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                  Add edit invoice number
                                 </label>
                                </div>

                            </div>
                        </div>
                        <hr>
                        <div class="row mt-5">
                            <div class="col-lg-3 ">
                                <h5>Shipments</h5>
                            </div>
                            <div class="col-lg-9">
                            <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                  Access Shipments
                                 </label>
                                </div>
                                
                                <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                  Access own shipments
                                 </label>
                                </div>
                                <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                  Commission agent can access their own shipments
                                 </label>
                                </div>
                                

                            </div>
                        </div>
                        <hr>
                        <div class="row mt-5">
                            <div class="col-lg-3 ">
                                <h5>Cash Register</h5>
                            </div>
                            <div class="col-lg-9">
                            <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                  View cash register
                                 </label>
                                </div>
                                
                                <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                  Close cash register
                                 </label>
                                </div>
                                
                                

                            </div>
                        </div>
                        <hr>
                        <div class="row mt-5">
                            <div class="col-lg-3 ">
                                <h5>Brand</h5>
                            </div>
                            <div class="col-lg-9">
                            <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                   View brand
                                 </label>
                                </div>
                                <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                   Add brand
                                 </label>
                                </div>
                                <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                   Edit brand
                                 </label>
                                </div>
                                <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                   Delete brand
                                 </label>
                                </div>

                            </div>
                        </div>
                        <hr>
                        <div class="row mt-5">
                            <div class="col-lg-3 ">
                                <h5>Tax Rate</h5>
                            </div>
                            <div class="col-lg-9">
                            <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                   View Tax Rate
                                 </label>
                                </div>
                                <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                   Add Tax Rate
                                 </label>
                                </div>
                                <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                   Edit Tax Rate
                                 </label>
                                </div>
                                <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                   Delete Tax Rate
                                 </label>
                                </div>

                            </div>
                        </div>
                        <hr>
                        <div class="row mt-5">
                            <div class="col-lg-3 ">
                                <h5>Unit</h5>
                            </div>
                            <div class="col-lg-9">
                            <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                   View Unit
                                 </label>
                                </div>
                                <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                   Add Unit
                                 </label>
                                </div>
                                <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                   Edit Unit
                                 </label>
                                </div>
                                <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                   Delete Unit
                                 </label>
                                </div>

                            </div>
                        </div>
                        <hr>
                        <div class="row mt-5">
                            <div class="col-lg-3 ">
                                <h5>Category</h5>
                            </div>
                            <div class="col-lg-9">
                            <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                   View Category
                                 </label>
                                </div>
                                <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                   Add Category
                                 </label>
                                </div>
                                <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                   Edit Category
                                 </label>
                                </div>
                                <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                   Delete Category
                                 </label>
                                </div>

                            </div>
                        </div>
                        <hr>
                        <div class="row mt-5">
                            <div class="col-lg-3 ">
                                <h5>Report</h5>
                            </div>
                            <div class="col-lg-9">
                            <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                  View purchase & sell report
                                 </label>
                                </div>
                                <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                  View Tax report
                                 </label>
                                </div>
                                <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                  View Supplier & Customer report
                                 </label>
                                </div>
                                <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                  View expense report
                                 </label>
                                </div>
                                <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                  View profit/loss report
                                 </label>
                                </div>
                                <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                  View stock report, stock adjustment report & stock expiry report
                                 </label>
                                </div>
                                <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                  View trending product report
                                 </label>
                                </div>
                                <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                  View register report
                                 </label>
                                </div>
                                <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                  View sales representative report
                                 </label>
                                </div>
                                <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                  View product stock value
                                 </label>
                                </div>

                            </div>
                        </div>
                        <hr>
                        <div class="row mt-5">
                            <div class="col-lg-3 ">
                                <h5>Setting</h5>
                            </div>
                            <div class="col-lg-9">
                            <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                  Access business settings
                                 </label>
                                </div>
                                <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                  Access barcode settings
                                 </label>
                                </div>
                                <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                  Access invoice settings
                                 </label>
                                </div>
                                <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                  Access expenses
                                 </label>
                                </div>
                                <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                  View own expense only
                                 </label>
                                </div>
                                <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                  Access printers
                                 </label>
                                </div>
                                

                            </div>
                        </div>
                        <hr>
                        <div class="row mt-5">
                            <div class="col-lg-3 ">
                                <h5>Home</h5>
                            </div>
                            <div class="col-lg-9">
                            <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                  View Home data
                                 </label>
                                </div>
                               
                                

                            </div>
                        </div>
                        <hr>
                        <div class="row mt-5">
                            <div class="col-lg-3 ">
                                <h5>Account</h5>
                            </div>
                            <div class="col-lg-9">
                            <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                 Access Accounts
                                 </label>
                                </div>
                               
                                

                            </div>
                        </div>
                        <hr>
                        <div class="row mt-5">
                            <div class="col-lg-3 ">
                                <h5>Access selling price groups</h5>
                            </div>
                            <div class="col-lg-9">
                            <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                  <label class="form-check-label" for="flexCheckDefault">
                                  Default Selling Price
                                 </label>
                                </div>
                               
                                

                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-4">

                            </div>
                            <div class="col-lg-4 text-center">
                            <button class="btn btn-success mt-3"> Save</button>
                            </div>
                            <div class="col-lg-4">

                            </div>
                        </div>
                        



    </div>

</from>


  
              <div class="card-body table-responsive p-0">
                
              </div>
            </div>
            



            </div>
            <!-- flex-item -->
        </div>
        <!-- /flex-container -->
    </div>
            </div>
            <!-- flex-item -->
        </div>
        <!-- /flex-container -->
    </div>
</div>
        
        </div>
      
    </div>




    </div>






<?php 


include 'footer.php';

?>