<html lang="en">
<html>

<head>
	<title>NEW</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.css">

</head>

<body>
	<div class="container text-center mt-5" style=" width:100% ;">
		<form id="cart">
			<table name="cart table  responsive text-center">
				<div class="row text-center mx-auto">
					<div class="col-xl-3 mt-2">
						<div class="form-group " style="display: inline;">
							<input type="text" class="form-control" name="unique_id" id="unique">
						</div>
					</div>
					<div class="col-xl-3 mt-2">
						<div class="form-group mx-3">
							<select class="form-control " name="sup_name" id="name_suppler" required="">
								<option value="">Select Suppler</option>
								<option value="one">one</option>
								<option value="two">two</option>
								<option value="three">three</option>
								<option value="four">four</option>
								<option value="five">five</option>
							</select>
						</div>
					</div>
					<div class="col-xl-3 mt-2">
						<div class="form-group " style="display: inline;">
							<select class="form-control    mx-auto" name="status" id="status_id" required="" onchange="cat(this.value)">
								<option value="">Status</option>
								<option value="paid">Paid</option>
								<option value="unpaid">UnPaid</option>

							</select>
						</div>
					</div>
					<div class="col-md-3 mt-2">
						<div class="form-group" id="money">

						</div>
					</div>
				</div>
				<tr class="mt-5">
					<td>&nbsp;</td>
					<th><label for=""> Product_Name</label></th>
					<th><label for="">Quantity</label></th>
					<th>Price</th>
					<th></th>
					<th style=" margin-left:20px"><label for=""> Total_Price</label></th>
				</tr>
				<tr class="line_items text-center " style="margin-top:5px;">
					<td><button class="row-remove btn btn-danger " style=" margin-right:20px">Remove</button></td>
					<td> <select class="form-control product_name" style="    margin-top: 11px;" required="">
							<option value="">Select Product_Name</option>
							<option value="mobile">mobile</option>
							<option value="laptop">laptop</option>
							<option value="car">car</option>
							<option value="computer">computer</option>
							<option value="handfree">handfree</option>
						</select></td>
					<input type="hidden" class="form-control sup_name assign" value="">
					<input type="hidden" class="form-control bill_id assign_id" value="">
					<input type="hidden" class="form-control status assign_status" value="">
					<input type="hidden" class="form-control rup assign_amount" value="">
					<td><input type="text" class="form-control quantity_name" style="    margin-top: 11px;" name="qty" value=""></td>
					<td><input type="text" class="form-control price_name" style="    margin-top: 11px;" name="price" value=""></td>
					<td>&nbsp;</td>
					<td><input type="text" class="form-control tprice_name" style="    margin-top: 11px;" name="item_total" value="" jAutoCalc="{qty} * {price}"></td>
				</tr>
				<tr>
					<td colspan="3">&nbsp;</td>
					<th><label for="">Total</label></th>
					<td>&nbsp;</td>
					<td><input type="text" class="form-control" id="sub" name="sub_total" value="" jAutoCalc="SUM({item_total})"></td>
				</tr>


				<tr style="margin-bottom: 20px;">
					<td colspan="99" class="mb-3"><button class="row-add btn btn-primary px-3">Add </button></td>
				</tr>
				<tr>
					<td colspan="99"><button type="submit" style=" margin-top: 16px;" class="btn btn-success p-2">Submit </button></td>
				</tr>
			</table>
		</form>
	</div>
	<!-- ...........form pric -->




	<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js"></script>
	<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/jautocalc@1.3.1/dist/jautocalc.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.repeater/1.2.1/jquery.repeater.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.repeater/1.2.1/jquery.repeater.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert-dev.js"></script>

	<script type="text/javascript">
		function cat(data) {
			const ajaxreq = new XMLHttpRequest();
			ajaxreq.open('GET', 'http://localhost/htdocs/new(1)/new/pdata.php?selectvalue=' + data, 'TRUE');
			ajaxreq.send();
			ajaxreq.onreadystatechange = function() {
				if (ajaxreq.readyState == 4 && ajaxreq.status == 200) {
					document.getElementById('money').innerHTML = ajaxreq.responseText;
				}
			}
		}

		$(function() {

			function autoCalcSetup() {
				$('form#cart').jAutoCalc('destroy');
				$('form#cart tr.line_items').jAutoCalc({
					keyEventsFire: true,
					decimalPlaces: 2,
					emptyAsZero: true
				});
				$('form#cart').jAutoCalc({
					decimalPlaces: 2
				});
			}
			autoCalcSetup();
			$('button.row-remove').on("click", function(e) {
				e.preventDefault();

				var form = $(this).parents('form')
				$(this).parents('tr').remove();
				autoCalcSetup();

			});

			$('button.row-add').on("click", function(e) {
				e.preventDefault();

				var $table = $(this).parents('table');
				var $top = $table.find('tr.line_items').first();
				var $new = $top.clone(true);

				$new.jAutoCalc('destroy');
				$new.insertBefore($top);
				$new.find('input[type=text]').val('');
				autoCalcSetup();

			});

		});
		//-->


		$("#cart").on("submit", function(e) {
			e.preventDefault();
			let name = $('#name_suppler').val();
			console.log(name);
			$('.assign').val(name);

			let uniqid = $('#unique').val();
			console.log(uniqid);
			$('.assign_id').val(uniqid);

			let status_bill = $("#status_id").val();
			console.log(status_bill);
			$('.assign_status').val(status_bill);

			let paid_amount = $("#rupee").val();
			console.log(paid_amount);
			$('.assign_amount').val(paid_amount);

			let sub = $('#sub').val();
			var sup_name = [];
			var product_name = [];
			var quantity_name = [];
			var price_name = [];
			var tprice_name = [];
			var bill_id = [];
			var status = [];
			var rup = [];
			$('.sup_name').each(function() {
				sup_name.push({
					value: this.value
				});
			});
			$('.product_name').each(function() {

				product_name.push({
					value: this.value
				})
			});
			$('.quantity_name').each(function() {

				quantity_name.push({
					value: this.value
				})
			});
			$('.price_name').each(function() {

				price_name.push({
					value: this.value
				})
			});
			$('.tprice_name').each(function() {

				tprice_name.push({
					value: this.value
				})
			});
			$('.bill_id').each(function() {

				bill_id.push({
					value: this.value
				})
			});
			$('.status').each(function() {

				status.push({
					value: this.value
				})
			});

			$('.rup').each(function() {

				rup.push({
					value: this.value
				})
			});
			$.ajax({
				url: "ajax.php?price_form",
				type: "POST",
				data: {
					sup_name: sup_name,
					product_name: product_name,
					quantity_name: quantity_name,
					price_name: price_name,
					tprice_name: tprice_name,
					bill_id: bill_id,
					status: status,
					name: name,
					uniqid: uniqid,
					status_bill: status_bill,
					sub: sub,
					rup: rup
				},
				success: function(data) {
					console.log(data);
					let response = JSON.parse(data);
					// $('#cart').trigger("reset");
					if (response.status == "success") {
						swal({
							title: "Success!",
							text: "Good job.",
							type: "success",
							timer: 5000,
							showConfirmButton: true
						}, function() {
							//   window.location.href = "view_all.php";
						});
					}
				},

			});
		});
	</script>
</body>

</html>