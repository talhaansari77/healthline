<?php

include_once "connection.php";

$qty = $_POST['qty'];

$product = explode(",", $_POST["name"])[0];


// $reuslt = $conn->query("SELECT `batchno` from product WHERE `product_name`='$product'");
$reuslt = $conn->query("SELECT * from product WHERE `product_name`='$product'");

if ($reuslt->num_rows > 0) {
    $reuslt = $reuslt->fetch_assoc();
    $batches = explode(",", $reuslt['batchno']);
}

?>


<div class="col-lg-3">
    <label class="form-label" id="">Product Name</label>
    <select class="form-select" onchange="get_old_price(),get_batch()" id="pname" name="pname">
        <optgroup label="Select Product">
            <?php
            $sql = "SELECT * FROM product ";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
            ?>
                    <option value="<?php echo $row['product_name'] . "," . $row['id'] ?>" <?php if($product == $row['product_name']) echo "selected" ?> ><?php echo $row['product_name'] ?></option>
            <?php

                }
            }
            ?>
        </optgroup>
    </select>
</div>

<!-- get batch name -->
<div class="col-lg-3">
    <label class="form-label" id="">Batch #</label>
    <select class="form-select" onchange="get_old_price()" id="batchno" name="batchno">
        <optgroup label="Select Product">
            <?php

            if (sizeof($batches) > 0) {
                foreach ($batches as $batch) {

            ?>
                    <option value="<?php echo $batch ?>">
                        <?php echo $batch ?>
                    </option>
            <?php
                }
            }
            ?>
        </optgroup>
    </select>
</div>



<div class="col-lg-3">
    <label class="form-label" id="">Quantity</label>
    <input class="form-control" value="<?php echo $qty?>" onkeyup="mulqtyprice()" min="1" pattern="[1-9][0-9]*" type="number" value="1" name="pqty" id="pqty" required>

</div>


<div class="col-lg-3">
    <label class="form-label" id="">Price</label>

    <input class="form-control" value="<?php echo $reuslt['selling_price']?>" min="0" onkeyup="mulqtyprice()" pattern="[1-9][0-9]*" type="number" name="pprice" id="pprice" required>

</div>