<?php
define("TITLE", "Products");
define("PAGE", "Products");
include 'connection.php';
include 'header.php';
$id = $_GET['ide'];
$query = mysqli_query($conn, "select * from product where id='$id'");
$rowe = mysqli_fetch_assoc($query);
?>


<div class="body-section">
    <div class="container ">
        <div class="card ">
            <div class="card-header border-0">
                <h3 class="card-title">Edit Product</h3>
                <hr>
                <div class="container mt-1">
                    <form id="contact-form" class="studentform" method="POST">
                        <div class="row">
                            <div class="col-md-6 ">
                                <label class="form-label">Product Name:</label>
                                <input type="text" class="form-control" name="product" placeholder="Product Name" value="<?php echo $rowe['product_name']; ?>">
                            </div>

                            <div class="col-md-6 ">

                                <label class="form-label">Narcotics:</label>
                                <div class="input-group">
                                    <select class="form-select" name="narcotics">
                                        <option value="<?php echo $rowe['narcotics']; ?>"><?php echo $rowe['narcotics']; ?></option>
                                        <option value="yes">Yes</option>
                                        <option value="no">No</option>

                                    </select>


                                </div>
                            </div>




                        </div>
                        <div class="row mt-3">

                            <div class="col-md-3 ">

                                <label class="form-label">Manufacturer:</label>
                                <div class="input-group">
                                    <select name="manufecturer" class="form-select">
                                        <option value="<?php echo $rowe['manufacturer']; ?>"><?php echo $rowe['manufacturer']; ?></option>
                                        <?php
                                        $brand_query = mysqli_query($conn, "select * from brands");
                                        while ($row = mysqli_fetch_assoc($brand_query)) {
                                        ?>
                                            <option value="<?php echo $row['name']; ?>"><?php echo $row['name']; ?></option>
                                        <?php
                                        }
                                        ?>
                                    </select>

                                </div>





                            </div>
                            <div class="col-md-3 ">
                                <label class="form-label">Re-Order Level:</label>
                                <input type="text" class="form-control" name="reorder_lvl" placeholder="Reorder Level" value="<?php echo $rowe['reorder_lvl']; ?>">
                            </div>
                            <div class="col-md-3 ">

                                <label class="form-label">Pieces:</label>
                                <div class="input-group">
                                    <input type="number" class="form-control" min="1" name="pieces" value="<?php echo $rowe['pieces']; ?>">


                                </div>



                            </div>
                            <div class="col-md-3 ">

                                <label class="form-label">Batch #</label>
                                <div class="input-group">
                                    <input type="text" class="form-control" name="batchno" value="<?php echo $rowe['batchno']; ?>">


                                </div>



                            </div>


                        </div>
                        <div class="row mt-3">
                            <div class="col-md-4 ">

                                <label class="form-label">Catagories:</label>

                                <select name="category" class="form-select">
                                    <option value="<?php echo $rowe['catgories']; ?>"><?php echo $rowe['catgories']; ?></option>
                                    <?php
                                    $cat_query = mysqli_query($conn, "select * from categories");
                                    while ($row = mysqli_fetch_assoc($cat_query)) {
                                    ?>
                                        <option value="<?php echo $row['name']; ?>"><?php echo $row['name']; ?></option>
                                    <?php
                                    }
                                    ?>
                                </select>


                            </div>
                            <div class="col-md-4 ">

                                <label class="form-label">Sub-Catagories:</label>

                                <select name="subcat" class="form-select">
                                    <option value="<?php echo $rowe['subcategories']; ?>"><?php echo $rowe['subcategories'];  ?></option>
                                    <?php
                                    $sub_query = mysqli_query($conn, "select * from subcategories");
                                    while ($row = mysqli_fetch_assoc($sub_query)) {
                                    ?>
                                        <option value="<?php echo $row['sub']; ?>"><?php echo $row['sub']; ?></option>
                                    <?php
                                    }
                                    ?>
                                </select>


                            </div>
                            <div class="col-md-4 ">
                                <label class="form-label">Alter Quantity:</label>
                                <input type="number" class="form-control" name="alter" placeholder="Alter Quantity" value="<?php echo $rowe['alter_quantity']; ?>">
                            </div>



                        </div>


                        <div class="row mt-3">

                            <div class="col-md-6 ">
                                <label class="form-label">Opening Stock:</label>
                                <input type="number" class="form-control" name="stock" placeholder="Stock" value="<?php echo $rowe['opening_stock']; ?>">
                            </div>
                            <div class="col-md-6 ">
                                <label class="form-label">Add Stock:</label>
                                <input type="number" class="form-control" name="plus_stock" placeholder="New Stock" value="">
                            </div>
                            <input type="hidden" name="total_purchase" value="<?php echo $rowe['total_purchase']; ?>">

                        </div>


                        <div class="row mt-3">
                            <div class="col-md-12">
                                <label class="form-label">Product Description:</label>
                                <div>
                                    <textarea class="form-control" name="productDes"> <?php echo $rowe['product_desc']; ?> </textarea>
                                    <script>
                                        CKEDITOR.replace('exampleInputpdes');
                                    </script>

                                </div>
                            </div>

                        </div>
                        <div class="row mt-3">
                            <div class="col-md-6 ">
                                <label class="form-label">Rack:</label>
                                <input type="number" class="form-control" name="rack" placeholder="Rack" value="<?php echo $rowe['rack']; ?>">
                            </div>
                            <div class="col-md-6 ">
                                <label class="form-label">Row:</label>
                                <input type="number" class="form-control" name="row" placeholder="Row" value="<?php echo $rowe['row']; ?>">
                            </div>
                        </div>
                        <div class="row mt-3">
                            <div class="col-md-6 ">
                                <label class="form-label">Position:</label>
                                <input type="text" class="form-control" name="position" placeholder="Position" value="<?php echo $rowe['position']; ?>">
                            </div>
                            <div class="col-md-6 ">
                                <label class="form-label">Location:</label>
                                <select name="location" class="form-select">
                                    <option value="<?php echo $rowe['location']; ?>"><?php echo $rowe['location']; ?></option>
                                    <?php
                                    $location_query = mysqli_query($conn, "select * from location");
                                    while ($row = mysqli_fetch_assoc($location_query)) {
                                    ?>
                                        <option value="<?php echo $row['location']; ?>"><?php echo $row['location']; ?></option>
                                    <?php
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>

                        <hr>
                        <div class="row mt-3">
                            <div class="col-md-4 ">

                                <label class="form-label">Product Type:</label>

                                <select name="type" class="form-select">
                                    <option value="<?php echo $rowe['product_type']; ?>"><?php echo $rowe['product_type']; ?></option>
                                    <option value="single">Single</option>
                                    <option value="variable">Variable</option>
                                    <option value="combo">Combo</option>

                                </select>


                            </div>

                        </div>
                        <div class="row mt-3">
                            <div class="col-md-12 table-responsive">

                                <table class="table table-bordered ">
                                    <tr class="th">
                                        <th>Default Selling Price</th>
                                        <th>Default Purchase Price</th>

                                    </tr>
                                    <tr>
                                        <td>
                                            <label class="form-label">Selling Price:</label>
                                            <input type="text" class="form-control" name="sprice" placeholder="Selling Price:" value="<?php echo $rowe['selling_price']; ?>">
                                        </td>

                                        <td>
                                            <label class="form-label">Purchasing Price:</label>
                                            <input type="text" class="form-control" name="pprice" placeholder="Purchasing Price:" value="<?php echo $rowe['purchase_price']; ?>">

                                        </td>

                                        </td>
                                    </tr>

                                </table>


                            </div>
                            <div class="row mt-3">
                                <div class="col-md-3 ">
                                    <label class="form-label">Purchase Disc%:</label>
                                    <input type="number" class="form-control" name="pdiscount" placeholder="Purchase" value="<?php echo $rowe['purchase_discount']; ?>">
                                </div>
                                <div class="col-md-3 ">
                                    <label class="form-label">Sale Disc%:</label>
                                    <input type="number" class="form-control" name="sdicount" placeholder="Sale Disc%" value="<?php echo $rowe['sale_discount']; ?>">
                                </div>
                                <div class="col-md-2 ">
                                    <label class="form-label">Sales Commission</label>
                                    <input type="number" min="0" class="form-control" name="SalesCommission" value="<?php echo explode('%',$rowe['comission'])[0]; ?>">


                                </div>
                                <div class="col-md-1 ">
                                <div><label class="form-label"> Type</label></div>
                                    %<input type="radio" value="%" <?php if(strpos($rowe['comission'], '%')) echo 'checked'?> name="comtype">
                                    Rs<input type="radio" value="Rs" <?php if(strpos($rowe['comission'], 'Rs')) echo 'checked'?> name="comtype">

                                </div>
                                <div class="col-md-3 ">
                                    <label class="form-label">Expiry Date</label>
                                    <input type="text" class="form-control" name="exp_date" value="<?php echo $rowe['exp_date']; ?>">
                                </div>
                            </div>

                            <div class="row mt-3 mb-3">

                                <div class="col-lg-4 ">
                                    <button type="submit" class="btn btn-success btn-lg" style="margin-left:25px; " name="edit">Edit Product</button>
                                </div>

                            </div>



                        </div>

                        </from>



                        <div class="card-body table-responsive p-0">

                        </div>
                </div>




            </div>
            <!-- flex-item -->
        </div>
        <!-- /flex-container -->
    </div>
</div>
<!-- flex-item -->
</div>
<!-- /flex-container -->
</div>
</div>

</div>

</div>




</div>






<?php


include 'footer.php';

//Add Product into database
if (isset($_POST['edit'])) {
    $product_name = $_POST['product'];
    $narcotics = $_POST['narcotics'];

    $pieces = $_POST['pieces'];
    $batchno = $_POST['batchno'];
    $exp_date = $_POST['exp_date'];
    $reorder_lvl = $_POST['reorder_lvl'];
    $plus_stock = $_POST['plus_stock'];
    $SalesCommission = $_POST['SalesCommission'].$_POST['comtype'];

    $manufecturer = $_POST['manufecturer'];
    $category = $_POST['category'];
    $subcategory = $_POST['subcat'];
    $alter = $_POST['alter'];
    $stock = $_POST['stock'];


    $stock += $plus_stock;
    $total_purchase = $plus_stock + intval($_POST['total_purchase']);

    $productDes = $_POST['productDes'];
    $rack = $_POST['rack'];
    $row = $_POST['row'];
    $position = $_POST['position'];
    $location = $_POST['location'];
    $type = $_POST['type'];
    $sprice = $_POST['sprice'];
    $pprice = $_POST['pprice'];
    $pdiscount = $_POST['pdiscount'];
    $sdiscount = $_POST['sdicount'];

    $update = "UPDATE `product` SET `product_name`='$product_name',`narcotics`='$narcotics',`pieces`='$pieces',`batchno`='$batchno',`exp_date`='$exp_date',`reorder_lvl`='$reorder_lvl',`manufacturer`='$manufecturer',`catgories`='$category',`subcategories`='$subcategory',`alter_quantity`='$alter',`opening_stock`='$stock',`product_desc`='$productDes',`rack`='$rack',`row`='$row',`position`='$position',`location`='$location',`product_type`='$type',`selling_price`='$sprice',`purchase_price`='$pprice',`purchase_discount`='$pdiscount',`sale_discount`='$sdiscount', `total_purchase`='$total_purchase', `comission`='$SalesCommission' WHERE id='$id'";
    $res = mysqli_query($conn, $update);
    if ($res) {
?>
        <script>
            window.location = "<?php echo $app_url . '/product.php' ?>";
            // window.location = "<?php 'product.php' ?>";
        </script>
    <?php
    } else {
    ?>
        <script>
            alert("Failed");
        </script>
<?php
    }
}
?>