-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 08, 2021 at 01:22 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `healthline`
--

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`id`, `name`, `status`) VALUES
(1, 'b1', 'active'),
(2, 'b2', 'active'),
(5, 'b3', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `status`) VALUES
(2, 'ready', 'active'),
(3, 'raw', 'active'),
(10, 'c1', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `commission`
--

CREATE TABLE `commission` (
  `id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `emp_name` varchar(100) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp(),
  `lastupdate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `commission`
--

INSERT INTO `commission` (`id`, `amount`, `emp_name`, `date`, `lastupdate`) VALUES
(1, '204.90', 'Talha Ansari ', '2021-11-08', '2021-11-08'),
(3, '0.00', '', '2021-11-06', '0000-00-00'),
(4, '1.50', 'new.1234', '2021-11-06', '2021-11-06'),
(5, '0.00', 'FreeGuy  ', '2021-11-06', '2021-11-06'),
(6, '0.00', 'SuperUser', '2021-11-06', '2021-11-08'),
(7, '0.00', 'spunchBob', '2021-11-08', '2021-11-08');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `profile` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `mobile` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `cnic` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `business_name` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `address` text COLLATE utf8mb4_bin NOT NULL,
  `licence_no` varchar(100) COLLATE utf8mb4_bin NOT NULL,
  `licence_exp` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `name`, `profile`, `mobile`, `cnic`, `business_name`, `address`, `licence_no`, `licence_exp`) VALUES
(6, 'Hashim Customer', 'customers/men.jpg', '123456', '34643634', 'hashim bb', 'LAhore', '', '0000-00-00'),
(11, 'Talha Ansari', 'customers/download (1).jpg', '03095235889', '3410146843513', 'KingStar', 'Lahore', '87965445', '2021-10-30'),
(12, 'c1', 'customers/5a148de51dd6d.jpg', '030224548554', '1434565432', 'cust', 'ryewgturteyugewoigtutfdsiguwfdsgjdygh', '24567654', '2021-11-17');

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `id` int(11) NOT NULL,
  `supplier` varchar(255) NOT NULL,
  `bill_id` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `item_name` varchar(255) NOT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp(),
  `total` decimal(10,2) NOT NULL,
  `batchno` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`id`, `supplier`, `bill_id`, `status`, `item_name`, `quantity`, `price`, `date`, `total`, `batchno`) VALUES
(188, 'Hashim', '20211022092631', 'returned', 'p1', '1.00', '500.00', '2020-10-23', '500.00', ''),
(189, 'Hashim', '20211022094145', 'returned', 'p1', '1.00', '456.00', '2020-10-23', '456.00', 'khajshd45'),
(211, 'Ali', '20211026093538', 'returned', 'p1', '1.00', '0.00', '2021-10-26', '0.00', ''),
(212, 'Ali', '20211026093538', 'returned', 'p2', '1.00', '0.00', '2021-10-26', '0.00', ''),
(213, 'Ali', '20211026093538', 'returned', 'p3', '1.00', '0.00', '2021-10-26', '0.00', ''),
(214, 'Ali', '20211026093538', 'returned', 'newproduct', '1.00', '10.00', '2021-10-26', '10.00', ''),
(215, 'Ali', '20211026012257', '', 'newproduct', '11.00', '45.00', '2021-10-26', '495.00', 'and'),
(223, 'Talha Ansari', '20211027033045', '', 'p1', '1.00', '45.00', '2021-10-27', '45.00', ''),
(224, 'Ali', '20211028100459', '', 'p1', '15.00', '45.00', '2021-10-28', '675.00', ''),
(232, 'Ali', '20211030125453', '', 'p1', '1.00', '0.00', '2021-10-30', '0.00', ''),
(233, 'Ali', '20211030125453', '', 'p1', '1.00', '0.00', '2021-10-30', '0.00', ''),
(234, 'Ali', '20211030125453', '', 'p1', '10.00', '0.00', '2021-10-30', '0.00', ''),
(235, 'Ali', '20211030125453', '', 'newproduct', '1.00', '9999.00', '2021-10-30', '9999.00', 'this'),
(236, 'Ali', '20211030125453', '', 'newproduct', '1.00', '0.00', '2021-10-30', '0.00', 'this'),
(237, 'Ali', '20211030125453', '', 'newproduct', '12.00', '0.00', '2021-10-30', '0.00', 'this'),
(238, 'Ali', '20211030125453', '', 'newproduct', '1.00', '0.00', '2021-10-30', '0.00', 'this'),
(239, 'Ali', '20211030125453', '', 'newproduct', '1.00', '0.00', '2021-10-30', '0.00', 'this'),
(240, 'Ali', '20211030125453', '', 'newproduct', '1.00', '0.00', '2021-10-30', '0.00', 'this'),
(241, 'Ali', '20211030125453', '', 'newproduct', '1.00', '0.00', '2021-10-30', '0.00', 'this'),
(242, 'Ali', '20211030125453', '', 'p1', '10.00', '897.00', '2021-10-30', '8970.00', ''),
(244, 'Ali', '20211030010930', '', 'p1', '150.00', '45.00', '2021-10-30', '6750.00', ''),
(245, 'Ali', '20211030010930', '', 'newproduct', '50.00', '278.00', '2021-10-30', '13900.00', 'this'),
(258, 'Talha Ansari', '20211030025341', '', 'p1', '1.00', '45.00', '2021-10-30', '45.00', ''),
(259, 'Talha Ansari', '20211030025341', '', 'p2', '1.00', '36.00', '2021-10-30', '36.00', ''),
(260, 'Talha Ansari', '20211030025341', '', 'new product', '1.00', '56.00', '2021-10-30', '56.00', 'this'),
(314, 'Ali', '20211107104244', '', 'new product', '1000.00', '10.00', '2021-11-07', '10000.00', 'this'),
(318, 'Ali', '20211107112904', 'returned', 'p1', '5.00', '10.00', '2021-11-07', '50.00', ''),
(319, 'Ali', '20211108071126', 'returned', 'p1', '2.00', '10.00', '2021-11-08', '20.00', '');

-- --------------------------------------------------------

--
-- Table structure for table `location`
--

CREATE TABLE `location` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `location` text COLLATE utf8mb4_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Dumping data for table `location`
--

INSERT INTO `location` (`id`, `name`, `location`) VALUES
(1, 'Ali', 'Lahore, Lahore'),
(2, 'Hashim', 'Gujranwala');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp(),
  `role` int(11) DEFAULT NULL,
  `phone` varchar(15) NOT NULL,
  `address` varchar(250) NOT NULL,
  `cnic` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `name`, `email`, `password`, `date`, `role`, `phone`, `address`, `cnic`) VALUES
(6, 'Talha Ansari ', 'asd@asd.com', '456', '2021-10-25', 37, '03123456987', 'LAHORE', ''),
(7, 'new.1234', 'this@is.com', '123', '2021-10-25', 30, '03123456987', 'pta ni\r\nl', ''),
(10, 'FreeGuy  ', 'asd1@asd.com', '123', '2021-10-26', 31, '03095235889', 'Lahore, Lahore', ''),
(13, 'SuperUser', 'super@test.com', '123', '2021-11-05', 37, '03123456789', 'Lahore', ''),
(14, 'spunchBob', 'spunch@bob.com', '123', '2021-11-08', 40, '03123456789', 'Lahore\r\nLahore', '12345-1234567-9');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `product_name` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `narcotics` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `pieces` int(11) NOT NULL,
  `batchno` varchar(100) COLLATE utf8mb4_bin NOT NULL,
  `exp_date` varchar(50) COLLATE utf8mb4_bin NOT NULL,
  `reorder_lvl` varchar(100) COLLATE utf8mb4_bin NOT NULL,
  `manufacturer` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `catgories` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `subcategories` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `alter_quantity` int(11) NOT NULL,
  `opening_stock` int(11) NOT NULL,
  `product_desc` text COLLATE utf8mb4_bin NOT NULL,
  `rack` int(11) NOT NULL,
  `row` int(11) NOT NULL,
  `position` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `location` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `product_type` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `selling_price` decimal(10,2) NOT NULL,
  `purchase_price` decimal(10,2) NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `purchase_discount` int(11) NOT NULL,
  `sale_discount` int(11) NOT NULL,
  `total_purchase` int(11) NOT NULL,
  `comission` varchar(50) COLLATE utf8mb4_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `product_name`, `narcotics`, `pieces`, `batchno`, `exp_date`, `reorder_lvl`, `manufacturer`, `catgories`, `subcategories`, `alter_quantity`, `opening_stock`, `product_desc`, `rack`, `row`, `position`, `location`, `product_type`, `selling_price`, `purchase_price`, `image`, `purchase_discount`, `sale_discount`, `total_purchase`, `comission`) VALUES
(4, 'p1', 'yes', 1000, '', '', '', 'b1', 'ready', 'r1', 10, 41, '    dummy 1   ', 10, 10, '10', 'Lahore', 'variable', '22.00', '20.00', 'products/Experts-Camp.png', 10, 5, 1717, '15%'),
(5, 'p2', 'yes', 0, '', '', '', 'b1', 'ready', 'r1', 10, 840, ' dummy ', 10, 5, '10', 'Lahore', 'variable', '100.00', '50.00', 'products/Experts-Camp.png', 10, 5, 1, ''),
(7, 'p3', 'Narcotics', 465, 'khajshd45', '09/09/21', '546a5sd', 'Manufacturer', 'Catagories', 'Sub-Catagories', 0, 501, '                      ', 0, 0, '', 'Loction', 'single', '0.00', '0.00', 'products/anime-that-will-put-you-to-sleep.webp', 0, 0, 500, ''),
(15, 'new product', 'Narcotics', 789, 'this,and', '', '', 'b1', 'ready', 'r1', 0, 1518, '  ', 0, 0, '', 'Loction', 'single', '10.00', '8.00', 'products/3edf3e7ee75e0e3b0b73cf7b17f7d94b.jpg', 0, 0, 2456, '5Rs'),
(16, 'new', 'Narcotics', 789, 'jaksd21', '2021-10-25', '', 'b1', 'ready', 'r1', 10, 99, 'THis is a new PRoduct', 1, 1, '1', 'Lahore', 'variable', '50.00', '45.00', 'products/download (1).jpg', 5, 5, 100, '2%'),
(17, 'np1', 'yes', 50, 'c3', '2021-12-01', '20', 'b3', 'c1', 'sc1', 25, 1, '  test product  ', 3, 3, '1', 'Gujranwala', 'single', '10.00', '5.00', 'products/3edf3e7ee75e0e3b0b73cf7b17f7d94b.jpg', 2, 1, 0, '3Rs'),
(18, 'p4', 'Narcotics', 100, 'adsa123', '2021-11-08', '50', 'b3', 'ready', 'r1', 10, 0, 'this is product number 4', 1, 2, '1', 'Lahore, Lahore', 'variable', '50.00', '45.00', 'products/anime-that-will-put-you-to-sleep.webp', 1, 1, 0, '5%');

-- --------------------------------------------------------

--
-- Table structure for table `products_detail`
--

CREATE TABLE `products_detail` (
  `id` int(11) NOT NULL,
  `supplier` varchar(255) NOT NULL,
  `bill_id` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `sub_total` decimal(10,2) NOT NULL,
  `discount_total` decimal(10,2) NOT NULL,
  `discount` int(11) NOT NULL,
  `grand_total` decimal(10,2) NOT NULL,
  `paid` decimal(10,2) NOT NULL,
  `remaining` decimal(10,2) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp(),
  `billmaker` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products_detail`
--

INSERT INTO `products_detail` (`id`, `supplier`, `bill_id`, `status`, `sub_total`, `discount_total`, `discount`, `grand_total`, `paid`, `remaining`, `date`, `billmaker`) VALUES
(112, 'Hashim', '20211022092631', 'returned', '500.00', '475.00', 0, '479.75', '0.00', '479.75', '2021-10-23', ''),
(113, 'Hashim', '20211022094145', 'returned', '456.00', '414.96', 0, '423.26', '0.00', '423.26', '2021-10-23', ''),
(115, 'Ali', '20211026093538', 'returned', '10.00', '9.50', 0, '9.50', '0.00', '9.50', '2021-10-26', ' Talha Ansari '),
(116, 'Ali', '20211026012257', 'paid', '495.00', '470.25', 0, '474.95', '121.00', '353.95', '2021-10-26', ' new` '),
(118, 'Talha Ansari', '20211027033045', 'paid', '45.00', '45.00', 0, '47.25', '0.00', '47.25', '2021-10-27', ' Talha Ansari '),
(119, 'Ali', '20211028100459', 'paid', '675.00', '675.00', 0, '675.00', '3.00', '672.00', '2021-10-28', ' Talha Ansari '),
(120, 'Ali', '20211030125453', 'unpaid', '18969.00', '18969.00', 0, '18969.00', '0.00', '18969.00', '2021-10-30', ' Talha Ansari '),
(122, 'Ali', '20211030010930', 'unpaid', '20650.00', '18585.00', 0, '19514.25', '0.00', '19514.25', '2021-10-30', ' Talha Ansari '),
(123, 'Talha Ansari', '20211030025341', 'unpaid', '137.00', '130.15', 0, '130.15', '0.00', '130.15', '2021-10-30', ' Talha Ansari '),
(125, 'Ali', '20211107104244', 'unpaid', '10000.00', '10000.00', 0, '10000.00', '0.00', '10000.00', '2021-11-07', 'Talha Ansari '),
(126, 'Ali', '20211107112904', 'returned', '50.00', '47.50', 0, '47.50', '0.00', '47.50', '2021-11-07', 'Talha Ansari '),
(127, 'Ali', '20211108071126', 'returned', '20.00', '20.00', 0, '20.00', '0.00', '20.00', '2021-11-08', 'Talha Ansari ');

-- --------------------------------------------------------

--
-- Table structure for table `return_sitems`
--

CREATE TABLE `return_sitems` (
  `id` int(11) NOT NULL,
  `customer` varchar(255) NOT NULL,
  `bill_id` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `item_name` varchar(255) NOT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp(),
  `total` decimal(10,2) NOT NULL,
  `batchno` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `return_sitems`
--

INSERT INTO `return_sitems` (`id`, `customer`, `bill_id`, `status`, `item_name`, `quantity`, `price`, `date`, `total`, `batchno`) VALUES
(1, 'Hashim Customer', '20211025025106', 'returned', 'p1', '1.00', '0.00', '2021-10-25', '0.00', ''),
(2, 'Hashim Customer', '20211025025106', 'returned', 'p1', '1.00', '0.00', '2021-10-25', '0.00', ''),
(3, 'Hashim Customer', '20211025025106', 'returned', 'p1', '1.00', '0.00', '2021-10-25', '0.00', ''),
(4, 'Hashim Customer', '20211025025106', 'returned', 'p1', '1.00', '0.00', '2021-10-25', '0.00', ''),
(5, 'Hashim Customer', '20211025025106', 'returned', 'p1', '1.00', '0.00', '2021-10-25', '0.00', ''),
(6, 'Hashim Customer', '20211025025106', 'returned', 'p1', '1.00', '0.00', '2021-10-25', '0.00', ''),
(7, 'Hashim Customer', '20211025025106', 'returned', 'p1', '1.00', '0.00', '2021-10-25', '0.00', ''),
(8, 'Hashim Customer', '20211025025106', 'returned', 'p1', '1.00', '0.00', '2021-10-25', '0.00', ''),
(9, 'Hashim Customer', '20211025025106', 'returned', 'p1', '1.00', '0.00', '2021-10-25', '0.00', ''),
(10, 'Hashim Customer', '20211025031124', 'returned', 'p1', '1.00', '0.00', '2021-10-25', '0.00', ''),
(11, 'Hashim Customer', '20211025031124', 'returned', 'p1', '1.00', '0.00', '2021-10-25', '0.00', ''),
(12, 'Hashim Customer', '20211025031124', 'returned', 'p1', '1.00', '0.00', '2021-10-25', '0.00', ''),
(13, 'Hashim Customer', '20211025031124', 'returned', 'p1', '1.00', '0.00', '2021-10-25', '0.00', ''),
(14, 'Hashim Customer', '20211025031757', 'returned', 'p1', '1.00', '0.00', '2021-10-25', '0.00', '');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(11) NOT NULL,
  `role_name` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `category` int(11) NOT NULL,
  `subcategory` int(11) NOT NULL,
  `product` int(11) NOT NULL,
  `sale` int(11) NOT NULL,
  `purchase` int(11) NOT NULL,
  `user_management` int(11) NOT NULL,
  `stock` int(11) NOT NULL,
  `dashboard` int(11) NOT NULL,
  `report` int(11) NOT NULL,
  `supplier` int(11) NOT NULL,
  `customer` int(11) NOT NULL,
  `projection` int(11) NOT NULL,
  `employee` int(11) NOT NULL,
  `status` varchar(10) COLLATE utf8mb4_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `role_name`, `category`, `subcategory`, `product`, `sale`, `purchase`, `user_management`, `stock`, `dashboard`, `report`, `supplier`, `customer`, `projection`, `employee`, `status`) VALUES
(30, 'Maneger', 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(31, 'NewGuy', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, ''),
(37, 'Admin', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, ''),
(40, 'Chashier', 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 'active');

-- --------------------------------------------------------

--
-- Table structure for table `rolesname`
--

CREATE TABLE `rolesname` (
  `id` int(11) NOT NULL,
  `role_name` varchar(255) COLLATE utf8mb4_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Dumping data for table `rolesname`
--

INSERT INTO `rolesname` (`id`, `role_name`) VALUES
(1, 'test'),
(2, 'test'),
(3, 'test'),
(4, 'check'),
(5, 'check'),
(6, 'check'),
(7, 'check'),
(8, 'pta ni'),
(9, 'pta ni'),
(10, 'pta ni'),
(11, 'pta ni'),
(12, 'Admin'),
(13, 'Maneger'),
(14, 'pta ni'),
(15, '1'),
(16, '1'),
(17, '1'),
(18, '1'),
(19, '1'),
(20, '1'),
(21, '1'),
(22, '1'),
(23, 'lkj'),
(24, 'lkj'),
(25, 'lkj'),
(26, 'lkj'),
(27, 'lkj'),
(28, 'pta ni'),
(29, 'Admin'),
(30, 'Chashier'),
(31, 'pta ni'),
(32, 'pta ni'),
(33, 'pta ni'),
(34, 'pta ni'),
(35, 'pta ni'),
(36, 'pta ni'),
(37, 'pta ni'),
(38, 'pta ni'),
(39, ''),
(40, 'pta ni'),
(41, ''),
(42, ''),
(43, 'pta ni'),
(44, ''),
(45, 'pta ni'),
(46, 'pta ni'),
(47, 'pta ni'),
(48, 'lkj'),
(49, 'Chashier');

-- --------------------------------------------------------

--
-- Table structure for table `sale_items`
--

CREATE TABLE `sale_items` (
  `id` int(11) NOT NULL,
  `customer` varchar(255) NOT NULL,
  `bill_id` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `item_name` varchar(255) NOT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `purchase_price` decimal(10,2) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp(),
  `total` decimal(10,2) NOT NULL,
  `batchno` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sale_items`
--

INSERT INTO `sale_items` (`id`, `customer`, `bill_id`, `status`, `item_name`, `quantity`, `price`, `purchase_price`, `date`, `total`, `batchno`) VALUES
(344, 'Hashim Customer', '20211101061640', '', 'p1', '1.00', '10.00', '0.00', '2021-01-01', '10.00', ''),
(345, 'Hashim Customer', '20211101061640', '', 'p2', '1.00', '100.00', '0.00', '2021-11-01', '100.00', ''),
(346, 'Hashim Customer', '20211101061640', '', 'new', '1.00', '50.00', '0.00', '2021-11-01', '50.00', 'jaksd21'),
(347, 'Hashim Customer', '20211101061830', '', 'p1', '1.00', '10.00', '0.00', '2021-11-30', '10.00', ''),
(351, 'Hashim Customer', '20211104030607', '', 'p3', '1.00', '0.00', '0.00', '2021-11-04', '0.00', 'khajshd45'),
(352, 'Hashim Customer', '20211104030607', '', 'p2', '1.00', '100.00', '0.00', '2021-11-04', '100.00', ''),
(353, 'Hashim Customer', '20211104030607', '', 'p1', '1.00', '10.00', '0.00', '2021-11-04', '10.00', ''),
(354, 'Hashim Customer', '20211104030607', '', 'np1', '5.00', '10.00', '0.00', '2021-11-04', '50.00', 'c3'),
(355, 'Hashim Customer', '20211105071243', '', 'p1', '1.00', '10.00', '0.00', '2021-11-05', '10.00', ''),
(356, 'Hashim Customer', '20211105105808', '', 'p2', '1.00', '100.00', '0.00', '2021-11-05', '100.00', ''),
(358, 'Hashim Customer', '20211105071849', '', 'p1', '1.00', '10.00', '0.00', '2021-11-05', '10.00', ''),
(359, 'Hashim Customer', '20211105071849', '', 'p1', '1.00', '10.00', '0.00', '2021-11-05', '10.00', ''),
(360, 'Hashim Customer', '20211106115450', '', 'p1', '1.00', '10.00', '0.00', '2021-11-06', '10.00', ''),
(364, 'Hashim Customer', '20211106115618', '', 'p2', '1.00', '100.00', '0.00', '2021-11-06', '100.00', ''),
(365, 'Hashim Customer', '20211106115618', '', 'p2', '1.00', '100.00', '0.00', '2021-11-06', '100.00', ''),
(381, 'Hashim Customer', '20211107105910', '', 'np1', '17.00', '10.00', '5.00', '2021-11-07', '170.00', 'c3'),
(382, 'Hashim Customer', '20211107105910', '', 'p1', '1.00', '10.00', '20.00', '2021-11-07', '10.00', ''),
(383, 'Hashim Customer', '20211107105910', '', 'new product', '15.00', '10.00', '8.00', '2021-11-07', '150.00', 'this'),
(384, 'Hashim Customer', '20211107112302', '', 'new product', '6.00', '10.00', '8.00', '2021-11-07', '60.00', 'this'),
(386, 'Hashim Customer', '20211108112827', '', 'p1', '6.00', '10.00', '20.00', '2021-11-08', '60.00', ''),
(387, 'Talha Ansari', '20211108010448', '', 'p1', '2.00', '22.00', '20.00', '2021-11-08', '44.00', '');

-- --------------------------------------------------------

--
-- Table structure for table `sale_product_details`
--

CREATE TABLE `sale_product_details` (
  `id` int(11) NOT NULL,
  `customer` varchar(255) NOT NULL,
  `bill_id` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `sub_total` decimal(10,2) NOT NULL,
  `discount_total` decimal(10,2) NOT NULL,
  `grand_total` decimal(10,2) NOT NULL,
  `paid` decimal(10,2) NOT NULL,
  `remaining` decimal(10,2) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp(),
  `billmaker` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sale_product_details`
--

INSERT INTO `sale_product_details` (`id`, `customer`, `bill_id`, `status`, `sub_total`, `discount_total`, `grand_total`, `paid`, `remaining`, `date`, `billmaker`) VALUES
(177, 'Hashim Customer', '20211101061640', 'unpaid', '160.00', '152.00', '159.60', '0.00', '159.60', '2021-01-01', 'Talha Ansari'),
(178, 'Hashim Customer', '20211101061830', 'unpaid', '10.00', '10.00', '10.00', '0.00', '10.00', '2020-11-01', 'Talha Ansari'),
(179, 'Hashim Customer', '20211104030607', 'paid', '160.00', '152.00', '152.00', '152.00', '0.00', '2021-11-04', 'Talha Ansari'),
(180, 'Hashim Customer', '20211105071243', 'unpaid', '10.00', '10.00', '10.00', '0.00', '10.00', '2021-11-06', 'Talha Ansari '),
(181, 'Hashim Customer', '20211105105808', 'unpaid', '100.00', '99.00', '103.95', '0.00', '103.95', '2021-11-06', 'new.1234 '),
(183, 'Hashim Customer', '20211105071849', 'unpaid', '20.00', '20.00', '25.00', '0.00', '25.00', '2021-11-06', 'Talha Ansari '),
(184, 'Hashim Customer', '20211106115450', 'unpaid', '10.00', '10.00', '10.00', '0.00', '10.00', '2021-11-06', 'new.1234'),
(185, 'Hashim Customer', '20211106115618', 'paid', '200.00', '200.00', '200.00', '0.00', '200.00', '2021-11-06', 'FreeGuy  '),
(186, 'Hashim Customer', '20211107105910', 'unpaid', '330.00', '313.50', '313.50', '0.00', '313.50', '2021-11-07', 'Talha Ansari '),
(187, 'Hashim Customer', '20211107112302', 'unpaid', '60.00', '60.00', '60.00', '0.00', '60.00', '2021-11-07', 'Talha Ansari '),
(188, 'Hashim Customer', '20211108112827', 'returned', '60.00', '57.00', '57.00', '0.00', '57.00', '2021-11-08', 'Talha Ansari '),
(189, 'Talha Ansari', '20211108010448', 'unpaid', '44.00', '44.00', '44.00', '0.00', '44.00', '2021-11-08', 'Talha Ansari ');

-- --------------------------------------------------------

--
-- Table structure for table `stock`
--

CREATE TABLE `stock` (
  `id` int(11) NOT NULL,
  `bill_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `supplier_name` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `product_name` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `quantity` varchar(255) COLLATE utf8mb4_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Dumping data for table `stock`
--

INSERT INTO `stock` (`id`, `bill_id`, `supplier_name`, `product_name`, `quantity`) VALUES
(90, '20211030125453', 'Ali', 'p1', '1736'),
(91, '20211030125453', 'Ali', 'new product', '2041'),
(95, '20211030023856', 'Ali', 'p3', '1'),
(96, '20211030025341', 'Talha Ansari', 'p1', '-8'),
(97, '20211030025341', 'Talha Ansari', 'p2', '-16'),
(98, '20211030025341', 'Talha Ansari', 'new product', '-30'),
(99, '20211101022807', 'Ali', '\n                        p1                    ', '23'),
(100, '20211104030502', 'Ali', 'p2', '-3');

-- --------------------------------------------------------

--
-- Table structure for table `subcategories`
--

CREATE TABLE `subcategories` (
  `id` int(11) NOT NULL,
  `sub` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Dumping data for table `subcategories`
--

INSERT INTO `subcategories` (`id`, `sub`, `name`, `status`) VALUES
(1, 'r1', 'ready', 'deactive'),
(2, 'raw1', 'raw', 'active'),
(6, 'sc1', 'c1', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE `supplier` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `profile` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `business_name` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `mobile` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `address` text COLLATE utf8mb4_bin NOT NULL,
  `licence_no` varchar(100) COLLATE utf8mb4_bin NOT NULL,
  `licence_exp` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`id`, `name`, `profile`, `business_name`, `mobile`, `email`, `address`, `licence_no`, `licence_exp`) VALUES
(3, 'Ali', 'supplier/men.jpg', 'ali business', '1133456', 'ali@gmail.com', 'lahore', '879645', '2022-01-10'),
(5, 'Hashim', 'supplier/men.jpg', 'hashim bb', '987456', 'hashim@gmail.com', 'Gujranwala', '879645', '2022-01-10'),
(9, 'Talha Ansari', 'supplier/download (1).jpg', 'KingStar', '03123456789', 'talhaprince09@gmail.com', 'Lahore', '879645', '2021-11-06'),
(10, 'Talha Ansari', 'supplier/download (1).jpg', 'KingStar', '03095235889', 'talhapr09@gmail.com', 'Lahore\r\nLahore', '879645', '2021-10-27'),
(11, 't1', 'supplier/anime-that-will-put-you-to-sleep.webp', 'pharmaD', '03021345678', 'test1@gmail.com', 'ydgf7ey3edgiyqerf9uedbvdbfrhdhhdu84rehoafydgtrdbhiafuhfiqe', '215403326', '2021-11-19'),
(12, 'Talha Ansari', 'supplier/c58bc5a3c3707acd1231e43989c47db68547ea8dr1-1200-831v2_hq.jpg', 'KingStar', '03095235889', 'ta@gmail.com', 'Lahore\r\nLahore', '879645', '2021-11-01');

-- --------------------------------------------------------

--
-- Table structure for table `units`
--

CREATE TABLE `units` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `unit` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `commission`
--
ALTER TABLE `commission`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `location`
--
ALTER TABLE `location`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products_detail`
--
ALTER TABLE `products_detail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `return_sitems`
--
ALTER TABLE `return_sitems`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rolesname`
--
ALTER TABLE `rolesname`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sale_items`
--
ALTER TABLE `sale_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sale_product_details`
--
ALTER TABLE `sale_product_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stock`
--
ALTER TABLE `stock`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subcategories`
--
ALTER TABLE `subcategories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `units`
--
ALTER TABLE `units`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `commission`
--
ALTER TABLE `commission`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `items`
--
ALTER TABLE `items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=320;

--
-- AUTO_INCREMENT for table `location`
--
ALTER TABLE `location`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `products_detail`
--
ALTER TABLE `products_detail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=128;

--
-- AUTO_INCREMENT for table `return_sitems`
--
ALTER TABLE `return_sitems`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `rolesname`
--
ALTER TABLE `rolesname`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `sale_items`
--
ALTER TABLE `sale_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=388;

--
-- AUTO_INCREMENT for table `sale_product_details`
--
ALTER TABLE `sale_product_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=190;

--
-- AUTO_INCREMENT for table `stock`
--
ALTER TABLE `stock`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;

--
-- AUTO_INCREMENT for table `subcategories`
--
ALTER TABLE `subcategories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `supplier`
--
ALTER TABLE `supplier`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `units`
--
ALTER TABLE `units`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
