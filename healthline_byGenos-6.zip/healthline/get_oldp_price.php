<?php

include_once "connection.php";

$name = $_POST['name'];
$pname =explode(',', $_POST['pname'])[0];
$result = $conn->query("SELECT * FROM items WHERE supplier='$name' and item_name = '$pname' ORDER BY date DESC LIMIT 1");
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
}





?>
<div class="col-lg-3">
    <!-- <label for="">This is product</label> -->
</div>
<div class="col-lg-3">
    <!-- <label for="">This is product</label> -->
</div>
<div class="col-lg-3 text-danger fw-bold">
    &nbsp;&nbsp;&nbsp; <label for=""><?php 
    if(isset($row['quantity'])){
        echo $row['quantity'];
    }else{
        echo "No Data";
    }
    ?></label>
</div>
<div class="col-lg-3 text-danger fw-bold">
    <label for="">Rs.<?php 
    if(isset($row['price'])){
        echo $row['price'];
    }else{
        echo "No Data";
    }
    ?></label>
</div>