<?php
define("TITLE", "Users");
define("PAGE", "Users");
include 'connection.php';
include 'header.php';







?>


<div class="body-section">
  <div class="container">

    <!-- msg -->
    <?php
    if (isset($_GET["msg"])) {
      if ($_GET["msg"] == "Paid") {
    ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
          <strong><?php echo $_GET["msg"] ?></strong> Successfully
          <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>

      <?php
      } else {
      ?>

        <div class="alert alert-danger alert-dismissible fade show" role="alert">
          <strong><?php echo $_GET["msg"] ?></strong> Please Recheck The Amount.
          <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php
      }
    }
    ?>

    <div class="card">
      <div class="card-header border-0">
        <h3 class="card-title">Employee Commission</h3>
        <hr>

        <div class="card-body table-responsive p-0">
          <div class="row">
            <div class="col-lg-12">
              <table id="table" class="table pt-2">

                <thead class="table-dark">
                  <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Commission</th>
                    <th>From</th>
                    <th>To</th>
                    <th>Action</th>
                    <!-- <th>Operations</th> -->
                  </tr>
                </thead>
                <tbody>
                  <?php
                  $result = $conn->query("SELECT commission.*,login.email FROM `commission`, login WHERE commission.emp_name=login.name and commission.emp_name!='SuperUser'");
                  while ($row = $result->fetch_assoc()) {
                  ?>
                    <!-- <form action=""> -->
                    <tr>
                      <td><?php echo $row['id'] ?></td>
                      <td><?php echo $row['emp_name'] ?> </td>

                      <td><?php echo $row['email'] ?></td>
                      <td><?php echo intval($row['amount']) ?> .Rs</td>
                      <td><?php echo $row['date'] ?></td>
                      <td><?php echo $row['lastupdate'] ?></td>
                      <td>
                        <button class="btn btn-primary editbtn" data-bs-toggle="modal" data-bs-target="#paycommission" data-sid="<?php echo $row['id'] ?>">
                          <i class="fas fa-donate"></i>
                        </button>
                      </td>



                      <!-- <td>
                          <button type="submit" class="btn btn-sm btn-danger" name="" data-bs-toggle="modal" data-bs-target="#myModalDelete">Delete</button>

                          <button type="button" data-bs-toggle="modal" data-bs-target="#myModalEdit" class="btn btn-success btn-sm editbtn">Edit</button>
                        </td> -->
                    </tr>
                    <!-- </form> -->
                  <?php
                  }
                  ?>

                </tbody>

              </table>
            </div>
          </div>


        </div>



      </div>
      <!-- flex-item -->
    </div>
    <!-- /flex-container -->
    <div class="modal fade" id="paycommission" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Employee Commission</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <div class="container mt-1">


              <div class="row mt-3">
                <form action="employee.php" method="POST">
                  <div class="form-group">
                    <input type="hidden" id="emp_id" name="emp_id">
                    <label class="fw-bold">Total Commission:</label>
                    <input type="text" class="form-control mb-2" readonly name='totalcommission' id="emp_com">
                    <label class="fw-bold">Payment:</label><br>
                    <input type="text" min="1" pattern="[0-9]+" class="form-control mb-2" placeholder="Amount" name="amount">

                  </div>


              </div>


              <div class="row mt-3 mb-3">
                <div class="col-lg-4">

                </div>
                <div class="col-lg-4 ">
                  <input type="submit" class="form-control btn btn-success" onclick="return confirm('Are You Sure')" name="save" value="PayNow">
                </div>
                <div class="col-lg-4">

                </div>

              </div>
              </form>


            </div>

            </from>
          </div>

        </div>

      </div>
    </div>
  </div>
</div>




<script>
  $(document).ready(function() {
    $('.editbtn').on('click', function() {
      $('#paycommission').modal('show');

      $tr = $(this).closest('tr');

      var data = $tr.children('td').map(function() {
        return $(this).text();
      }).get();

      console.log(data);
      $('#emp_id').val(data[0]);
      $('#emp_com').val(data[3].split('.')[0]);


    });
  });
</script>




<?php


include 'footer.php';

if (isset($_POST["save"])) {
  $id = $_POST["emp_id"];
  $emp_com = floatval($_POST["totalcommission"]);
  $amount = floatval($_POST["amount"]);
  echo $amount;
  echo $emp_com;
  if ($amount <= $emp_com) {
    $conn->query("UPDATE commission Set amount=amount-'$amount', date=date(now()),lastupdate=date(now()) Where id='$id'");
    echo "<script>window.location='employee.php?msg=Paid'</script>";
  } else {
    echo "<script>window.location='employee.php?msg=Amount-is-Greater'</script>";
  }
}


?>