<?php
include("connection.php");


if(isset($_GET["id"])){

    $qty =$_GET['qty'];
    $name = $_GET["name"];
    $sql = "DELETE FROM sale_items WHERE id=".$_GET["id"];
    $conn->query($sql);
    $conn->query("UPDATE product SET opening_stock = opening_stock +'$qty' WHERE product_name='$name'");
    $conn->query("UPDATE stock SET quantity = quantity +'$qty' WHERE product_name='$name'");
    echo "<script>window.location = 'sale.php?ed_rc=".$_GET["bill_no"]."'</script>";
}


?>