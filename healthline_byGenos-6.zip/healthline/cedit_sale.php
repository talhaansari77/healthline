<?php
include_once "connection.php";

if (isset($_POST["submit"])) {
    // echo var_dump($_POST);

    $product = $_POST["product_name"];
    $qty = intval($_POST["qty"]);
    $price = floatval($_POST["price"]);
    $Totalprice = $qty * $price;


    $sql = "UPDATE sale_items SET `item_name` = '$product', `price`= '$price', `quantity`='$qty', `total`='$Totalprice' WHERE id = " . $_POST["bill_id"];
    $conn->query($sql);


    echo "<script>window.location='extra.php?bill_no=".$_POST["bill_no"]."'</script>";
    
}


if (isset($_POST["detail_submit"])) {
    // echo var_dump($_POST);

    $bill_no = floatval($_POST["bill_no"]);
    $subtotal = floatval($_POST["subtotal"]);
    $distotal = floatval($_POST["distotal"]);
    $grandtotal = floatval($_POST["grandtotal"]);
    $status = $_POST["status"];
    $paid = floatval($_POST["paid"]);
    $remaining = $grandtotal - $paid;

if($distotal != null && $grandtotal != null){
    $sql = "UPDATE sale_product_details SET `status` = '$status', `sub_total`= '$subtotal', `discount_total`='$distotal', `grand_total`='$grandtotal' , `paid`='$paid' , `remaining`='$remaining' WHERE bill_id = " . $bill_no;
    $conn->query($sql);
}else{
    echo "<script>window.location='extra.php?bill_no=".$_POST["bill_no"]."'</script>";
}
    


    echo "<script>window.location='sale.php?'</script>";
    
}
