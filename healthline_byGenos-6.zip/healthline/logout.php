<?php

session_start();

include_once 'connection.php';

// salecommission
$userCommission = 0;
$usernameforcom = $_SESSION['username'];
$result = $conn->query("SELECT SUM(sale_items.quantity) as quantity ,sale_product_details.billmaker, product.* FROM `sale_product_details`, product, sale_items WHERE sale_items.bill_id=sale_product_details.bill_id AND product.product_name=sale_items.item_name AND sale_product_details.billmaker='$usernameforcom' GROUP BY product.product_name");
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        if ($row["comission"]) {
            if (strpos($row["comission"], "%")) {
                // echo $row["quantity"] ;
                $userCommission += $row["quantity"] * ($row["selling_price"] / 100 * explode('%', $row["comission"])[0]);
            } else if (strpos($row["comission"], "Rs")) {
                $userCommission += $row["quantity"] * explode('Rs', $row["comission"])[0];
                // echo $userCommission;
            }
        }
    }
}

// echo $userCommission;
$result = $conn->query(("SELECT * FROM commission where emp_name = '$usernameforcom'"));
if ($result->num_rows > 0) {
    // update
    $conn->query(("UPDATE commission SET amount='$userCommission',`lastupdate`=date(now()) where emp_name='$usernameforcom'"));
} else {
    // insert
    $conn->query(("INSERT into commission(amount,emp_name) VALUE('$userCommission','$usernameforcom')"));
}








// 
session_destroy();
header('location:login.php');
