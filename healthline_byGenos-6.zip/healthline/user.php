<?php
define("TITLE", "User Managements");
define("PAGE", "User Managements");

include 'header.php';
include 'connection.php';



if (isset($_POST["delete"])) {
  $conn->query("DELETE FROM `login` WHERE id=" . $_POST["del_user_id"]);
  echo "<script>window.location = 'user.php?deleted'</script>";
}

if (isset($_POST["edituser"])) {
  $id = $_POST['update_id'];
  $name = $_POST['uname'];
  $email = $_POST['ename'];
  $password = $_POST['password'];
  $phone = $_POST['contact'];
  $address = $_POST['address'];
  // $rolename = $_POST['rolename'];


  $conn->query("UPDATE `login` SET `name`='$name', `email`='$email', `password`='$password', `phone`='$phone', `address`= '$address' WHERE id = $id");
  echo "<script>window.location = 'user.php?Updated'</script>";
}

?>


<div class="body-section">
  <div class="container">
    <div class="card">
      <div class="card-header border-0">
        <h3 class="card-title">User Managements</h3>
        <hr>
        <div class="container mt-1">
          <!-- Button trigger modal -->



          <div class="card-body table-responsive p-0">
            <div class="row">
              <div class="col-lg-12">
                <table id="table" class="table table-striped  pt-3">

                  <thead class="table-dark">
                    <tr>
                      <th>#</th>
                      <th>Name</th>
                      <!-- <th>User Name</th> -->
                      <th>Password</th>
                      <th>E-mail</th>
                      <th>Contact</th>
                      <th> Address</th>
                      <th> Role</th>

                      <th>Operations</th>
                    </tr>
                  </thead>
                  <tbody>

                    <?php
                    $result = $conn->query("SELECT * FROM `login` where `email`!='super@test.com'");
                    while ($row = $result->fetch_assoc()) {
                    ?>
                      <form action="user.php" method="POST">
                        <input type="hidden" value="<?php echo $row['id'] ?>" name="userid">
                        <tr>
                          <td><?php echo $row['id'] ?></td>
                          <td><?php echo $row['name'] ?> </td>

                          <!-- <td>hm8646451</td> -->
                          <td style="filter: blur(4px);-webkit-user-select: none; /* Safari */-moz-user-select: none; /* Firefox */-ms-user-select: none; /* IE10+/Edge */user-select: none; /* Standard */"><?php echo $row['password'] ?></td>
                          <td><?php echo $row['email'] ?></td>
                          <td><?php echo $row['phone'] ?></td>
                          <td><?php echo $row['address'] ?></td>



                          <td>
                            <select name="role_name" id="role_name" class="form-select">
                              <!-- <optgroup label="Select Role"> -->
                              <option label="Select Role"></option>
                              <?php
                              $result1 = $conn->query("SELECT * FROM `roles`");
                              while ($row1 = $result1->fetch_assoc()) {
                              ?>

                                <option value="<?php echo $row1['id'] . "," . $row['id'] ?>" <?php if ($row1['id'] == $row['role']) echo "selected" ?>>
                                  <?php echo $row1['role_name'] ?>
                                </option>


                              <?php
                              }
                              ?>
                              <!-- </optgroup> -->
                            </select>
                          </td>

                          <td>
                            <button type="submit" class="btn btn-sm btn-danger" id="deleteuser" data-sid="<?php echo $row['id'] ?>" name="" data-bs-toggle="modal" data-bs-target="#myModalDelete"><i class="fas fa-trash"></i></button>

                            <button type="button" data-bs-toggle="modal" data-bs-target="#myModalEdit" class="btn btn-success btn-sm editbtn"><i class="fas fa-edit"></i></button>
                            <a href="commissiondetail.php?username=<?php echo $row['name']?>" class="btn btn-primary btn-sm"><i class="fas fa-coin"></i></a>
                          </td>
                        </tr>
                      </form>
                    <?php
                    }
                    ?>




                  </tbody>
                </table>
              </div>
            </div>


            <!-- <div class="row mt-2">
              <div class="col-lg-4">
                <p>Showing 1 to 5 of 5 entries</p>
              </div>
              <div class="col-lg-8">
                <nav aria-label="Page navigation example">
                  <ul class="pagination">
                    <li class="page-item"><a class="page-link" href="#">Previous</a></li>
                    <li class="page-item"><a class="page-link" href="#">1</a></li>
                    <li class="page-item"><a class="page-link" href="#">2</a></li>
                    <li class="page-item"><a class="page-link" href="#">3</a></li>
                    <li class="page-item"><a class="page-link" href="#">Next</a></li>
                  </ul>
                </nav>
              </div>
            </div> -->
          </div>
        </div>




      </div>
      <!-- flex-item -->
    </div>
    <!-- /flex-container -->
  </div>
</div>
<!-- flex-item -->
</div>
<!-- /flex-container -->
</div>
</div>

<!-- ============================================================== -->
<!-- End Container fluid  -->
<!-- ============================================================== -->
</div>
<!-- ============================================================== -->
<!-- End Page wrapper  -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- footer -->
<!-- ============================================================== -->
<!--  <footer class="footer fixed">
            © 2020 Elegent Admin by <a href="https://www.wrappixel.com/">wrappixel.com</a>
        </footer> -->
<!-- ============================================================== -->
<!-- End footer -->
<!-- ============================================================== -->
</div>
<!-- ============================================================== -->
<!-- End Wrapper -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<div class="modal fade" id="myModalEdit" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Edit User Management</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="container">


          <form action="user.php" method="POST">
            <input type="hidden" name="update_id" id="update_id" />
            <div class="form-group">
              <!-- <label class="form-label" for="pname">Name</label>
              <input type="text" class="form-control" placeholder=" Name" name="pname" id="pname"> -->
              <label class="form-label" for="uname">User Name</label>
              <input type="text" class="form-control" placeholder="User Name" name="uname" id="uname">
              <label class="form-label" for="password">Password</label>

              <div class="row">
                <div class="col-11">
                  <input type="password" class="form-control" name="password" autocomplete="current-password" required="" id="id_password">

                </div>
                <div class="col-1 bg-success text-light rounded-circle">
                  <i class="far fa-eye" id="togglePassword" style="margin-top: 0.8rem; cursor: pointer;"></i>

                </div>



              </div>

              <label class="form-label" for="ename">E-mail</label>
              <input type="e-mail" class="form-control" placeholder="E-mail" name="ename" id="ename">
              <label class="form-label" for="contact">Contact</label>
              <input type="text" class="form-control" placeholder="Contact" name="contact" id="contact">
              <label class="form-label" for="address">Address</label>
              <textarea class="form-control" placeholder="Address" name="address" id="address"></textarea>
              <!-- 
              <label class="form-label" for="">Role</label>
              <input type="text" class="form-control" placeholder="Role" name="rolenamem" id="rolenamem"> -->


            </div>




        </div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" name="edituser" class="btn " id="button-addon2">Edit</button>
      </div>
      </form>
    </div>
  </div>
</div>

<!--delete-->
<div class="modal fade" id="myModalDelete" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Delete Supplier</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="container">
          <form action="user.php" method="POST">
            <input type="hidden" id="del_user_id" name="del_user_id" value="">
            <p>Are you sure want to delete the record?</p>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
              <button type="submit" name="delete" class="btn btn-success">Yes</button>
            </div>
          </form>
        </div>

      </div>

    </div>
  </div>
</div>




</div>






<?php


include 'footer.php';

?>

<script>
  $(document).on("click", "#deleteuser", function() {

    let id = $(this).data('sid');
    console.log(id);
    $("#del_user_id").val(id);

  });

  $(document).ready(function() {
    $('.editbtn').on('click', function() {
      $('#myModalEdit').modal('show');

      $tr = $(this).closest('tr');

      var data = $tr.children('td').map(function() {
        return $(this).text();
      }).get();

      console.log(data);
      $('#update_id').val(data[0]);
      $('#uname').val(data[1]);
      $('#id_password').val(data[2]);
      $('#ename').val(data[3]);
      $('#contact').val(data[4]);
      $('#address').val(data[5]);
    });
  });

  $(document).on("change", "#role_name", function() {
    var rolid = $(this).find(":selected").val();

    console.log(rolid);
    $.ajax({
      url: "changeuserrole.php",
      type: "POST",
      data: {
        rolid: rolid
      },
      success: function(data) {
        // console.log(data);
      }
    });
  });


  const togglePassword = document.querySelector('#togglePassword');
  const password = document.querySelector('#id_password');

  togglePassword.addEventListener('click', function(e) {
    // toggle the type attribute
    const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
    password.setAttribute('type', type);
    // toggle the eye slash icon
    this.classList.toggle('fa-eye-slash');
  });
</script>