<?php
include_once "connection.php";

if(isset($_POST["submit"])){


    $pname = $_POST["pname"];
    $qty = $_POST["pqty"];
    $price = floatval( $_POST["pprice"]);
    $item_id = $_POST["id"];
    $bill_no = $_POST["bill_no"];
    $total = $qty * $price;

    $sql = "UPDATE sale_items set item_name='$pname', quantity='$qty', price='$price', total='$total' WHERE id=".$item_id;
    $conn->query($sql);

    echo "<script>window.location = 'sale.php?ed_rc=".$bill_no."'</script>";
}


?>