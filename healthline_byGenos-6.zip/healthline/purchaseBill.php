<?php
include_once "connection.php";
$from = $_GET["from"];
$to = $_GET["to"];
?>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Purchase Bill</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
</head>

<body>


    <table class="table ">
        <tr>
            <th>
                <h1>
                    <center>Health Line : Pharmacy</center>
                </h1>
            </th>
        </tr>
        <tr>
            <th>
                <center>
                    Detailed Purchased Report
                </center>
            </th>
        </tr>
        <tr>
            <th>
                <center>
                    From: <?php echo $from ?>
                    &nbsp;&nbsp;
                    To: <?php echo $to ?>
                </center>
            </th>
        </tr>


    </table>
    <table class="table table-bordered">
        <tr>
            <!-- <td></td> -->
            <th>No#</th>
            <!-- <th>Product</th> -->
            <th>Name</th>
            <th>Total</th>
            <th>Paid</th>
            <th>Unpaid</th>
            <th>Date</th>
        </tr>
        <?php
        $total = 0;
        $paid = 0;
        $remains = 0;

        $result = $conn->query("SELECT * FROM `products_detail` WHERE date BETWEEN '$from' AND '$to' and `status` != 'returned'");
        while ($row = $result->fetch_assoc()) {
            $total += floatval($row["grand_total"]);
            $paid += floatval($row["paid"]);
            $remains += floatval($row["remaining"]);
        ?>
            <tr>
                <td> <?php echo $row["id"] ?> </td>
                <!-- <td> <?php echo $row["item_name"] ?> </td> -->
                <td> <?php echo $row["supplier"] ?> </td>
                <td> <?php echo $row["grand_total"] ?> </td>
                <td> <?php echo $row["paid"] ?> </td>
                <td> <?php echo $row["remaining"] ?> </td>
                <td> <?php echo $row["date"] ?> </td>

            </tr>
        <?php
        }
        ?>

    </table>
    <table class="table table-bordered">
        <tr>
            <th>
                <center>
                    Total Purchase: <?php echo $total ?> &nbsp;&nbsp;&nbsp;
                    Paid: <?php echo $paid ?> &nbsp;&nbsp;&nbsp;
                    Remaining: <?php echo $remains ?> &nbsp;&nbsp;&nbsp;
                </center>
            </th>
        </tr>
    </table>
</body>

</html>

<script>
    window.print();
</script>