<?php
define("TITLE", "Users");
define("PAGE", "Users");
include 'connection.php';
include 'header.php';

if (isset($_POST['add'])) {
  $fname = $_POST['fname'];
  $lname = $_POST['lname'];
  $newuser = $fname . $lname;
  $email = $_POST['email'];
  $password = $_POST['password'];
  $role = $_POST['role'];
  $phone = $_POST['phone'];
  $cnic = $_POST['cnic'];
  $address = $_POST['address'];

  $result1 = $conn->query("SELECT * FROM `login` WHERE `name`='$newuser' OR `email`='$email'");
  if ($result1->num_rows > 0) {
    echo "<script>window.location='user1.php?msg=userExist'</script>";
  } else {
    if ($fname != null && $lname != null && $email != null && $password != null) {
      $result = mysqli_query($conn, "INSERT INTO `login` (`name`,email, `password`, `role`, `phone`, `address`,`cnic`) 
      values('$newuser','$email', '$password', '$role','$phone', '$address','$cnic')");
    } else {
      echo "<script>window.location = 'user1.php?msg=no'</script>";
    }
  }



  if ($result) {
?>
    <script>
      window.location = "<?php echo $app_url . '/user.php' ?>";
    </script>

<?php
  }
}


?>

<div class="body-section">
  <div class="container">
    <div class="card">
      <div class="card-header border-0">
        <h3 class="card-title">Users</h3>
        <hr>
        <div class="container mt-1">
          <!-- Button trigger modal -->
          <div class="row">
            <div class="col-lg-9">
            </div>
            <div class="col-lg-3">


              <button type="button" id="button-addon2" data-bs-toggle="modal" data-bs-target="#exampleModal" class="btn btn-lg float-right mb-3">
                <i class="fas fa-plus"></i> Add User
              </button>
              <!--Modal-->
              <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                  <div class="modal-content">
                    <div class="modal-header bg-light">
                      <h4 class="modal-title " id="exampleModalLabel">User Detail</h4>
                      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      </button>
                    </div>
                    <div class="modal-body">
                      <form action="user1.php" method="POST">
                        <table>
                          <tr>
                            <td>
                              <div class="form-group">
                                <label class="form-label">First Name</label>
                                <input type="text" class="form-control" placeholder="First Name" name="fname" required>
                              </div>
                            </td>
                            <td>
                              <div class="form-group">
                                <label class="form-label">Last Name</label>
                                <input type="text" class="form-control" placeholder="Last Name" name="lname" required>
                              </div>
                            </td>
                          </tr>
                          <tr>
                            <td>
                              <div class="form-group mt-3">
                                <label class="form-label">Email</label>
                                <input type="email" class="form-control" placeholder="Email" name="email" required>
                              </div>
                            </td>

                            <td>
                              <div class="form-group mt-3">
                                <label class="form-label">Password</label>
                                <input type="password" class="form-control" placeholder="Password" name="password" required>
                              </div>
                            </td>


                          </tr>
                          <tr>
                            <td>
                              <div class="form-group mt-3">
                                <label class="form-label">Phone</label>
                                <input type="text" class="form-control" placeholder="03*********" name="phone" required>
                              </div>
                            </td>

                            <td>
                              <div class="form-group mt-3">
                                <label class="form-label">Role</label><br>
                                <select name="role" class="form-control">
                                  <optgroup label="Select Role">


                                    <?php
                                    $query = mysqli_query($conn, 'select * from roles group by role_name');
                                    while ($row = mysqli_fetch_assoc($query)) {

                                    ?>
                                      <option value="<?php echo $row['id'] ?>"><?php echo $row['role_name'] ?></option>

                                    <?php } ?>
                                  </optgroup>
                                </select>

                              </div>
                            </td>


                          </tr>
                          <tr>
                          <td colspan="2">
                          <label class="fw-bold">CNIC</label><br>
                          <input type="text" class="form-control mb-2" pattern="^[0-9+]{5}-[0-9+]{7}-[0-9]{1}$" required placeholder="xxxxx-xxxxxxx-x" name="cnic">
                          
                          </td>
                          </tr>
                          <tr>
                            <td colspan="2">
                              <div class="form-group mt-3">
                                <label class="form-label">Address</label>
                                <textarea class="form-control" placeholder="Address" name="address" required></textarea>
                              </div>
                            </td>
                          </tr>
                          
                        </table>



                        <div class="modal-footer">
                          <button type="submit" class="btn" id="button-addon2" name="add">Add</button>
                        </div>
                      </form>
                    </div>

                  </div>
                </div>
              </div>

            </div>
          </div>


          <div class="card-body table-responsive p-0">
            <div class="row">
              <div class="col-lg-12">
                <table id="table" class="table pt-2">

                  <thead class="table-dark">
                    <tr>
                      <th>#</th>
                      <th>Name</th>
                      <th>Email</th>
                      <th>Role</th>
                      <!-- <th>Operations</th> -->
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                    $result = $conn->query("SELECT *, `roles`.`role_name` AS role_name FROM `login`INNER JOIN `roles` ON `login`.`role` =`roles`.`id` where `email`!='super@test.com'");
                    while ($row = $result->fetch_assoc()) {
                    ?>
                      <!-- <form action=""> -->
                      <tr>
                        <td><?php echo $row['id'] ?></td>
                        <td><?php echo $row['name'] ?> </td>

                        <!-- <td>hm8646451</td> -->
                        <!-- <td>.......</td> -->
                        <td><?php echo $row['email'] ?></td>
                        <td><?php echo $row['role_name'] ?></td>





                        <!-- <td>
                          <button type="submit" class="btn btn-sm btn-danger" name="" data-bs-toggle="modal" data-bs-target="#myModalDelete">Delete</button>

                          <button type="button" data-bs-toggle="modal" data-bs-target="#myModalEdit" class="btn btn-success btn-sm editbtn">Edit</button>
                        </td> -->
                      </tr>
                      <!-- </form> -->
                    <?php
                    }
                    ?>

                  </tbody>

                </table>
              </div>
            </div>


          </div>
        </div>




      </div>
      <!-- flex-item -->
    </div>
    <!-- /flex-container -->
  </div>
</div>

<!-- Edit Modal -->
<div class="modal fade" id="myModalEdit" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Edit Category</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form method="POST">
          <input type="hidden" name="update_id" id="update_id">
          <div class="mb-3">
            <label for="name" class="form-label">Category Name</label>
            <input type="text" class="form-control" name="name" id="name">

          </div>
          <div class="form-group">
            <label class="form-label">Status</label><br>
            <select name="status" id="status" class="form-control">
              <option value="active">Active</option>
              <option value="deactive">Deactive</option>
            </select>
          </div>

          <button type="submit" class="btn btn-success mt-2 float-end" name="edit">Edit</button>
        </form>
      </div>

    </div>
  </div>
</div>
<!-- Edit Modal END -->
<!--delete-->
<script>
  $(document).ready(function() {
    $(".delete_btn_ajax").click(function(e) {
      e.preventDefault();
      var deleteid = $(this).closest('tr').find('.delete_id_value').val();
      // alert(deleteid);
      swal({
          title: "Are you sure?",
          text: "Once deleted, you will not be able to recover this Data!",
          icon: "warning",
          buttons: true,
          dangerMode: true,
        })
        .then((willDelete) => {
          if (willDelete) {
            $.ajax({
              type: "POST",
              url: "deletecategory.php",
              data: {
                "delete_btn_set": 1,
                "deleteid": deleteid,
              },
              success: function(response) {
                swal("Deleted!", "Your Data is Deleted", "success", {
                  button: "Ok!",
                }).then((result) => {
                  location.reload();
                });

              }
            });
          }
        });

    });
  });
</script>





</div>







<script>
  $(document).ready(function() {
    $('.editbtn').on('click', function() {
      $('#myModalEdit').modal('show');

      $tr = $(this).closest('tr');

      var data = $tr.children('td').map(function() {
        return $(this).text();
      }).get();

      console.log(data);
      $('#update_id').val(data[0]);
      $('#name').val(data[1]);
      $('#status').val(data[2]);
    });
  });
</script>




<?php


include 'footer.php';



//edit
if (isset($_POST['edit'])) {
  $id = $_POST['update_id'];
  $name = $_POST['name'];
  $status = $_POST['status'];
  $updatequery = "update categories set name='$name', status='$status' where id='$id'";
  $uquery = mysqli_query($conn, $updatequery);
  if ($uquery) {
?>
    <script>
      window.location = "<?php echo $app_url . '/cat.php' ?>";
    </script>

  <?php
  } else {
  ?>
    <script>
      alert('Update Failed');
    </script>

<?php
  }
}

?>