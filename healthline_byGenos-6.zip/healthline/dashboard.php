<?php
// session_start();
// if(!isset($_SESSION['email'])){
//   header('location:login.php');
//  }
define("TITLE", "Dashboard");
define("PAGE", "Dashboard");
include 'connection.php';
include 'header.php';






// salecommission
$userCommission = 0;
$usernameforcom = $_SESSION['username'];
$result = $conn->query("SELECT SUM(sale_items.quantity) as quantity ,sale_product_details.billmaker, product.* FROM `sale_product_details`, product, sale_items WHERE sale_items.bill_id=sale_product_details.bill_id AND product.product_name=sale_items.item_name AND sale_product_details.billmaker='$usernameforcom' GROUP BY product.product_name");
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        if ($row["comission"]) {
            if (strpos($row["comission"], "%")) {
                // echo $row["quantity"] ;
                $userCommission += $row["quantity"] * ($row["selling_price"] / 100 * explode('%', $row["comission"])[0]);
            } else if (strpos($row["comission"], "Rs")) {
                $userCommission += $row["quantity"] * explode('Rs', $row["comission"])[0];
                // echo $userCommission;
            }
        }
    }
}

// echo $userCommission;
$result = $conn->query(("SELECT * FROM commission where emp_name = '$usernameforcom'"));
if ($result->num_rows > 0) {
    // update
    $conn->query(("UPDATE commission SET amount='$userCommission',`lastupdate`=date(now()) where emp_name='$usernameforcom'"));
} else {
    // insert
    $conn->query(("INSERT into commission(amount,emp_name) VALUE('$userCommission','$usernameforcom')"));
}








// 








if (isset($_POST["save"])) {
    $uid = $_SESSION['email'];
    $name = $_POST["uname"];
    $email = $_POST["email"];
    $phone = $_POST["ph"];
    $password = $_POST["password"];
    $address = $_POST["address"];


    if ($name != null && $email != null && $password) {
        $conn->query("UPDATE `login` SET `name`='$name', `email`='$email', `phone`='$phone', `password`='$password', `address`='$address' WHERE `email`='$uid'");
        session_destroy();
        echo "<script>window.location= 'dashboard.php?msg=update'</script>";
    }
}

?>
<style>
    .mm {
        margin-top: 150px;
    }

    .mn {
        margin-top: -40px;
    }
</style>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.6.0/Chart.min.js"></script>




<div class="body-section">
    <div class="container ">
        <div class="card mm">
            <div class="card-header border-0">
                <h3 class="card-title">Dashboard</h3>
                <!-- Button trigger modal -->


                <div class="container mt-1">



                    <hr>
                    <div class="card-body table-responsive ">
                        <div class="row">

                            <div class="col-md-4 mt-2">
                                <div class="p-3 bg-white shadow-sm d-flex justify-content-around align-items-center rounded" style="color:#00A54F">
                                    <div>
                                        <?php
                                        $date = date('y-m-d');
                                        $query = mysqli_query($conn, "select * from sale_items where date='$date'");
                                        $totalSale = 0;
                                        while ($row = mysqli_fetch_assoc($query)) {
                                            $quantity = $row['quantity'];
                                            $sale = $row['price'];
                                            $sale_final = $sale * $quantity;
                                            $totalSale = $totalSale + $sale_final;
                                        }

                                        ?>
                                        <h3 class="fs-2"><?php if ($totalSale) {
                                                                echo $totalSale;
                                                            } else {
                                                                echo '0';
                                                            } ?></h3>
                                        <p class="fs-5">Daily Sale</p>
                                    </div>
                                    <i class="fas fa-dollar-sign fs-1  border-rounded-full p-3"></i>
                                </div>
                            </div>

                            <div class="col-md-4 mt-2">
                                <div class="p-3 bg-white shadow-sm d-flex justify-content-around align-items-center rounded" style="color:#00A54F">
                                    <div>
                                        <?php
                                        $date = date('y-m-d');
                                        $queryp = mysqli_query($conn, "select * from items where date='$date'");
                                        $totalPurchase = 0;
                                        while ($rowp = mysqli_fetch_assoc($queryp)) {
                                            $quantity = $rowp['quantity'];
                                            $purchase = $rowp['price'];
                                            $purchase_final = $purchase * $quantity;
                                            $totalPurchase = $totalPurchase + $purchase_final;
                                        }

                                        ?>
                                        <h3 class="fs-2"><?php if ($totalPurchase) {
                                                                echo $totalPurchase;
                                                            } else {
                                                                echo '0';
                                                            } ?></h3>
                                        <p class="fs-5">Daily Purchase</p>
                                    </div>
                                    <i class="fas fa-search-dollar fs-1  border-rounded-full p-3"></i>
                                </div>
                            </div>

                            <div class="col-md-4 mt-2">
                                <div class="p-3 bg-white shadow-sm d-flex justify-content-around align-items-center rounded" style="color:#00A54F">
                                    <div>
                                        <?php

                                        $date = date('y-m-d');
                                        $currentprofitis=0;
                                        $currentprofit = $conn->query("SELECT *, sum((sale_items.price-sale_items.purchase_price)*sale_items.quantity) as profit FROM `sale_items` where date='$date' GROUP by item_name");

                                        if ($currentprofit->num_rows > 0) {
                                           while($row = $currentprofit->fetch_assoc()){
                                                $currentprofitis += $row['profit'];
                                           }
                                          
                                        }

                                        ?>
                                        <h3 class="fs-2">
                                            <?php if ($currentprofitis) {
                                                echo intval($currentprofitis);
                                            } else {
                                                echo '0';
                                            } ?>
                                        </h3>
                                        <p class="fs-5">Daily Profit</p>
                                    </div>
                                    <i class="fas fa-hand-holding-usd fs-1  border-rounded-full p-3"></i>
                                </div>
                            </div>
                            <!-- the chart -->




                        </div>
                    </div>

                    <div class="container">

                        <center>
                            <canvas id="myChart"></canvas>
                        </center>

                    </div>


                </div>




            </div>
            <!-- flex-item -->
        </div>
        <!-- /flex-container -->
    </div>
</div>
<!-- flex-item -->
</div>
<!-- /flex-container -->
</div>
</div>

</div>

</div>




</div>




<?php
include 'footer.php';

$currentyear = date("Y");

$result = $conn->query("SELECT sum(grand_total) as grand_total, month(date) as `month` FROM `sale_product_details` where year(date)='$currentyear' group by month(date)");
$monthlysales = array(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
while ($row = $result->fetch_assoc()) {
    for ($i = 1; $i <= 12; $i++) {
        if ($row['month'] == $i) {
            $monthlysales[$i - 1] = $row['grand_total'];
        }
    }
}
// echo print_r($monthlysales);
$result = $conn->query("SELECT sum(grand_total) as grand_total, month(date) as `month` FROM `products_detail` where year(date)='$currentyear' group by month(date)");
$monthlypurchase = array(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
while ($row = $result->fetch_assoc()) {
    for ($i = 1; $i <= 12; $i++) {
        if ($row['month'] == $i) {
            $monthlypurchase[$i - 1] = $row['grand_total'];
        }
    }
}
$result = $conn->query("SELECT *,month(date) as `month`, SUM((sale_items.price-sale_items.purchase_price)*sale_items.quantity) as profit FROM `sale_items` where year(date)='2021' group by month(date)");
$monthlyprofit = array(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
while ($row = $result->fetch_assoc()) {
    for ($i = 1; $i <= 12; $i++) {
        if ($row['month'] == $i) {
            $monthlyprofit[$i - 1] = intval($row['profit']);
        }
    }
}
// echo print_r($monthlyprofit);
?>

<script>
  
    let myChart = document.getElementById('myChart').getContext('2d');

    // Global Options
    Chart.defaults.global.defaultFontFamily = 'Lato';
    Chart.defaults.global.defaultFontSize = 14;
    Chart.defaults.global.defaultFontColor = '#777';

    let massPopChart = new Chart(myChart, {
        type: 'line', // bar, horizontalBar, pie, line, doughnut, radar, polarArea
        data: {
            labels: ["January", "February", "March", "April", "May", "June",
                "July", "August", "September", "October", "November", "December"
            ],
            datasets: [{
                    label: 'Sales',
                    data: <?php echo json_encode($monthlysales) ?>,
                    //backgroundColor:'green',
                    backgroundColor: [
                        'lightblue',
                        // 'rgba(255, 99, 132, 0.6)',
                        // 'rgba(54, 162, 235, 0.6)',
                        // 'rgba(255, 206, 86, 0.6)',
                        // 'rgba(75, 192, 192, 0.6)',
                        // 'rgba(153, 102, 255, 0.6)',
                        // 'rgba(255, 159, 64, 0.6)',
                        // 'rgba(255, 99, 132, 0.6)'
                    ],
                    borderWidth: 5,
                    borderColor: 'rgb(75, 192, 192)',
                    fill: false,
                    hoverBorderWidth: 3,
                    hoverBorderColor: '#000'
                },
                {
                    label: 'Purchase',
                    data: <?php echo json_encode($monthlypurchase) ?>,
                    //backgroundColor:'green',
                    backgroundColor: [
                        'pink',
                        // 'rgba(255, 99, 132, 0.6)',
                        // 'rgba(54, 162, 235, 0.6)',
                        // 'rgba(255, 206, 86, 0.6)',
                        // 'rgba(75, 192, 192, 0.6)',
                        // 'rgba(153, 102, 255, 0.6)',
                        // 'rgba(255, 159, 64, 0.6)',
                        // 'rgba(255, 99, 132, 0.6)'
                    ],
                    borderWidth: 5,
                    fill: false,
                    borderColor: 'rgb(255, 53, 53)',
                    hoverBorderWidth: 3,
                    hoverBorderColor: '#000'
                },
                {
                    label: 'Profit',
                    data: <?php echo json_encode($monthlyprofit) ?>,
                    //backgroundColor:'green',
                    backgroundColor: [
                        'rgb(0, 206, 61)',
                        // 'rgba(255, 99, 132, 0.6)',
                        // 'rgba(54, 162, 235, 0.6)',
                        // 'rgba(255, 206, 86, 0.6)',
                        // 'rgba(75, 192, 192, 0.6)',
                        // 'rgba(153, 102, 255, 0.6)',
                        // 'rgba(255, 159, 64, 0.6)',
                        // 'rgba(255, 99, 132, 0.6)'
                    ],
                    borderWidth: 5,
                    fill: false,
                    borderColor: 'rgb(0, 206, 61)',
                    hoverBorderWidth: 3,
                    hoverBorderColor: '#000'
                }
            ]
        },
        options: {
            title: {
                display: true,
                text: 'Sales, Purchase, Profit',
                fontSize: 25
            },
            legend: {
                display: true,
                position: 'right',
                labels: {
                    fontColor: '#000'
                }
            },
            layout: {
                padding: {
                    left: 50,
                    right: 0,
                    bottom: 0,
                    top: 0
                }
            },
            tooltips: {
                enabled: true
            }
        }
    });
</script>