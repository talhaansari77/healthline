<?php
$conn=mysqli_connect("localhost","root","","try");
$val= $_GET['selectvalue'];

    if($val == 'paid'){
        ?>
        <input type="number" name="rup" class="form-control" id="rupee" placeholder="Enter Paid Price.." />
        <?php
    }


?>

