-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 11, 2021 at 11:14 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `healthline`
--

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`id`, `name`, `status`) VALUES
(1, 'b1', 'active'),
(2, 'b2', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `status`) VALUES
(2, 'ready', 'active'),
(3, 'raw', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `profile` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `mobile` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `cnic` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `business_name` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `address` text COLLATE utf8mb4_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `name`, `profile`, `mobile`, `cnic`, `business_name`, `address`) VALUES
(6, 'Hashim Customer', 'customers/men.jpg', '123456', '34643634', 'hashim bb', 'LAhore');

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `id` int(11) NOT NULL,
  `supplier` varchar(255) NOT NULL,
  `bill_id` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `item_name` varchar(255) NOT NULL,
  `quantity` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `date` date DEFAULT NULL,
  `total` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`id`, `supplier`, `bill_id`, `status`, `item_name`, `quantity`, `price`, `date`, `total`) VALUES
(60, 'Hashim', '3', 'paid', 'p1', '20', '20', '2021-09-09', '400.00'),
(66, 'Ali', '4', 'paid', 'p1', '1', '10', '2021-09-11', '10.00'),
(67, 'Ali', '5', 'unpaid', 'p2', '2', '50', '2021-09-11', '100.00'),
(68, 'Ali', '5', 'unpaid', 'p1', '1', '10', '2021-09-11', '10.00'),
(69, 'Hashim', '6', 'unpaid', 'p1', '1', '10', '2021-09-11', '10.00'),
(70, 'Ali', '7', 'unpaid', 'p1', '1', '10', '2021-09-11', '10.00'),
(71, 'Hashim', '8', 'unpaid', 'p2', '10', '10', '2021-09-11', '100.00'),
(72, 'Ali', '9', 'unpaid', 'p1', '1', '10', '2021-09-11', '10.00'),
(73, 'Ali', '10', 'unpaid', 'p1', '1', '10', '2021-09-11', '10.00'),
(74, 'Ali', '10', 'unpaid', 'p2', '2', '20', '2021-09-11', '40.00'),
(76, 'Hashim', '11', 'paid', 'p1', '10', '10', '2021-09-13', '100.00'),
(78, 'Ali', '111', 'unpaid', 'p2', '1', '50', '2021-09-13', '50.00'),
(79, 'Ali', '111', 'unpaid', 'p1', '10', '10', '2021-09-13', '100.00'),
(80, 'Ali', '112', 'unpaid', 'p1', '1', '500', '2021-09-13', '500.00'),
(81, 'Hashim', '113', 'unpaid', 'p1', '10', '40', '2021-09-13', '400.00'),
(82, 'Ali', '114', 'unpaid', 'p1', '1', '50', '2021-09-13', '50.00'),
(83, 'Ali', '115', 'unpaid', 'p1', '10', '40', '2021-09-13', '400.00'),
(84, 'Ali', '116', 'unpaid', 'p1', '10', '50', '2021-09-13', '500.00'),
(85, 'Ali', '117', 'unpaid', 'p1', '10', '40', '2021-09-13', '400.00'),
(86, 'Ali', '118', 'unpaid', 'p1', '10', '40', '2021-09-13', '400.00'),
(87, 'Ali', '119', 'unpaid', 'p1', '10', '40', '2021-09-13', '400.00'),
(88, 'Ali', '120', 'unpaid', 'p1', '10', '40', '2021-09-13', '400.00'),
(89, 'Hashim', '121', 'unpaid', 'p1', '10', '20', '2021-09-13', '200.00'),
(90, 'Hashim', '121', 'unpaid', 'p2', '1', '50', '2021-09-13', '50.00'),
(92, 'Ali', '122', 'paid', 'p1', '10', '50', '2021-09-13', '500.00');

-- --------------------------------------------------------

--
-- Table structure for table `location`
--

CREATE TABLE `location` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `location` text COLLATE utf8mb4_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Dumping data for table `location`
--

INSERT INTO `location` (`id`, `name`, `location`) VALUES
(1, 'Ali', 'Lahore'),
(2, 'Hashim', 'Gujranwala');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `product_name` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `narcotics` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `unit` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `manufacturer` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `catgories` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `subcategories` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `alter_quantity` int(11) NOT NULL,
  `opening_stock` int(11) NOT NULL,
  `product_desc` text COLLATE utf8mb4_bin NOT NULL,
  `rack` int(11) NOT NULL,
  `row` int(11) NOT NULL,
  `position` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `location` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `product_type` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `selling_price` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `purchase_price` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `purchase_discount` int(11) NOT NULL,
  `sale_discount` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `product_name`, `narcotics`, `unit`, `manufacturer`, `catgories`, `subcategories`, `alter_quantity`, `opening_stock`, `product_desc`, `rack`, `row`, `position`, `location`, `product_type`, `selling_price`, `purchase_price`, `image`, `purchase_discount`, `sale_discount`) VALUES
(4, 'p1', 'yes', 'kg', 'b1', 'ready', 'r1', 10, 0, ' dummy 1', 10, 10, '10', 'Lahore', 'variable', '10', '20', 'products/Experts-Camp.png', 10, 5),
(5, 'p2', 'yes', 'kg', 'b1', 'ready', 'r1', 10, 50, ' dummy ', 10, 5, '10', 'Lahore', 'variable', '100', '50', 'products/Experts-Camp.png', 10, 5);

-- --------------------------------------------------------

--
-- Table structure for table `products_detail`
--

CREATE TABLE `products_detail` (
  `id` int(11) NOT NULL,
  `supplier` varchar(255) NOT NULL,
  `bill_id` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `sub_total` varchar(255) NOT NULL,
  `discount_total` varchar(255) NOT NULL,
  `grand_total` varchar(255) NOT NULL,
  `paid` varchar(255) NOT NULL,
  `remaining` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products_detail`
--

INSERT INTO `products_detail` (`id`, `supplier`, `bill_id`, `status`, `sub_total`, `discount_total`, `grand_total`, `paid`, `remaining`) VALUES
(67, 'Ali', '120', 'unpaid', '400.00', '380', '383.8', '0', '383.8'),
(68, 'Hashim', '121', 'unpaid', '250.00', '225', '229.5', '0', '229.5'),
(70, 'Ali', '122', 'paid', '500.00', '490.00', '495.00', '495', '0');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(11) NOT NULL,
  `role_name` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `category` int(11) NOT NULL,
  `subcategory` int(11) NOT NULL,
  `unit` int(11) NOT NULL,
  `product` int(11) NOT NULL,
  `sale` int(11) NOT NULL,
  `purchase` int(11) NOT NULL,
  `user_management` int(11) NOT NULL,
  `stock` int(11) NOT NULL,
  `dashboard` int(11) NOT NULL,
  `report` int(11) NOT NULL,
  `supplier` int(11) NOT NULL,
  `customer` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `role_name`, `category`, `subcategory`, `unit`, `product`, `sale`, `purchase`, `user_management`, `stock`, `dashboard`, `report`, `supplier`, `customer`) VALUES
(2, 'Admin', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(3, 'Admin', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(4, 'Admin', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(5, 'Admin', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(6, 'Admin', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(7, 'Admin', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(8, 'Admin', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(9, 'Admin', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(10, 'Admin', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(11, 'Admin', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(12, 'Admin', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(13, 'Admin', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(14, 'Manager', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(15, 'Manager', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(16, 'Manager', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(17, 'Manager', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(18, 'Manager', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(19, 'test', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(20, 'test', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(21, 'test', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(22, 'check', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(23, 'check', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(24, 'check', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(25, 'check', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `rolesname`
--

CREATE TABLE `rolesname` (
  `id` int(11) NOT NULL,
  `role_name` varchar(255) COLLATE utf8mb4_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Dumping data for table `rolesname`
--

INSERT INTO `rolesname` (`id`, `role_name`) VALUES
(1, 'test'),
(2, 'test'),
(3, 'test'),
(4, 'check'),
(5, 'check'),
(6, 'check'),
(7, 'check');

-- --------------------------------------------------------

--
-- Table structure for table `sale_items`
--

CREATE TABLE `sale_items` (
  `id` int(11) NOT NULL,
  `customer` varchar(255) NOT NULL,
  `bill_id` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `item_name` varchar(255) NOT NULL,
  `quantity` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `total` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sale_items`
--

INSERT INTO `sale_items` (`id`, `customer`, `bill_id`, `status`, `item_name`, `quantity`, `price`, `date`, `total`) VALUES
(61, 'Hashim Customer', '103', 'unpaid', 'p1', '1', '10', '2021-09-13', '10.00'),
(71, 'Hashim Customer', '111', 'unpaid', 'p1', '10', '10', '2021-09-13', '100.00'),
(72, 'Hashim Customer', '112', 'paid', 'p2', '10', '10', '2021-09-13', '100.00'),
(73, 'Hashim Customer', '112', 'paid', 'p1', '10', '10', '2021-09-13', '100.00'),
(76, 'Hashim Customer', '114', 'paid', 'p1', '1', '10', '2021-09-13', '10.00'),
(77, 'Hashim Customer', '114', 'paid', 'p2', '10', '50', '2021-09-13', '500.00');

-- --------------------------------------------------------

--
-- Table structure for table `sale_product_details`
--

CREATE TABLE `sale_product_details` (
  `id` int(11) NOT NULL,
  `customer` varchar(255) NOT NULL,
  `bill_id` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `sub_total` varchar(255) NOT NULL,
  `discount_total` varchar(255) NOT NULL,
  `grand_total` varchar(255) NOT NULL,
  `paid` varchar(255) NOT NULL,
  `remaining` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sale_product_details`
--

INSERT INTO `sale_product_details` (`id`, `customer`, `bill_id`, `status`, `sub_total`, `discount_total`, `grand_total`, `paid`, `remaining`) VALUES
(62, 'Hashim Customer', '114', 'paid', '510.00', '459', '481.95', '480', '1.95');

-- --------------------------------------------------------

--
-- Table structure for table `stock`
--

CREATE TABLE `stock` (
  `id` int(11) NOT NULL,
  `bill_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `supplier_name` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `product_name` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `quantity` varchar(255) COLLATE utf8mb4_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Dumping data for table `stock`
--

INSERT INTO `stock` (`id`, `bill_id`, `supplier_name`, `product_name`, `quantity`) VALUES
(1, '10', 'Ali', 'p1', '1'),
(2, '10', 'Ali', 'p2', '2'),
(4, '11', 'Hashim', 'p1', '10'),
(5, '111', 'Ali', 'p2', '1'),
(6, '111', 'Ali', 'p1', '10'),
(7, '112', 'Ali', 'p1', '1'),
(8, '113', 'Hashim', 'p1', '10'),
(9, '114', 'Ali', 'p1', '1'),
(10, '115', 'Ali', 'p1', '10'),
(11, '116', 'Ali', 'p1', '10'),
(12, '117', 'Ali', 'p1', '10'),
(13, '118', 'Ali', 'p1', '10'),
(14, '119', 'Ali', 'p1', '10'),
(15, '120', 'Ali', 'p1', '10'),
(16, '121', 'Hashim', 'p1', '10'),
(17, '121', 'Hashim', 'p2', '1'),
(19, '122', 'Ali', 'p1', '10');

-- --------------------------------------------------------

--
-- Table structure for table `subcategories`
--

CREATE TABLE `subcategories` (
  `id` int(11) NOT NULL,
  `sub` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Dumping data for table `subcategories`
--

INSERT INTO `subcategories` (`id`, `sub`, `name`, `status`) VALUES
(1, 'r1', 'ready', 'deactive'),
(2, 'raw1', 'raw', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE `supplier` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `profile` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `business_name` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `mobile` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `address` text COLLATE utf8mb4_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`id`, `name`, `profile`, `business_name`, `mobile`, `email`, `address`) VALUES
(3, 'Ali', 'supplier/men.jpg', 'ali business', '1133', 'ali@gmail.com', 'lahore'),
(5, 'Hashim', 'supplier/men.jpg', 'hashim bb', '987456', 'hashim@gmail.com', 'Gujranwala');

-- --------------------------------------------------------

--
-- Table structure for table `units`
--

CREATE TABLE `units` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `unit` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Dumping data for table `units`
--

INSERT INTO `units` (`id`, `name`, `unit`, `status`) VALUES
(5, 'piece', 'pcs', 'active');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `location`
--
ALTER TABLE `location`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products_detail`
--
ALTER TABLE `products_detail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rolesname`
--
ALTER TABLE `rolesname`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sale_items`
--
ALTER TABLE `sale_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sale_product_details`
--
ALTER TABLE `sale_product_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stock`
--
ALTER TABLE `stock`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subcategories`
--
ALTER TABLE `subcategories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `units`
--
ALTER TABLE `units`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `items`
--
ALTER TABLE `items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=93;

--
-- AUTO_INCREMENT for table `location`
--
ALTER TABLE `location`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `products_detail`
--
ALTER TABLE `products_detail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `rolesname`
--
ALTER TABLE `rolesname`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `sale_items`
--
ALTER TABLE `sale_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=78;

--
-- AUTO_INCREMENT for table `sale_product_details`
--
ALTER TABLE `sale_product_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;

--
-- AUTO_INCREMENT for table `stock`
--
ALTER TABLE `stock`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `subcategories`
--
ALTER TABLE `subcategories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `supplier`
--
ALTER TABLE `supplier`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `units`
--
ALTER TABLE `units`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
