<?php
include 'connection.php';
define("TITLE", "Sale");
define("PAGE", "Sale");
include 'header.php';



?>


<div class="body-section">
    <div class="container mt-5">
        <h3>Edit Bill # <small><?php echo $_GET["bill_no"] ?></small></h3>

        <div class="mt-5">

            <div class="row">
                <div class="col fw-bold"></div>
                <div class="col fw-bold">Product Name</div>
                <div class="col fw-bold">Quantity</div>
                <div class="col fw-bold">Price</div>
                <div class="col fw-bold">Total</div>
            </div>

            <?php
            $sql = "SELECT * from items where bill_id=" . $_GET["bill_no"];
            $result = $conn->query($sql);
            while ($billrow = $result->fetch_assoc()) {
            ?>




                <div class="row mt-2">

                    <div class=" col">
                        <button id="del_item" class="btn btn-danger">
                            <i class="fas fa-trash"></i>
                        </button>


                        <a href="edit_sale.php?bill_id=<?php echo $billrow['id'] . "&bill_no=" . $_GET["bill_no"] ?>" class=" btn btn-primary">
                            <i class="fas fa-pen"></i>
                        </a>
                    </div>

                    <div class="col">
                        <select class="form-control " name="product_name" id="product_name" readonly required="">
                            <option value="">Select Product_Name</option>
                            <?php
                            $sql = mysqli_query($conn, "select * from product");
                            while ($row = mysqli_fetch_assoc($sql)) {
                            ?>
                                <option value="<?php echo $row['product_name']; ?>" <?php if ($billrow["item_name"] == $row['product_name']) echo "selected" ?>>
                                    <?php echo $row['product_name']; ?>
                                </option>
                            <?php
                            }

                            ?>
                        </select>
                    </div>
                    <div class="col">
                        <input class="form-control" type="number" value="<?php echo $billrow['quantity'] ?>" name="qty" id="qty" readonly>
                    </div>
                    <div class="col">
                        <input class="form-control" type="number" value="<?php echo $billrow['price'] ?>" name="price" id="price" readonly>
                    </div>
                    <div class="col">
                        <input class="form-control" type="number" value="<?php echo $billrow['price'] * $billrow['quantity'] ?>" name="total" id="total" readonly>
                    </div>
                </div>




            <?php
            }

            // $sql = "SELECT sub_total from products_detail where bill_id=" . $_GET["bill_no"];
            $sql = "SELECT SUM(total) as total from items where bill_id=" . $_GET["bill_no"];
            $result = $conn->query($sql);
            $amount = $result->fetch_assoc();
            ?>

            <!-- saving details here -->
            <form action="cedit_sale.php" method="POST">

                <input type="hidden" name="bill_no" value="<?php echo $_GET["bill_no"] ?>">
                <div class="row mt-2">
                    <div class="col fw-bold"></div>
                    <div class="col fw-bold"></div>
                    <div class="col fw-bold"></div>
                    <div class="col fw-bold">Total</div>
                    <div class="col fw-bold">
                        <input class="form-control" type="number" value="<?php echo $amount['total'] ?>" name="subtotal" id="subtotal" readonly>
                    </div>
                </div>
                <div class="row mt-2">
                    <div class="col fw-bold"></div>
                    <div class="col fw-bold"></div>
                    <div class="col fw-bold"></div>
                    <div class="col fw-bold">Discount Total</div>
                    <div class="col fw-bold">
                        <input class="form-control" type="number" value="" name="distotal" id="distotal" readonly>
                    </div>
                </div>
                <div class="row mt-2">
                    <div class="col fw-bold"></div>
                    <div class="col fw-bold"></div>
                    <div class="col fw-bold"></div>
                    <div class="col fw-bold">Grand Total</div>
                    <div class="col fw-bold">
                        <input class="form-control" type="number" value="" name="grandtotal" id="grandtotal" readonly>
                    </div>
                </div>
                <div class="row mt-2">
                    <div class="col fw-bold">Discount %</div>
                    <div class="col fw-bold">GST Tax</div>
                    <div class="col fw-bold"></div>
                    <div class="col fw-bold"></div>
                    <div class="col fw-bold">
                    </div>
                </div>

                <!-- discount and Tex -->
                <div class="row mt-2">
                    <div class="col fw-bold">
                        <input class="form-control" type="number" value="" onkeyup="getAmount()" name="discount" id="discount">
                    </div>
                    <div class="col fw-bold">
                        <input class="form-control" type="number" value="" onkeyup="getTotal()" name="gst" id="gst">
                    </div>
                    <div class="col fw-bold"></div>
                    <div class="col fw-bold"></div>
                    <div class="col fw-bold">
                    </div>
                </div>

                <div class="row mt-2">
                    <div class="col fw-bold">
                        <select class="form-control mx-auto" name="status" id="status" required="">

                            <option value="paid">Paid</option>
                            <option value="unpaid" selected>UnPaid</option>

                        </select>
                    </div>
                    <div class="col fw-bold">
                        <input class="form-control" type="number" value="" name="paid" id="paid">

                    </div>
                    <div class="col fw-bold"></div>
                    <div class="col fw-bold"></div>
                    <div class="col fw-bold">
                    </div>
                </div>

                <div class="row mt-3">
                    <div class="col fw-bold">
                        <input style="float: right;" type="submit" name="detail_submit" value="Save Changes" class="btn btn-success ">

                    </div>

                </div>

            </form>

        </div>


    </div>
</div>


<?php
include 'footer.php';

?>




<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/jautocalc@1.3.1/dist/jautocalc.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.repeater/1.2.1/jquery.repeater.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.repeater/1.2.1/jquery.repeater.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert-dev.js"></script>


<script>
    function getAmount() {
        var value = $('#subtotal').val();
        var percent = parseFloat($('#discount').val());

        var discount = value - ((value * percent) / 100);
        // console.log(parseInt(value));
        // console.log("Ae Lo "+ );
        // console.log(discount);
        $('#distotal').val(discount);
    }

    function getTotal() {
        var value = $('#distotal').val();
        var vg = parseFloat(value);
        var percent = $('#gst').val();
        var vp = parseFloat(percent);
        var discountg = vg + ((vg * vp) / 100);
        $('#grandtotal').val(discountg);
    }
</script>