<?php
include_once "connection.php";

$total = 0;
$customer = $_POST["formdata"]["cus_name"];
$product = $_POST["formdata"]["pname"];
$product = preg_replace("/\s+/", "", $product);;
$price = $_POST["formdata"]["pprice"];
$qty = $_POST["formdata"]["pqty"];
$subtotal = $_POST["formdata"]["subtotal"];
$bill_no = $_POST["formdata"]["bill_no"];

$batchno = $_POST["formdata"]["batchNo"];


// $result =  $conn->query("SELECT opening_stock FROM product WHERE product_name = '$product'");
// $old_stock = $result->fetch_assoc();


// if($old_stock['opening_stock'] > $qty){
    $sql = "INSERT into `return_sitems` (`customer`, `item_name`, `bill_id`,`quantity`, `price`,`total`,`batchno`,`status`)
    VALUE('$customer','$product','$bill_no','$qty','$price','$subtotal','$batchno','returned')";
    
    $conn->query($sql);
    
    
    // updating stock value
    // $old_stock = $old_stock['opening_stock'] - $qty;
    // $conn->query("UPDATE product SET opening_stock = '$old_stock' WHERE product_name = '$product'");
    
// }else{
//     echo "<script>window.location='sale.php?msg=stockout'</script>";
// }



$sql = "SELECT * FROM return_sitems where bill_id=" . $bill_no;
$result =  $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $total += floatval($row["total"]);
?>

        <tr>
            <!-- <td><?php //echo $row["customer"] ?></td> -->
            <td><?php echo $row["item_name"] ?></td>
            <td><?php echo $row["price"] ?></td>
            <td><?php echo $row["quantity"] ?></td>
            <td><?php echo $row["total"] ?></td>
            <td>
                <a href="ed_it.php?id=<?php echo $row['id'] . "&name=" . preg_replace("/\s+/", "", $row['item_name']) . "&price=" . $row['price'] . "&qty=" . $row['quantity'] . "&bill_no=" . $row['bill_id'] ?>" class="btn btn-primary">
                    <i class="fas fa-pen"></i>
                </a>
                <a href="del_it.php?id=<?php echo $row['id']. "&bill_no=" . $row['bill_id'] ?>" class="btn btn-danger">
                    <i class="fas fa-trash"></i>
                </a>
            </td>
        </tr>

<?php
    }
}

?>

<tr>
    <!-- <td>------</td> -->
    <td>------</td>
    <td>------</td>
    <td>------</td>
    <td><?php echo $total ?></td>
    <td>------</td>
</tr>
<input type="hidden" value="<?php echo $total ?>" id="sub2" name="sub2">