<?php
include 'connection.php';
define("TITLE", "Sale");
define("PAGE", "Sale");
include 'header.php';






?>


<div class="body-section">
    <div class="container mt-5">
        <h3>Bill Item # <small><?php echo $_GET["bill_id"] ?></small></h3>

        <div class="mt-5">

            <div class="row">
                <div class="col fw-bold"></div>
                <div class="col fw-bold">Product Name</div>
                <div class="col fw-bold">Quantity</div>
                <div class="col fw-bold">Price</div>
            </div>

            <?php
            $sql = "SELECT * from sale_items where id=" . $_GET["bill_id"];
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
                // fetching bill item data
                $billrow = $result->fetch_assoc()

            ?>



                <form action="cedit_sale.php" method="POST">
                    <input type="hidden" name="bill_id" value="<?php echo $_GET["bill_id"] ?>" class="btn btn-success">
                    <input type="hidden" name="bill_no" value="<?php echo $_GET["bill_no"] ?>" class="btn btn-success">

                    <div class="row mt-2">

                        <div class=" col">
                            <input type="submit" name="submit" value="Save" class="btn btn-success">
                        </div>

                        <div class="col">
                            <select class="form-control " name="product_name" id="product_name" required="">
                                <optgroup label="Select Product_Name">
                                    <?php
                                    $sql = mysqli_query($conn, "select * from product");
                                    while ($row = mysqli_fetch_assoc($sql)) {
                                    ?>
                                        <option value="<?php echo $row['product_name']; ?>" <?php if ($billrow["item_name"] == $row['product_name']) echo "selected" ?>>
                                            <?php echo $row['product_name']; ?>
                                        </option>
                                    <?php
                                    }

                                    ?>
                                </optgroup>
                            </select>
                        </div>
                        <div class="col">
                            <input class="form-control" type="number" value="<?php echo $billrow['quantity'] ?>" name="qty" id="qty">
                        </div>
                        <div class="col">
                            <input class="form-control" type="number" value="<?php echo $billrow['price'] ?>" name="price" id="price">
                        </div>
                        <!-- <div class="col">
                        <input class="form-control" type="number" value="<?php //echo $billrow['price'] * $billrow['quantity'] 
                                                                            ?>" name="total" id="total" readonly>
                    </div> -->
                    </div>

                </form>


            <?php
            }
            ?>




        </div>


    </div>
</div>


<?php
include 'footer.php';

?>




<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/jautocalc@1.3.1/dist/jautocalc.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.repeater/1.2.1/jquery.repeater.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.repeater/1.2.1/jquery.repeater.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert-dev.js"></script>