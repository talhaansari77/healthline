<?php
define("TITLE", "Products");
define("PAGE", "Products");
include 'connection.php';
include 'header.php';

?>


<div class="body-section">
  <div class="container">
    <div class="card">
      <div class="card-header border-0">
        <h3 class="card-title">Customer</h3>
        <hr>
        <div class="container mt-1">
          <!-- Button trigger modal -->
          <div class="row">
            <div class="col-lg-9">
              <div class="input-group ">


              </div>
            </div>
            <div class="col-lg-3">


              <button type="button" id="button-addon2" data-bs-toggle="modal" data-bs-target="#exampleModal" class="btn float-right mb-3">
                <i class="fas fa-plus"></i>
                Add Customer
              </button>
              <!--Modal-->
              <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                  <div class="modal-content">
                    <div class="modal-header bg-light">
                      <h4 class="modal-title " id="exampleModalLabel">Add Customer</h4>
                      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      </button>
                    </div>
                    <div class="modal-body">
                      <form method="POST" enctype="multipart/form-data">
                        <div class="form-group">
                          <label class="fw-bold">Customer Name</label>
                          <input type="text" class="form-control mb-2" placeholder="Customer Name" name="name">
                          <label>Image:</label>
                          <input type="file" name="pic" class="form-control">
                          <label class="fw-bold">Phone No.</label><br>
                          <input type="number" class="form-control mb-2" placeholder="Phone No" name="mobile">
                          <label class="fw-bold">CNIC</label><br>
                          <input type="text" class="form-control mb-2" pattern="^[0-9+]{5}-[0-9+]{7}-[0-9]{1}$" required placeholder="xxxxx-xxxxxxx-x" name="cnic">
                          <label class="fw-bold">Business Name</label><br>
                          <input type="text" class="form-control mb-2" placeholder="Business Name" name="bname">
                          
                          <label class="fw-bold">license No</label><br>
                          <input type="text" class="form-control mb-2" placeholder="license No" name="licence_no" required>
                          <label class="fw-bold">license Expiry</label><br>
                          <input type="date" class="form-control mb-2"  name="licence_exp" required>
                          
                          <label class="fw-bold">Current Address</label><textarea class="form-control" name="address"></textarea>
                        </div>
                        <div class="modal-footer bg-light">
                          <button type="submit" class="btn btn-primary" name="add">Add </button>
                        </div>
                      </form>
                    </div>

                  </div>
                </div>
              </div>

            </div>
          </div>


          <div class="card-body table-responsive p-0">
            <div class="row">
              <div class="col-lg-12">
                <table id="table" class="table table-striped table-bordered  pt-3">

                  <thead class="table-dark">
                    <tr>
                      <th>ID</th>
                      <th>Name</th>
                      <th>Image</th>
                      <th>Buisness Name</th>
                      <th>Phone#</th>
                      <th>CNIC</th>
                      <th>licence No</th>
                      <th>licence Expiry</th>
                      <th>Current Address</th>
                      <th>Operations</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                    $squery = "select * from customer";
                    $run = mysqli_query($conn, $squery);
                    while ($row = mysqli_fetch_assoc($run)) {

                    ?>
                      <tr>
                        <td><?php echo $row['id']; ?></td>
                        <td><?php echo $row['name']; ?></td>
                        <td><img src="<?php echo $row['profile'] ?>" alt="profile" style="width:120px; height:120px;"> </td>
                        <td><?php echo $row['business_name']; ?></td>
                        <td><?php echo $row['mobile']; ?></td>
                        <td><?php echo $row['cnic']; ?></td>
                        <td><?php echo $row['licence_no']; ?></td>
                        <td><?php echo $row['licence_exp']; ?></td>
                        <td><?php echo $row['address']; ?></td>

                        <td class="text-center">

                          <div class="action">
                            <button class="btn btn-success btn-sm dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                              Action
                            </button>
                            <ul class="dropdown-menu p-0">


                              <!--  -->
                              <a href="customerview.php?idv=<?php echo $row['id']; ?>" style="text-decoration: none; color: black;">
                                <li class="dropdown-item"><i class="far fa-eye"></i> View </li>
                              </a>

                              <li class="editbtn" style="cursor:pointer;"> &nbsp;&nbsp; &nbsp;<i class="far fa-edit"></i> Edit</li>

                              <input type="hidden" class="delete_id_value" value="<?php echo $row['id']; ?>">
                              <a href="javascript:void(0)" type="button" class="delete_btn_ajax btn btn-sm"> &nbsp;
                                <i class="fas fa-trash"></i>
                                Delete</a>

                 

                              <!--  -->






                              <!-- <button type="button" class="btn btn-success btn-sm editbtn"><i class="fas fa-edit"></i></button>
                              <input type="hidden" class="delete_id_value" value="<?php echo $row['id']; ?>">
                              <a href="javascript:void(0)" type="button" class="delete_btn_ajax btn btn-sm btn-danger"><i class="fas fa-trash"></i></a> -->

                            </ul>
                          </div>




                        </td>

                      </tr>
                    <?php } ?>
                  </tbody>
                </table>
              </div>
            </div>



          </div>
        </div>




      </div>
      <!-- flex-item -->
    </div>
    <!-- /flex-container -->
  </div>
</div>
<!-- flex-item -->
</div>
<!-- /flex-container -->
</div>
</div>

<!-- ============================================================== -->
<!-- End Container fluid  -->
<!-- ============================================================== -->
</div>
<!-- ============================================================== -->
<!-- End Page wrapper  -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- footer -->
<!-- ============================================================== -->
<!--  <footer class="footer fixed">
            © 2020 Elegent Admin by <a href="https://www.wrappixel.com/">wrappixel.com</a>
        </footer> -->
<!-- ============================================================== -->
<!-- End footer -->
<!-- ============================================================== -->
</div>
<!-- ============================================================== -->
<!-- End Wrapper -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<div class="modal fade" id="myModalEdit" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Edit Customer</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="container">

          <form id="editSuplier" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="update_id" id="update_id">
            <div class="modal-body">
              <div class="form-group">
                <label for="suplierName">Customer Name</label>
                <input type="text" class="form-control" id="name" placeholder="Suplier Name" name="sname" required>
              </div>

              <div class="form-group">
                <label for="suplierbName">Business name</label>
                <input type="text" class="form-control" id="bname" placeholder="Bussiness Name" name="bname" required>
              </div>

              <div class="form-group">
                <label>Phone Number</label>
                <input type="phone" class="form-control" id="phone" placeholder="phone Number" name="cell" required>
              </div>

              <div class="form-group">
                <label for="cnic">CNIC</label>
                <input type="text" class="form-control" id="cnic" name="cnic" required>
              </div>
              <div class="form-group">
                <label for="licence_no">licence NO</label>
                <input type="text" class="form-control" id="licence_no" name="licence_no" required>
              </div>
              <div class="form-group">
                <label for="licence_exp">licence Expiry</label>
                <input type="text" class="form-control" id="licence_exp" name="licence_exp" required>
              </div>

              <div class="form-group">
                <label>Current Address</label>
                <input type="text" class="form-control" id="address" placeholder="Current Address" name="address" required>
              </div>
            </div>
            <div class="modal-footer">
              <button type="submit" class="btn btn-primary" name="update">Save changes</button>
            </div>
          </form>
        </div>

      </div>

    </div>
  </div>
</div>


</div>

</div>
</div>
</div>





</div>



<script>
  $(document).ready(function() {
    $(".delete_btn_ajax").click(function(e) {
      e.preventDefault();
      var deleteid = $(this).closest('tr').find('.delete_id_value').val();
      // alert(deleteid);
      swal({
          title: "Are you sure?",
          text: "Once deleted, you will not be able to recover this Data!",
          icon: "warning",
          buttons: true,
          dangerMode: true,
        })
        .then((willDelete) => {
          if (willDelete) {
            $.ajax({
              type: "POST",
              url: "deletecustomer.php",
              data: {
                "delete_btn_set": 1,
                "deleteid": deleteid,
              },
              success: function(response) {
                swal("Deleted!", "Your Data is Deleted", "success", {
                  button: "Ok!",
                }).then((result) => {
                  location.reload();
                });

              }
            });
          }
        });

    });
  });
</script>

<script>
  $(document).ready(function() {
    $('.editbtn').on('click', function() {
      $('#myModalEdit').modal('show');

      $tr = $(this).closest('tr');

      var data = $tr.children('td').map(function() {
        return $(this).text();
      }).get();

      console.log(data);
      $('#update_id').val(data[0]);
      $('#name').val(data[1]);
      $('#bname').val(data[3]);
      $('#phone').val(data[4]);
      $('#cnic').val(data[5]);
      $('#licence_no').val(data[6]);
      $('#licence_exp').val(data[7]);

      $('#address').val(data[8]);
    });
  });
</script>

<?php


include 'footer.php';

if (isset($_POST['add'])) {
  $cnic_pattern = '/[0-9]{5}[-][0-9]{7}[-][0-9]{1}/';
  $name = $_POST['name'];
  $file = ($_FILES['pic']);
  //    print_r($file);
  $file_name = $file['name'];
  $file_path = $file['tmp_name'];
  $file_error = $file['error'];
  $business_name = $_POST['bname'];
  $mobile = $_POST['mobile'];
  $address = $_POST['address'];
  $cnic = $_POST['cnic'];
  $licence_no = $_POST['licence_no'];
  $licence_exp = $_POST['licence_exp'];

  
  
  if ($file_error == 0) {
    $destinaton = 'customers/' . $file_name;
    move_uploaded_file($file_path, $destinaton);

    $insert = "INSERT INTO `customer`(`name`, `profile`, `mobile`, `cnic`, `business_name`, `address`, `licence_no`,`licence_exp`)  values('$name','$destinaton','$mobile','$cnic','$business_name','$address','$licence_no','$licence_exp')";
    $res = mysqli_query($conn, $insert);
    if ($res) {
?>
      <script>
        window.location = "<?php echo $app_url . '/customer.php' ?>";
      </script>
    <?php
    } else {
    ?>
      <script>
        alert("Failed");
      </script>
    <?php
    }
  } else {
    ?>
    <script>
      alert("Profile Pic Error");
    </script>
  <?php
  }
}
//Edit
if (isset($_POST['update'])) {
  $id = $_POST['update_id'];
  $name = $_POST['sname'];
  $business_name = $_POST['bname'];
  $mobile = $_POST['cell'];
  $cnic = $_POST['cnic'];
  $address = $_POST['address'];
  $licence_no = $_POST['licence_no'];
  $licence_exp = $_POST['licence_exp'];

  $updatequery = "UPDATE `customer` SET `name`='$name',`mobile`='$mobile',`cnic`='$cnic',`business_name`='$business_name',`address`='$address', `licence_no`='$licence_no',`licence_exp`='$licence_exp' WHERE id='$id'";
  $uquery = mysqli_query($conn, $updatequery);
  if ($uquery) {
  ?>
    <script>
      window.location = "<?php echo $app_url . '/customer.php' ?>";
    </script>

  <?php
  } else {
  ?>
    <script>
      alert('Update Failed');
    </script>

<?php
  }
}
?>