
<script src="https://unpkg.com/sweetalert@2.1.2/dist/sweetalert.min.js"></script>

<button onclick="cdel()"  class="btn btn-danger " data-toggle="modal" data-target="#Delete">Delete</button>

<script>
    function cdel(){
        swal({
     title:"Please Confirm",
     text: "Are You Sure?",
     buttons: {
            cancel: true,
            confirm: "Delete"
     }
});
    }
    
</script>