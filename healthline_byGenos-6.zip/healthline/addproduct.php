<?php
define("TITLE", "Products");
define("PAGE", "Products");
include 'connection.php';
include 'header.php';

?>
<style>
    /*
 * bootstrap-tagsinput v0.8.0
 * 
 */

    .bootstrap-tagsinput {
        box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);

        vertical-align: middle;
        border-radius: 4px;
        max-width: 100%;
        cursor: text;

        padding: 0.467rem 0.6rem;
        font-size: 0.855rem;
        font-weight: 400;
        line-height: 1.8;
        color: #555252;
        background-color: white;
        background-clip: padding-box;
        border: 1px solid #DFE3E7;
    }

    .bootstrap-tagsinput input {
        border: none;
        box-shadow: none;
        outline: none;

        background-color: transparent;
        padding: 0 6px;
        margin: 0;
        width: auto;
        max-width: inherit;
    }

    .bootstrap-tagsinput.form-control input::-moz-placeholder {
        color: #777;
        opacity: 1;
    }

    .bootstrap-tagsinput.form-control input:-ms-input-placeholder {
        color: #777;
    }

    .bootstrap-tagsinput.form-control input::-webkit-input-placeholder {
        color: #777;
    }

    .bootstrap-tagsinput input:focus {
        border: none;
        box-shadow: none;
    }

    .bootstrap-tagsinput .tag {
        margin-right: 2px;
        color: white;
    }

    .bootstrap-tagsinput .tag [data-role="remove"] {
        margin-left: 8px;
        cursor: pointer;
    }

    .bootstrap-tagsinput .tag [data-role="remove"]:after {
        content: "x";
        padding: 0px 2px;
    }

    .bootstrap-tagsinput .tag [data-role="remove"]:hover {
        box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.2), 0 1px 2px rgba(0, 0, 0, 0.05);
    }

    .bootstrap-tagsinput .tag [data-role="remove"]:hover:active {
        box-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
    }
</style>

<style>
    .label-info {
        background-color: #2B8AFF;
        padding: 2px;
        border-radius: 4px;
    }
</style>

<div class="body-section">
    <div class="container ">
        <div class="card ">
            <div class="card-header border-0">
                <h3 class="card-title">Products</h3>
                <hr>
                <div class="container mt-1">
                    <form id="contact-form" class="studentform" method="POST" enctype="multipart/form-data">
                        <div class="row">
                            <div class="col-md-6 ">
                                <label class="form-label">Product Name:</label>
                                <input type="text" class="form-control" name="product" placeholder="Product Name">
                            </div>
                            <div class="col-md-6 ">

                                <label class="form-label">Narcotics:</label>
                                <div class="input-group">
                                    <select class="form-select" name="narcotics">
                                        <option selected>Narcotics</option>
                                        <option value="yes">Yes</option>
                                        <option value="no">No</option>

                                    </select>


                                </div>
                            </div>




                        </div>
                        <div class="row mt-3">

                            <div class="col-md-3 ">

                                <label class="form-label">Manufacturer:</label>
                                <div class="input-group">
                                    <select name="manufecturer" class="form-select">
                                        <option selected>Manufacturer</option>
                                        <?php
                                        $brand_query = mysqli_query($conn, "select * from brands");
                                        while ($row = mysqli_fetch_assoc($brand_query)) {
                                        ?>
                                            <option value="<?php echo $row['name']; ?>"><?php echo $row['name']; ?></option>
                                        <?php
                                        }
                                        ?>
                                    </select>

                                </div>





                            </div>
                            <div class="col-md-3 ">
                                <label class="form-label">ReOrder Level:</label>
                                <input type="number" class="form-control" name="reorder_lvl" placeholder="Reorder Level">
                            </div>
                            <div class="col-md-3 ">

                                <label class="form-label">Pieces:</label>
                                <div class="input-group">
                                    <input type="number" class="form-control" min="1" name="pieces">


                                </div>



                            </div>
                            <div class="col-md-3 ">

                                <label class="form-label">Batch #</label>
                                <div class="input-group">
                                    <input type="text" data-role="tagsinput" class="form-control" name="batchno">


                                </div>



                            </div>

                        </div>
                        <div class="row mt-3">
                            <div class="col-md-3 ">

                                <label class="form-label">Catagories:</label>

                                <select name="category" class="form-select">
                                    <option selected>Catagories</option>
                                    <?php
                                    $cat_query = mysqli_query($conn, "select * from categories");
                                    while ($row = mysqli_fetch_assoc($cat_query)) {
                                    ?>
                                        <option value="<?php echo $row['name']; ?>"><?php echo $row['name']; ?></option>
                                    <?php
                                    }
                                    ?>
                                </select>


                            </div>
                            <div class="col-md-3 ">

                                <label class="form-label">Sub-Catagories:</label>

                                <select name="subcat" class="form-select">
                                    <option selected>Sub-Catagories</option>
                                    <?php
                                    $sub_query = mysqli_query($conn, "select * from subcategories");
                                    while ($row = mysqli_fetch_assoc($sub_query)) {
                                    ?>
                                        <option value="<?php echo $row['sub']; ?>"><?php echo $row['sub']; ?></option>
                                    <?php
                                    }
                                    ?>
                                </select>


                            </div>
                            <div class="col-md-3 ">
                                <label class="form-label">Alter Quantity:</label>
                                <input type="number" class="form-control" name="alter" placeholder="Alter Quantity">
                            </div>

                            <div class="col-md-3 ">
                                <label class="form-label">Opening Stock:</label>
                                <input type="number" class="form-control" name="ostock" placeholder="Stock">
                            </div>

                        </div>


                        <div class="row mt-3">
                            <div class="col-md-12">
                                <label class="form-label">Product Description:</label>
                                <div>
                                    <textarea class="form-control" name="productDes"></textarea>
                                    <script>
                                        CKEDITOR.replace('exampleInputpdes');
                                    </script>

                                </div>
                            </div>

                        </div>
                        <div class="row mt-3">
                            <div class="col-md-6 ">
                                <label class="form-label">Rack:</label>
                                <input type="number" class="form-control" name="rack" placeholder="Rack">
                            </div>
                            <div class="col-md-6 ">
                                <label class="form-label">Row:</label>
                                <input type="number" class="form-control" name="row" placeholder="Row">
                            </div>
                        </div>
                        <div class="row mt-3">
                            <div class="col-md-6 ">
                                <label class="form-label">Position:</label>
                                <input type="text" class="form-control" name="position" placeholder="Position">
                            </div>
                            <div class="col-md-6 ">
                                <label class="form-label">Location:</label>
                                <select name="location" class="form-select">
                                    <option selected>Loction</option>
                                    <?php
                                    $location_query = mysqli_query($conn, "select * from location");
                                    while ($row = mysqli_fetch_assoc($location_query)) {
                                    ?>
                                        <option value="<?php echo $row['location']; ?>"><?php echo $row['location']; ?></option>
                                    <?php
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>

                        <hr>
                        <div class="row mt-3">
                            <div class="col-md-4 ">

                                <label class="form-label">Product Type:</label>

                                <select name="type" class="form-select">
                                    <option value="single">Single</option>
                                    <option value="variable">Variable</option>
                                    <option value="combo">Combo</option>

                                </select>


                            </div>

                        </div>
                        <div class="row mt-3">
                            <div class="col-md-12 table-responsive">

                                <table class="table table-bordered ">
                                    <tr class="th">
                                        <th>Default Selling Price</th>
                                        <th>Default Purchase Price</th>
                                        <th>Product image</th>
                                    </tr>
                                    <tr>
                                        <td>
                                            <label class="form-label">Selling Price:</label>
                                            <input type="text" class="form-control" name="sprice" placeholder="Selling Price:">
                                        </td>

                                        <td>
                                            <label class="form-label">Purchasing Price:</label>
                                            <input type="text" class="form-control" name="pprice" placeholder="Purchasing Price:">

                                        </td>
                                        <td>
                                            <label class="form-label">Product Sample Image:</label>
                                            <input type="file" name="pic" class="form-control">

                                            <p>Max File size: 5MB <br>
                                                Aspect ratio should be 1:1</p>

                                        </td>
                                    </tr>

                                </table>


                            </div>
                            <div class="row mt-3">
                                <div class="col-md-3 ">
                                    <label class="form-label">Purchase Disc%:</label>
                                    <input type="number" class="form-control" name="pdiscount" placeholder="Purchase">
                                </div>
                                <div class="col-md-3 ">
                                    <label class="form-label">Sale Disc%:</label>
                                    <input type="number" class="form-control" name="sdicount" placeholder="Sale Disc%">
                                </div>
                                <div class="col-md-2 ">
                                    <label class="form-label">Sales Commission</label>
                                    <input type="number" min="0" class="form-control" name="SalesCommission">


                                </div>
                                <div class="col-md-1 ">
                                <div><label class="form-label"> Type</label></div>
                                    %<input type="radio" value="%" checked="checked" name="comtype">
                                    Rs<input type="radio" value="Rs" name="comtype">

                                </div>
                                <div class="col-md-3 ">
                                    <label class="form-label">Expiry Date</label>
                                    <input type="date" class="form-control" name="exp_date">
                                </div>
                            </div>

                            <div class="row mt-3 mb-3">

                                <div class="col-lg-4 ">
                                    <button type="submit" class="btn btn-success btn-lg" style="margin-left:25px; " name="add">Add Product</button>
                                </div>

                            </div>



                        </div>

                        </from>



                        <div class="card-body table-responsive p-0">

                        </div>
                </div>




            </div>
            <!-- flex-item -->
        </div>
        <!-- /flex-container -->
    </div>
</div>
<!-- flex-item -->
</div>
<!-- /flex-container -->
</div>
</div>

</div>

</div>




</div>






<?php


include 'footer.php';

//Add Product into database
if (isset($_POST['add'])) {
    $product_name = $_POST['product'];
    $narcotics = $_POST['narcotics'];

    $pieces = $_POST['pieces'];
    $batchno = $_POST['batchno'];
    $exp_date = $_POST['exp_date'];
    $reorder_lvl = $_POST['reorder_lvl'];
    $SalesCommission = $_POST['SalesCommission'].$_POST['comtype'];

    $manufecturer = $_POST['manufecturer'];
    $category = $_POST['category'];
    $subcategory = $_POST['subcat'];
    $alter = $_POST['alter'];
    $stock = $_POST['ostock'];
    $productDes = $_POST['productDes'];
    $rack = $_POST['rack'];
    $row = $_POST['row'];
    $position = $_POST['position'];
    $location = $_POST['location'];
    $type = $_POST['type'];
    $sprice = $_POST['sprice'];
    $pprice = $_POST['pprice'];

    $file = ($_FILES['pic']);
    // print_r($file);
    $file_name = $file['name'];
    $file_path = $file['tmp_name'];
    $file_error = $file['error'];
    $pdiscount = $_POST['pdiscount'];
    $sdiscount = $_POST['sdicount'];
    if ($file_error == 0) {
        $destinaton = 'products/' . $file_name;
        move_uploaded_file($file_path, $destinaton);

        $insert = "INSERT INTO `product`(`product_name`, `narcotics`, `pieces`, `batchno`,`exp_date`, `reorder_lvl`,`manufacturer`, `catgories`, `subcategories`, `alter_quantity`,`opening_stock`, `product_desc`, `rack`, `row`, `position`, `location`, `product_type`, `selling_price`, `purchase_price`, `image`, `purchase_discount`, `sale_discount`, `total_purchase`,`comission`) 
        VALUES ('$product_name','$narcotics','$pieces','$batchno','$exp_date','$reorder_lvl','$manufecturer','$category','$subcategory','$alter','$stock','$productDes','$rack','$row','$position','$location','$type','$sprice','$pprice','$destinaton','$pdiscount','$sdiscount', '$stock','$SalesCommission')";
        $res = mysqli_query($conn, $insert);
        if ($res) {
?>
            <script>
                // window.location = "<?php //echo $app_url . '/product.php' 
                                        ?>";
                window.location = "<?php echo 'product.php' ?>";
            </script>
        <?php
        } else {
        ?>
            <script>
                alert("Failed");
            </script>
        <?php
        }
    } else {
        ?>
        <script>
            alert("Profile Pic Error");
        </script>
<?php
    }
}
?>

<script src="js/tags_input.js"></script>