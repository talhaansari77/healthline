<?php 
define("TITLE","Role");
define("PAGE","Role");

include 'header.php';

?>


<div class="body-section">
<div class="container">
         <div class="card">
              <div class="card-header border-0">
                <h3 class="card-title">Role</h3>
                <hr>
      <div class="container mt-1">
              <!-- Button trigger modal -->
              <div class="row">
                  <div class="col-lg-9">
                    <div class="input-group ">
                    <div class="form-outline">
                      <input type="search" id="form1" class="form-control" placeholder="Search">
                     
                    </div>
                    <button type="button" class="btn" id="button-addon2" >
                      <i class="fas fa-search"></i>
                    </button>
</div>
                  </div>
                  <div class="col-lg-3">
              
      <a href="addrole.php">
          <button type="button" id="button-addon2"  class="btn btn-lg float-right mb-3" >
        Add Role
        </button>
        </a>
        <!--Modal-->
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header bg-light">
          <h4 class="modal-title " id="exampleModalLabel">Add Role</h4>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </button>
        </div>
        <div class="modal-body">
            <form method="POST">
                <div class="form-group">
                    <label class="form-label">Name</label>
                    <input type="text" class="form-control" placeholder="Brand Name" name="name">
                </div>
                <div class="form-group">
                    <label class="form-label">Role</label>
                    <input type="text" class="form-control" placeholder="Role" name="Role">
                </div>
               
                <div class="form-group mt-3">
                    <input type="checkbox" name="status" value="active"> <label>Active</label>
                </div>
                <div class="modal-footer">
                  <button type="submit" class="btn" id="button-addon2" name="add">Add</button>
              </div>
            </form>
        </div>
       
      </div>
    </div>
  </div>

        </div>
        </div>

  
              <div class="card-body table-responsive">
                  <div class="row">
                  <div class="col-lg-12">
                <table id="table" class="table table-striped pt-3">
                  
                  <thead class="table-dark">
                     <tr>
                          <th>ID</th>
                         
                          <th>Role</th>
                          
                          
                          <th>Operations</th>                         
                     </tr>
                                            </thead>
                                            <tbody>
                                            
                                                     <tr>
                                                   <td>1</td>
                                                   
                                                    <td>Cashier</td>
                                                    
                                                    
                                                    
                                                    <td>
                                                    <button type="submit" class="btn btn-sm btn-danger"
                                                        name="" data-bs-toggle="modal" data-bs-target="#myModalDelete"
                                                            >Delete</button>
                                                            <a href="editrole.php">
                                                            <button type="button"  class="btn btn-success btn-sm editbtn">Edit</button></a>
                                                    </td>
                                                </tr>
                                                <tr>
                                                   <td>1</td>
                                                   
                                                    <td>Cashier</td>
                                                    
                                                    
                                                    
                                                    <td>
                                                    <button type="submit" class="btn btn-sm btn-danger"
                                                        name="" data-bs-toggle="modal" data-bs-target="#myModalDelete"
                                                            >Delete</button>

                                                            <a href="editrole.php">
                                                            <button type="button"  class="btn btn-success btn-sm editbtn">Edit</button></a>
                                                    </td>
                                                </tr>
                                                <tr>
                                                   <td>1</td>
                                                   
                                                    <td>Cashier</td>
                                                    
                                                    
                                                    
                                                    <td>
                                                    <button type="submit" class="btn btn-sm btn-danger"
                                                        name="" data-bs-toggle="modal" data-bs-target="#myModalDelete"
                                                            >Delete</button>

                                                            <a href="editrole.php">
                                                            <button type="button"  class="btn btn-success btn-sm editbtn">Edit</button></a>
                                                    </td>
                                                </tr>
                                                <tr>
                                                   <td>1</td>
                                                   
                                                    <td>Cashier</td>
                                                    
                                                    
                                                    
                                                    <td>
                                                    <button type="submit" class="btn btn-sm btn-danger"
                                                        name="" data-bs-toggle="modal" data-bs-target="#myModalDelete"
                                                            >Delete</button>

                                                            <a href="editrole.php">
                                                            <button type="button"  class="btn btn-success btn-sm editbtn">Edit</button></a>
                                                    </td>
                                                </tr>
                                                <tr>
                                                   <td>1</td>
                                                   
                                                    <td>Cashier</td>
                                                    
                                                    
                                                    
                                                    <td>
                                                    <button type="submit" class="btn btn-sm btn-danger"
                                                        name="" data-bs-toggle="modal" data-bs-target="#myModalDelete"
                                                            >Delete</button>

                                                            <a href="editrole.php">
                                                            <button type="button"  class="btn btn-success btn-sm editbtn">Edit</button></a>
                                                    </td>
                                                </tr>
                                                
                                               

                                                 
                                            </tbody>
                </table>
                </div>
                </div>


              </div>
            </div>
            



            </div>
            <!-- flex-item -->
        </div>
        <!-- /flex-container -->
    </div>
            </div>
            <!-- flex-item -->
        </div>
        <!-- /flex-container -->
    </div>
</div>
               
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- footer -->
        <!-- ============================================================== -->
       <!--  <footer class="footer fixed">
            © 2020 Elegent Admin by <a href="https://www.wrappixel.com/">wrappixel.com</a>
        </footer> -->
        <!-- ============================================================== -->
        <!-- End footer -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <div class="modal fade" id="myModalEdit" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Edit Role</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <div class="container">

                                   
<form  method="POST">
<input type="hidden" name="update_id" id="update_id" />
<div class="form-group">
<label class="form-label" for="pname">Name</label>
<input type="text" class="form-control" placeholder="Name" name="name" id="name">
</div>
<div class="form-group">
<label class="form-label" for="pname">Role</label>
<input type="text" class="form-control" placeholder="Role" name="Role" id="Role">
</div>

<div class="form-group">
      <label for="estatus" class="form-label">Status:</label>
      <select name="estatus" id="estatus" class="form-select">
        <option value="active">active</option>
        <option value="inactive">inactive</option>
      </select>                                      
    </div>
                        
    
</form>
</div>
        
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn " id="button-addon2">Edit</button>
      </div>
    </div>
  </div>
</div>

        <!--delete-->
<div class="modal fade" id="myModalDelete" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Delete Supplier</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <div class="container">

      <p>Are you sure want to delete the record?</p>
                <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
        <button type="button" class="btn " id="button-addon2">Yes</button>
      </div>
            </form>
</div>
        
      </div>
     
    </div>
  </div>
</div>





    </div>












<?php 


include 'footer.php';

?>