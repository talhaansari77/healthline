<?php
session_start();
if (isset($_SESSION['email'])) {
    header('location:dashboard.php');
}
// 
?>
<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet">

    <title>HealthLine</title>
</head>

<body class="bg-light">


    <!-- Demo content-->
    <div class="container">
        <div class="row ">
            <div class="col-md-10 mx-auto">


                <div class="text-center">
                    <figure>
                        <img class="logo mt-2" src="images/logo.png" style=" height:300px;">
                    </figure>
                    <form method="POST">
                        <div class="mb-3">

                            <input type="text" class="form-control" id="name" name="name" aria-describedby="UserName" placeholder="UserName" required>
                        </div>
                        <div class="mb-3">

                            <input type="email" class="form-control" id="email" name="email" aria-describedby="emailHelp" placeholder="Enter email" required>
                        </div>
                        <div class="mb-3">

                            <input type="password" class="form-control" id="password" name="password" placeholder="Enter password" required>
                        </div>
                        <div class="mb-3">

                            <input type="tel" class="form-control" id="phone" name="phone" aria-describedby="Phone" placeholder="03123456879" required>
                        </div>
                        <div class="mb-3">

                            <input type="text" class="form-control" id="address" name="address" placeholder="Enter Address" required>
                        </div>

                        <a href="login.php" class="btn btn-success text-white">
                            < Back</a>
                                <button type="submit" class="btn btn-primary text-white" name="submit">Register</button>
                                <!-- <a href="forget.php">Forget Password</a> -->


                    </form>
                </div>
            </div>
        </div>
    </div><!-- End -->






    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.min.js" integrity="sha384-Atwg2Pkwv9vp0ygtn1JAojH0nYbwNJLPhwyoVbhoPwBhjQPR5VtM2+xf0Uwh9KtT" crossorigin="anonymous"></script>
    -->
</body>

</html>
<?php

include 'connection.php';
if (isset($_POST['submit'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];

    $result = $conn->query("SELECT * FROM `login` WHERE `name`='$name' OR `email`='$email'");
    if ($result->num_rows > 0) {
        echo "<script>window.location='signup.php?msg=userExist'</script>";
    }else{
        if ($email != null && $password != null) {
            $conn->query("INSERT INTO `login`(email, `password`,`name`,`phone`,`address`) 
            VALUE('$email','$password','$name','$phone','$address')");
            header('location:login.php?userCreated');
        }
    }

    
}


?>