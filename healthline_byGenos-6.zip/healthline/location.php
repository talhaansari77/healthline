<?php 
define("TITLE","Products");
define("PAGE","Products");
include 'connection.php';
include 'header.php';

?>


<div class="body-section">
<div class="container">
         <div class="card">
              <div class="card-header border-0">
                <h3 class="card-title">Location</h3>
                <hr>
      <div class="container mt-1">
              <!-- Button trigger modal -->
              <div class="row">
                  <div class="col-lg-9">
                  </div>
                  <div class="col-lg-3">
              
      
          <button type="button" id="button-addon2" data-bs-toggle="modal" data-bs-target="#exampleModal" class="btn btn-lg float-right mb-3" >
               Add Location
        </button>
        <!--Modal-->
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header bg-light">
          <h4 class="modal-title " id="exampleModalLabel">Location</h4>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </button>
        </div>
        <div class="modal-body">
            <form method="POST">
                <div class="form-group">
                    <label class="form-label">Name</label>
                    <input type="text" class="form-control" placeholder="User Name" name="name">
                </div>
                <div class="form-group">
                    <label class="form-label">Address</label>
                    <textarea name="address" id="" cols="20" rows="5" class="form-control" placeholder="Enter Address"></textarea>
                </div>
                
                <div class="modal-footer">
                  <button type="submit" class="btn" id="button-addon2" name="add">Add</button>
              </div>
            </form>
        </div>
       
      </div>
    </div>
  </div>

        </div>
        </div>

  
              <div class="card-body table-responsive p-0">
                  <div class="row">
                  <div class="col-lg-12">
                <table id="example" class="table table-striped  mx-10">
                  
                  <thead>
                     <tr>
                          <th>#</th>
                          <th>Name</th>                       
                          <th>Address</th>
                          <th>Operations</th>                         
                     </tr>
                      </thead>
                           <tbody>
                           <?php
                            $squery="select * from location";
                            $run=mysqli_query($conn,$squery);
                            while($row=mysqli_fetch_assoc($run)){

                        ?>
                           
                                <tr>
                                    <td><?php echo $row['id'] ?></td>
                                    <td><?php echo $row['name'] ?></td>
                                    <td><?php echo $row['location'] ?></td>                                            
                                    <td>
                                       <button type="button" class="btn btn-success btn-sm editbtn">Edit</button>

                                       <input type="hidden" class="delete_id_value" value="<?php echo $row['id']; ?>">
                                       <a href="javascript:void(0)" type="button" class="delete_btn_ajax btn btn-sm btn-danger"><i class="fas fa-trash"></i></a>
                                                    </td>
                                                </tr>
                                             
                        <?php
                            }
                            ?>
                                                 
                                            </tbody>
                </table>
                </div>
                </div>

              </div>
            </div>
            



            </div>
            <!-- flex-item -->
        </div>
        <!-- /flex-container -->
    </div>
            </div>
            <!-- flex-item -->
        </div>
        <!-- /flex-container -->
    </div>
</div>
               
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- footer -->
        <!-- ============================================================== -->
       <!--  <footer class="footer fixed">
            © 2020 Elegent Admin by <a href="https://www.wrappixel.com/">wrappixel.com</a>
        </footer> -->
        <!-- ============================================================== -->
        <!-- End footer -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
<div class="modal fade" id="myModalEdit" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Edit Location</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="container">

                                    
          <form  method="POST">
            <input type="hidden" name="update_id" id="update_id" />
            <div class="form-group">
            <label class="form-label" for="pname">Name</label>
            <input type="text" class="form-control" placeholder="Product Name" name="pname" id="pname">
            </div>


            <div class="form-group">
            <label class="form-label" for="pname">Address</label>
            <input type="text" class="form-control" placeholder="Address" name="address" id="address">
            </div>         
            <button type="submit" class="btn btn-success mt-2 float-end" name="edit">Edit</button>
          </form>
        </div>
      </div>
   
    </div>
  </div>
</div>

    

   


    </div>




  <!--delete-->
  <script>
    $(document).ready(function () {
        $(".delete_btn_ajax").click(function (e) { 
            e.preventDefault();
            var deleteid=$(this).closest('tr').find('.delete_id_value').val();
           // alert(deleteid);
            swal({
                    title: "Are you sure?",
                    text: "Once deleted, you will not be able to recover this Data!",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                })
                .then((willDelete) => {
                if (willDelete) {
                   $.ajax({
                       type: "POST",
                       url: "deletelocation.php",
                       data: {
                           "delete_btn_set":1,
                           "deleteid":deleteid,
                       },                      
                       success:function(response) {
                        swal("Deleted!", "Your Data is Deleted", "success", {
                            button: "Ok!",
                            }).then((result)=>{
                              location.reload();
                            });
                            
                       }
                   });
                } 
                });
            
        });
    });
</script>

    <script>
  $(document).ready(function(){
    $('.editbtn').on('click',function(){
      $('#myModalEdit').modal('show');

      $tr=$(this).closest('tr');

      var data=$tr.children('td').map(function(){
        return $(this).text();
      }).get();

      console.log(data);
      $('#update_id').val(data[0]);
      $('#pname').val(data[1]);
      $('#address').val(data[2]);
    });
  });

</script>






<?php 


 include 'footer.php';


  if(isset($_POST['add'])){
    $name=$_POST['name'];
    $address=$_POST['address'];

    $sql="insert into location (name,location) values('$name','$address')";
    $query=mysqli_query($conn,$sql);
    if($query){
      ?>
      <script>
      window.location = "<?php echo $app_url.'/location.php' ?>";
    </script>
      <?php
    }else{
      echo "<script>alert('Not inserted') </script>";
    }
  }

  //Edit
  if(isset($_POST['edit'])){
    $id=$_POST['update_id'];
    $name=$_POST['pname'];
    $address=$_POST['address'];

    $sqli="update location set name='$name',location='$address' where id='$id'";
    $query_update=mysqli_query($conn,$sqli);
    if($query_update){
      ?>
      <script>
      window.location = "<?php echo $app_url.'/location.php' ?>";
    </script>
      <?php
    }else{
      echo "<script>alert('Not inserted') </script>";
    }
  }

?>