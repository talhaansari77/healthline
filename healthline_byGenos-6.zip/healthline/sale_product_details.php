<?php

include_once "connection.php";

if (isset($_POST["submit"])) {

    // getting daTa from post
    $customer = $_POST["cus_name"];
    $billmaker = $_POST["salesman"];
    $bill_no = $_POST["bill_no"];
    $status = $_POST["status"];
    $subtotal = floatval($_POST["sub2"]);
    $distotal = floatval($_POST["distotal"]);
    $grandtotal = floatval($_POST["grandtotal"]);
    $paid = floatval($_POST["paid"]);
    $remaining = $grandtotal - $paid;

    if ($distotal != null && $grandtotal != null) {

        $sql = "INSERT INTO sale_product_details (`customer`, `bill_id`, `status`, `sub_total`, `discount_total`, `grand_total`, `paid`, `remaining`, `billmaker`) 
    VALUE('$customer','$bill_no','$status','$subtotal','$distotal','$grandtotal','$paid','$remaining','$billmaker')";

        $conn->query($sql);
        echo "<script>window.location = 'billS_view_all.php?msg=ok'</script>";
    } else {
        echo "<script>window.location = 'sale.php?msg=no&ed_rc=" . $bill_no . "'</script>";
    }
}
if (isset($_REQUEST["return"])) {

    // getting daTa from post
    // $customer = $_POST["cus_name"];
    // $billmaker = $_POST["salesman"];
    $bill_no = $_REQUEST["bill_no"];
    // $status = $_POST["status"];
    // $subtotal = floatval($_POST["sub2"]);
    // $distotal = floatval($_POST["distotal"]);
    // $grandtotal = floatval($_POST["grandtotal"]);
    // $paid = floatval($_POST["paid"]);
    // $remaining = $grandtotal - $paid;

    // if($conn->query("SELECT * FROM sale_product_details bill_id='$bill_no'")->num_rows >0){

    // }

    $result = $conn->query("SELECT * FROM sale_items WHERE bill_id='$bill_no' ");



    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $rqty = intval($row['quantity']);
            $name = $row['item_name'];

            $conn->query("UPDATE product SET opening_stock=opening_stock +'$rqty' WHERE product_name='$name'");
            $conn->query("UPDATE sale_items SET `status`='returned' WHERE bill_id='$bill_no'");
            $conn->query("UPDATE sale_product_details SET `status`='returned' WHERE bill_id='$bill_no'");
            echo "<script>window.location = 'billS_view_all.php?msg=ok'</script>";
        }
    } else {
        echo "<script>window.location = 'sale.php?msg=no'</script>";
    }
}
