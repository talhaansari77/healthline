<?php
include 'connection.php';
define("TITLE", "Sale");
define("PAGE", "Sale");
include_once 'header.php';




?>


<div class="body-section">
    <div class="container">


        <div class="card">
            <div class="card-header border-0">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12 mt-5">

                            <h2 style="float: left;">Purchase Records</h2>

                            <a style="float: right;" href="purchase.php" class="btn btn-success"> <i class="fas fa-plus"></i> Add purchase</a>


                        </div>
                    </div>
                </div>
                <div class="container mt-1">
                    <!-- Button trigger modal -->
                    <!-- <div class="row ">
            <div class="col-lg-9 mt-2 mb-3">
              <div class="input-group ">
                <div class="form-outline">
                  <input type="search" id="form1" class="form-control" placeholder="Search">

                </div>
                <div>
                  <button type="button" class="btn" id="button-addon2">
                    <i class="fas fa-search"></i>
                  </button>
                </div>
              </div>
            </div>

          </div> -->


                    <div class="card-body table-responsive p-0">
                        <div class="row">
                            <div class="col-lg-12">
                                <table id="table" class="table table-striped  pt-3">

                                    <thead>
                                        <tr>

                                            <th>#</th>
                                            <th>Supplier Name</th>
                                            <th>Paid</th>
                                            <th>Remaining</th>
                                            <th>Total</th>
                                            <th>Status</th>
                                            <th>Date</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody id="tablebody">
                                        <?php

                                        $sql1 = "SELECT * FROM `products_detail` WHERE `status` != 'returned' ORDER BY `id` DESC";
                                        $result1 = $conn->query($sql1);

                                        if ($result1->num_rows > 0) {
                                            while ($row = $result1->fetch_assoc()) {

                                        ?>

                                                <tr>
                                                    <td><?php echo $row["id"] ?></td>
                                                    <td><?php echo $row["supplier"] ?></td>
                                                    <td><?php echo $row["paid"] ?></td>
                                                    <td><?php echo $row["remaining"] ?></td>
                                                    <td><?php echo $row["grand_total"] ?></td>
                                                    <td><?php echo $row["status"] ?></td>
                                                    <td><?php echo $row["date"] ?></td>
                                                    <td>
                                                        <a href="bill_viewp.php?bill_no=<?php echo $row['bill_id'] ?>" class="btn btn-primary">
                                                            <i class="fas fa-eye"></i>
                                                        </a>
                                                        <button id="del_bill" data-sid="<?php echo $row['bill_id'] ?>" class="btn btn-danger " data-toggle="modal" data-target="#Delete"><i class="fas fa-trash"></i></button>
                                                        <a href="bill_viewpprint.php?bill_no=<?php echo $row['bill_id'] ?>" class="btn btn-success">
                                                            <i class="fas fa-print"></i>
                                                        </a>
                                                    </td>
                                                </tr>
                                        <?php
                                            }
                                        }
                                        ?>

                                    </tbody>
                                </table>
                            </div>
                        </div>



                    </div>
                </div>




            </div>
            <!-- flex-item -->
        </div>
        <!-- /flex-container -->
    </div>
</div>



















<?php
include_once "footer.php";

?>

<!-- <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/jautocalc@1.3.1/dist/jautocalc.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.repeater/1.2.1/jquery.repeater.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.repeater/1.2.1/jquery.repeater.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert-dev.js"></script> -->

<script src="js_by_GENOS_1.js">
</script>

<script>
    
        
   
    $(document).on("click", "#del_bill", function() {

        var id = $(this).data("sid");


        
        // console.log(id);
        // if (confirm("Are You Sure")) {
        //     $.ajax({
        //         url: "deleteBill.php",
        //         type: "POST",
        //         data: {
        //             id: id
        //         },
        //         success: function(data) {
        //             $("#tablebody").html(data);
        //             // // mulqtyprice();
        //             // $("#main_form").trigger("reset");

        //         }
        //     });
        // }

        swal({
          title: "Are you sure?",
          text: "Once deleted, you will not be able to recover this Data!",
          icon: "warning",
          buttons: true,
          dangerMode: true,
        })
        .then((willDelete) => {
          if (willDelete) {
            $.ajax({
              type: "POST",
              url: "deleteBill.php",
              data: {
                    id: id
                },
              success: function(response) {
                swal("Deleted!", "Your Data is Deleted", "success", {
                  button: "Ok!",
                }).then((result) => {
                  location.reload();
                });

              }
            });
          }
        });

    



    });
</script>