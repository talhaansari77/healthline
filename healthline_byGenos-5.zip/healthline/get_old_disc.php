<?php

include_once "connection.php";

$name = $_POST['name'];
$result = $conn->query("SELECT * FROM sale_product_details WHERE customer='$name' ORDER BY date DESC LIMIT 1");
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $disprice = floatval($row['sub_total']) -  floatval($row['discount_total']);
    $disprice /= floatval($row['sub_total']);



    echo round($disprice * 100, 2);
} else {
    echo "Not Found";
}
