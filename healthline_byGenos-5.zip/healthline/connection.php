<?php
$username="root";
$password="";
$server="localhost";
$database="healthline";

$conn=mysqli_connect($server,$username,$password,$database);
$app_url="http://localhost/healthline";
// if($conn){
//     echo "<script>alert('connection') </script> ";
// }
?>