<?php
session_start();
if (!isset($_SESSION['email'])) {
  header('location:login.php');
}

include_once "connection.php";
$user_email = $_SESSION['email'];
$result = $conn->query("SELECT *,roles.id as roleid  FROM `login` INNER JOIN `roles` ON `login`.`role`=`roles`.`id` and `login`.`email`='$user_email' limit 1");
if ($result->num_rows > 0) {
  $valid_user = $result->fetch_assoc();
}

?>

<!DOCTYPE html>
<!-- Created by CodingLab |www.youtube.com/CodingLabYT-->
<html lang="en" dir="ltr">

<head>
  <meta charset="UTF-8">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <!--<title> Responsive Sidebar Menu  | CodingLab </title>-->
  <link rel="stylesheet" href="css/styles.css">
  <!-- Boxicons CDN Link -->
  <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" />

  <script src="https://unpkg.com/sweetalert@2.1.2/dist/sweetalert.min.js"></script>

  <script src="ckeditor/ckeditor.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.1/css/jquery.dataTables.css">


  <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.1/js/jquery.dataTables.js"></script>
</head>

<body>
  <div class="sidebar d-print-none">


    <ul class="nav-list ">
      <li>
        <a href="#">

          <span class="links_name"><img src="images/logo.png" alt="" height="90px" width="210px">
          </span>
        </a>

      </li>

      <?php if ($valid_user['dashboard'] != 0) {
      ?>
        <li>
          <a href="dashboard.php">
            <i class='bx bx-grid-alt'></i>

            <span class="links_name">Dashboard</span>
          </a>
          <span class="tooltip">Dashboard</span>
        </li>

      <?php
      }

      ?>


      <?php if ($valid_user['report'] != 0) {
      ?>
        <li class=" dropdown">
          <a href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            <i class="fas fa-file-alt"></i>

            <span class="links_name">Reports</span>
          </a>
          <span class="tooltip">Reports</span>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item" href="saleReport.php">Sale Reports</a></li>
            <li><a class="dropdown-item" href="purchaseReport.php">Purchase Report</a></li>
            <li><a class="dropdown-item" href="productReport.php">Product Report</a></li>
            <li><a class="dropdown-item" href="supplierReport.php">Supplier Report</a></li>
            <li><a class="dropdown-item" href="customerReport.php">Customer Report</a></li>
            <li><a class="dropdown-item" href="trendReport.php">Trend Report</a></li>

          </ul>
        </li>
      <?php
      }

      ?>

      <?php if ($valid_user['product'] != 0) {
      ?>
        <li>
          <a href="product.php">
            <i class="fab fa-product-hunt"></i>
            <span class="links_name">Products</span>
          </a>
          <span class="tooltip">Products</span>
        </li>
      <?php
      }

      ?>
      <?php if ($valid_user['user_management'] != 0) {
      ?>
        <li>
          <a href="brand.php">
            <i class="fab fa-btc"></i>


            <span class="links_name">Manufecturer</span>
          </a>
          <span class="tooltip">Manufecturer</span>
        </li>
      <?php
      }

      ?>

      <!-- <li>
        <a href="unit.php">
          <i class="fab fa-uniregistry"></i>
          <span class="links_name">Unit</span>
        </a>
        <span class="tooltip">Unit</span>
      </li> -->

      <?php if ($valid_user['category'] != 0) {
      ?>
        <li class=" dropdown">
          <a href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            <i class="fab fa-cuttlefish"></i>

            <span class="links_name">Categories</span>
          </a>
          <span class="tooltip">Categories</span>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item" href="cat.php">Category</a></li>
            <li><a class="dropdown-item" href="subcat.php">Sub-Category</a></li>


          </ul>
        </li>
      <?php
      }

      ?>
      <?php if ($valid_user['projection'] != 0) {
      ?>
        <li class=" dropdown">
          <a href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            <i class="fas fa-book"></i>

            <span class="links_name">Projections</span>
          </a>
          <span class="tooltip">Purchase</span>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item" href="projperiod.php">Projection Period</a></li>
            <li><a class="dropdown-item" href="reorder.php">Re-Order Level</a></li>


          </ul>
        </li>
      <?php
      }

      ?>
      <?php if ($valid_user['user_management'] != 0) {
      ?>
        <li class=" dropdown">
          <a href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            <i class="fas fa-user"></i>

            <span class="links_name">User Management</span>
          </a>
          <span class="tooltip">User Management</span>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item" href="user.php">User Management</a></li>
            <li><a class="dropdown-item" href="user1.php">Users</a></li>
            <li><a class="dropdown-item" href="roles.php">Roles</a></li>


          </ul>
        </li>
      <?php
      }

      ?>


      <?php if ($valid_user['dashboard'] != 0) {
      ?>
        <li>
          <a href="location.php">
            <i class="fas fa-map-marker-alt"></i>
            <span class="links_name">Location</span>
          </a>
          <span class="tooltip">Location</span>
        </li>
      <?php
      }

      ?>

      <?php if ($valid_user['supplier'] != 0) {
      ?>
        <li>
          <a href="supplier.php">
            <i class="fas fa-parachute-box"></i>
            <span class="links_name">Supplier</span>
          </a>
          <span class="tooltip">Supplier</span>
        </li>
      <?php
      }

      ?>
      <?php if ($valid_user['customer'] != 0) {
      ?>
        <li>
          <a href="customer.php">
            <i class="fas fa-user-tie"></i>
            <span class="links_name">Customer</span>
          </a>
          <span class="tooltip">Customer</span>
        </li>
      <?php
      }

      ?>


      <?php if ($valid_user['stock'] != 0) {
      ?>
        <li>
          <a href="stock.php">
            <i class="fas fa-layer-group"></i>


            <span class="links_name">Stock</span>
          </a>
          <span class="tooltip">Stock</span>
        </li>
      <?php
      }

      ?>
      <?php if ($valid_user['sale'] != 0) {
      ?>
        <li>
          <a href="bills_view_all.php">
            <i class="fas fa-clipboard-check"></i>
            <span class="links_name">Sale</span>
          </a>
          <span class="tooltip">Sale</span>
        </li>
      <?php
      }

      ?>
      <?php if ($valid_user['purchase'] != 0) {
      ?>
        <li>
          <a href="billS_view_allp.php">
            <i class="fas fa-cart-arrow-down"></i>
            <span class="links_name">Purchase</span>
          </a>
          <span class="tooltip">Purchase</span>
        </li>
      <?php
      }

      ?>



      <li>



    </ul>
  </div>
  <div class="top-section container-fluid d-print-none">
    <div class="row shadow">
      <div class="col-lg-1">
        <div class="logo-details">
          <i class='bx bx-menu' id="btn"></i>

        </div>
      </div>
      <div class="col-lg-8 col-sm-12">

      </div>
      <div class="col-lg-3 col-sm-12  text-end">
        <?php echo $_SESSION["username"] ?>
        <button class="btn " type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
          <img src="images/dummy-dp.png" style="border-radius: 100px;" class="m-4" alt="" height="50px" width="60px">
        </button>
        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
          <li class="dropdown-item" data-bs-toggle="modal" data-bs-target="#myModalProfile" style="cursor: pointer;">Profile</li>
          <!-- <li class="dropdown-item" data-bs-toggle="modal" data-bs-target="#myModalCompany" style="cursor: pointer;"> Company Profile</li> -->
          <li class="dropdown-item" data-bs-toggle="modal" data-bs-target="#myModalLogout" style="cursor: pointer;">Log Out</li>
        </ul>







      </div>
    </div>
  </div>

  <!--profile-->
  <div class="modal fade" id="myModalProfile" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Profile</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div class="container mt-1">


            <div class="row mt-3">
              <form action="dashboard.php" method="POST">
                <div class="form-group">

                  <label class="fw-bold">User Name:</label>
                  <input type="text" class="form-control mb-2" placeholder="User Name" name="uname" value="<?php echo $_SESSION["username"] ?>">
                  <label class="fw-bold">E-mail:</label><br>
                  <input type="text" class="form-control mb-2" placeholder="E-mail" name="email" value="<?php echo $_SESSION["email"] ?>">
                  <label class="fw-bold">Password:</label><br>
                  <input type="password" class="form-control mb-2" placeholder="Password" name="password">

                  <label class="fw-bold">Phone No:</label><br>
                  <input type="text" class="form-control mb-2" placeholder="Ph no." name="ph" value="<?php echo $_SESSION["phone"] ?>">

                  <label class="fw-bold ">Address:</label>
                  <textarea class="form-control mb-2" placeholder="Address" name="address"><?php echo $_SESSION["address"] ?></textarea>



                </div>


            </div>


            <div class="row mt-3 mb-3">
              <div class="col-lg-4">

              </div>
              <div class="col-lg-4 ">
                <input type="submit" id="button-addon2" class="form-control  " name="save" value="Save">
              </div>
              <div class="col-lg-4">

              </div>

            </div>
            </form>


          </div>

          </from>
        </div>

      </div>

    </div>
  </div>
  </div>


  <!--company-->
  <div class="modal fade" id="myModalCompany" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Company Profile</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div class="container mt-1">


            <div class="row mt-3">
              <form method="POST">
                <div class="form-group">

                  <label class="fw-bold">Name:</label>
                  <input type="text" class="form-control mb-2" placeholder=" Name" name="name">
                  <label class="fw-bold">Logo:</label>
                  <input type="file" name="picture" class="form-control mb-2">

                  <label class="fw-bold">Phone No:</label><br>
                  <input type="text" class="form-control mb-2" placeholder="Ph no." name="ph">
                  <label class="fw-bold">E-mail:</label><br>
                  <input type="text" class="form-control mb-2" placeholder="E-mail" name="email">
                  <label class="fw-bold ">Address:</label>
                  <textarea class="form-control mb-2" placeholder="Address" name="address"></textarea>



                </div>

              </form>
            </div>


            <div class="row mt-3 mb-3">
              <div class="col-lg-4">

              </div>
              <div class="col-lg-4 ">
                <input type="submit" id="button-addon2" class="form-control  " name="save" value="Save">
              </div>
              <div class="col-lg-4">

              </div>

            </div>



          </div>

          </from>
        </div>

      </div>

    </div>
  </div>
  </div>

  <!--logout-->
  <div class="modal fade" id="myModalLogout" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Log Out</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div class="container">
            <form action="logout.php" method="POST">
              <p>Want to Log Out?</p>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                <button type="submit" class="btn " id="button-addon2">Log Out</button>
              </div>
            </form>
          </div>

        </div>

      </div>
    </div>
  </div>