<?php
include_once "connection.php";
$from = $_GET["from"];
$to = $_GET["to"];
$name = $_GET["name"];

$current_date = date("Y-m-d");

$result =$conn->query("SELECT * FROM `supplier` where `name`='$name' and `licence_exp` >= '$current_date' limit 1 ");
if($result->num_rows ==0){
echo "<script>window.location='simplesupplierbill.php?from=".$from.'&to='.$to.'&name='.$name."'</script>";
}

?>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sales Bill</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
</head>

<body>


    <table class="table table-bordered">
        <tr>
            <th>
                <h1>
                    <center>Health Line : Pharmacy</center>

                </h1>
                <center>
                    X-69 People's Colony Gujranwala
                </center>
                <center>
                    Mobile: 0345-6479781 0300-6441592
                </center>
            </th>
        </tr>

        <tr>
            <th>
                <center>
                    From: <?php echo $from ?>
                    &nbsp;&nbsp;
                    To: <?php echo $to ?>
                </center>
            </th>
        </tr>


    </table>
    <table class="table table-bordered">
        <tr>
            <!-- <td></td> -->
            <th>No#</th>
            <th>Name</th>
            <th>Product</th>
            <th>Quantity</th>
            <th>Price</th>
            <th>Sub-Total</th>
            <th>date</th>
            <!-- <th>Remaining</th> -->
        </tr>
        <?php
        $total = 0;
        $price = 0;
        $qty = 0;

        $result = $conn->query("SELECT *,SUM(quantity) as quantity, SUM(price) as price, SUM(total) as total FROM `items` WHERE date BETWEEN '$from' AND '$to' AND `supplier`='$name' and `status` != 'returned' GROUP BY `date`");
        while ($row = $result->fetch_assoc()) {
            $total += floatval($row["total"]);
            $price += floatval($row["price"]);
            $qty += floatval($row["quantity"]);
        ?>
            <tr>
                <td> <?php echo $row["id"] ?> </td>
                <td> <?php echo $row["supplier"] ?> </td>
                <td> <?php echo $row["item_name"] ?> </td>
                <td> <?php echo $row["quantity"] ?> </td>
                <td> <?php echo $row["price"] ?> </td>
                <td> <?php echo $row["total"] ?> </td>
                <td> <?php echo $row["date"] ?> </td>


            </tr>
        <?php
        }
        ?>

    </table>
    <table class="table table-bordered">
        <tr>
            <th>
                <center>
                    Price : <?php echo $price ?> &nbsp;&nbsp;&nbsp;
                    Quantity: <?php echo $qty ?> &nbsp;&nbsp;&nbsp;
                    Total : <?php echo $total ?> &nbsp;&nbsp;&nbsp;
                </center>
            </th>
        </tr>
    </table>
</body>


<div class="container-fluid " style="margin-top: 50%;text-align: justify;">
    <!-- <hr style="background-color: black;"> -->
    <p>
        1. Hafiz M Khalid, Being a person resident in Pakistan carring on bussiness at X/69, People colony Gujranwala, under the name of Health Line Pharmacy (GRW) do give warranty of behalf of Distributer/Authotized Agent that the drugs mentioned in this invoice as sold by us do not contravene in any way the provision of section 23 of Drug Act 1976.
    </p>

    <div class="row">
        <div class="col-6">
            <p style="text-align: justify;">
                A-For Dated we must be informed six months prior to expiry
                <br>
                B-This warranty does not apply to unani, homeopathic, bio-chemic, herbal, and general items including syringes, medical disposable if any mentioned in this invoice.

            </p>
        </div>

        <div class="col-6" >
            <h3 style="margin-top: 5rem;margin-left: 2rem;"><i>Signature:</i> _______________
        </h3>

        </div>
    </div>

</div>


</html>

<script>
    window.print();
</script>



<!-- <div class="container-fluid " style="margin-top: 50%;text-align: justify;">
 
    <p>
        1. Hafiz M Khalid, Being a person resident in Pakistan carring on bussiness at X/69, People colony Gujranwala, under the name of Health Line Pharmacy (GRW) do give warranty of behalf of Distributer/Authotized Agent that the drugs mentioned in this invoice as sold by us do not contravene in any way the provision of section 23 of Drug Act 1976.
    </p>

    <div class="row">
        <div class="col-6">
            <p style="text-align: justify;">
                A-For Dated we must be informed six months prior to expiry
                <br>
                B-This warranty does not apply to unani, homeopathic, bio-chemic, herbal, and general items including syringes, medical disposable if any mentioned in this invoice.

            </p>
        </div>

        <div class="col-6" >
            <h3 style="margin-top: 5rem;margin-left: 2rem;"><i>Signature:</i> _______________
        </h3>

        </div>
    </div>

</div> -->
