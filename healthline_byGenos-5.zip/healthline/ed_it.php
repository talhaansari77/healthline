<?php
include("connection.php");

require_once("header.php");

if (isset($_GET["id"])) {

    $sql = "SELECT * FROM sale_items where id= " . $_GET["id"];
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $bill = $result->fetch_assoc();
    } else {
        echo "<script>window.location = 'sale.php'</script>";
    }


    // $id = $_GET["id"];
    // $sql = "SELECT * FROM products where id =" . $id;
    // $result = $connection->query($sql);
    // if ($result->num_rows > 0) {

    //     $productitem = $result->fetch_assoc();
    // }



} else {
    echo "<script>window.location = 'sale.php'</script>";
}

?>


<div class="body-section">
    <div class="container mt-5">
        <form action="ced_it.php" method="POST">
            <div class="col-lg-12 mt-5">
                <div class="modal-header">
                    <h4 class="modal-title" id="myModalLabel33">Edit Bill</h4>

                </div>

                <input type="hidden" name="id" value="<?php echo $_GET["id"] ?>">
                <input type="hidden" name="bill_no" value="<?php echo $_GET["bill_no"] ?>">
                <div class="row m-5">
                    <div class="col-lg-4">
                        <label class="form-label" id="">Product Name</label>
                        <select class="form-select" id="pname" name="pname">
                            <optgroup label="Select Product">
                                <?php
                                $sql = "SELECT * FROM product ";
                                $result = $conn->query($sql);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                ?>
                                        <option value="<?php echo $row['product_name'] ?>">
                                            <?php echo $row['product_name'] ?>
                                        </option>
                                <?php

                                    }
                                }
                                ?>
                            </optgroup>
                        </select>
                    </div>



                    <div class="col-lg-4">
                        <label class="form-label" id="">Quantity</label>
                        <input class="form-control" onkeyup="mulqtyprice()" min="1" pattern="[1-9][0-9]*" type="number" value="<?php echo $bill['quantity'] ?>" name="pqty" id="pqty">

                    </div>


                    <div class="col-lg-4">
                        <label class="form-label" id="">Price</label>
                        <input class="form-control" min="0" onkeyup="mulqtyprice()" pattern="[1-9][0-9]*" type="number" value="<?php echo $bill['price'] ?>" name="pprice" id="pprice">

                    </div>
                </div>

                <div class="row m-5 ">
                    <div class="form-action-buttons col-lg-12">
                        <label class="form-label"></label>
                        <input type="submit" value="Edit" name="submit" style="float: right;" class="btn btn-primary btn-lg">
                    </div>
                </div>


            </div>
        </form>
    </div>
</div>







<?php
require_once("footer.php");
?>