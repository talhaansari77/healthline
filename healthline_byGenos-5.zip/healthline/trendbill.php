<?php
session_start();
define("TITLE", "Sale Bill");
define("PAGE", "Sale Bill");
include 'connection.php';


?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
<style>
    .mm {
        margin-top: 150px;
    }

    .mn {
        margin-top: -40px;
    }

    .m {
        margin-top: -100px;
    }
</style>


<table class="table ">
        <tr>
            <th>
                <h1>
                    <center>Health Line : Pharmacy</center>
                </h1>
            </th>
        </tr>
        <tr>
            <th>
                <center>
                    Trend Report
                </center>
            </th>
        </tr>
      


    </table>


        <div class="row">
            <div class="col-md-12">


                <div class="">
                    <table class="table table-bordered ">
                        <thead>

                            <tr>
                                <th>Product</th>
                                <th>Quantity</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $startdate = $_SESSION['saleStart'];
                            $enddate = $_SESSION['saleEnd'];
                            $query_product = mysqli_query($conn, "select * from product");
                            while ($row_product = mysqli_fetch_assoc($query_product)) {
                                $product = $row_product['product_name'];

                                $sql = "SELECT quantity FROM sale_items WHERE item_name='$product' AND date BETWEEN '$startdate' AND '$enddate'";
                                $result = $conn->query($sql);

                                if ($result->num_rows > 0) {

                                    $total = 0;
                                    while ($row = mysqli_fetch_assoc($result)) {

                                        $quantity = $row['quantity'];
                                        $total = $total + $quantity;
                                        $_SESSION['product'] = $product;
                                        $_SESSION['total'] = $total;
                                    }
                            ?>

                                   
                        </tbody>

                    </table>
                    <table class="table">
                                   <tr>
                                       <td><?php echo $product; ?></td>
                                       <td><?php echo $total; ?></td>
                                   </tr>
                                   </table>
            <?php

                                }
                            }
            ?>
          

            </tbody>
            </table>
            <a href="trendReport.php" class="btn btn-sm btn-primary d-print-none mt-3">Back</a>
                </div>
            </div>


        </div>



<script>
    // window.print();
</script>

<?php
include 'footer.php';

?>