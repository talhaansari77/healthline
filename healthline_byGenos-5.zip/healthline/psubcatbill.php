<?php 
session_start();
if(!isset($_SESSION['email'])){
    header('location:login.php');
   }define("TITLE","Product Bill");
define("PAGE","Product Bill");
include 'connection.php';
include 'header.php';

?>
<style>
    .mm{
        margin-top:150px;
    }
    .mn{
        margin-top:-40px;
    }
</style>
<div class="body-section">
<div class="container ">
        
<a href="productReport.php" class="btn btn-sm btn-primary d-print-none mt-3">Back</a>
    <div class="row">
    <table class="table">
                <tr>
                   <td>
                    <div class="col-md-6 bg-dark ml-5">
                        
                    <img src="images/logo.png" alt="" style="width:300px; height:200px;">
                    </div>
                    </td>
                    <td>
                      
                        <div class="col-md-6 ">
                            <h4 class="mt-5 text-center st">" We Believe In Quality "</h4>
                            <h4 class="text-center"></h4>
                            <h6 class="text-center">Mobile No:</h6>                           
                            <h6 class="text-center">Email: </h6>
                            <h6 class="text-center">Date: _________________</h6>
                        </div>
                    </td>
                </tr>
            </table>
    </div>

        <div class="row">
            <div class="col-md-12">

           
              <div class="card-body table-responsive ">
                    <table id="table" class="table table-bordered pt-2" >
                        <thead>

                        <tr>                        
                         
                            <th scope="col">#</th>
                            <th scope="col">Product</th>
                            <th scope="col">Quantity</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                    $name=$_SESSION['name'];                     
                    $query=mysqli_query($conn,"SELECT * FROM product WHERE subcategories='$name'");
                    $total=0;
                    while($row =mysqli_fetch_assoc($query)){
                        $total++;
                    ?>
                    <tr>
                        <td><?php echo $total;?></td>
                        <td><?php echo $row["product_name"]?></td>
                        <td><?php echo $row["alter_quantity"];?></td>
                    </tr>
                    <?php
                    }
                
?>
        <tr></tr>
                
                        </tbody>
                    </table>
                  
              </div>
            </div>
            

            </div>
        </div>

            </div>
            <!-- flex-item -->
        </div>
        <!-- /flex-container -->
    </div>
            </div>
            <!-- flex-item -->
        </div>
        <!-- /flex-container -->
    </div>
</div>
        
        </div>
      
    </div>




    </div>



<script>
    window.print();
</script>

<?php 
include 'footer.php';

?>