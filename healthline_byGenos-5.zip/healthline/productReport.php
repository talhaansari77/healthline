<?php 
// session_start();
define("TITLE","Sale Report");
define("PAGE","Sale Report");
include 'connection.php';
include 'header.php';

?>
<style>
    .mm{
        margin-top:150px;
    }
    .mn{
        margin-top:-40px;
    }
</style>

<div class="body-section">
<div class="container ">
         <div class="card mm">
              <div class="card-header border-0">
                <h3 class="card-title">Product Report</h3>
                <!-- Button trigger modal -->
               
          <div class="container mt-1">
            
                    <form action="" method="POST" class="d-print-none">
                        <h4 class="mt-2 text-primary">Check Product Through Category</h4>
                        <table class="table">
                            <tr>
                                <td>
                                <div class="form-group">
                            <select name="name" id="name" class="form-control">
                                <option>Select Category</option>
                                <?php
                                $query=mysqli_query($conn,"select * from categories");
                                while($rows=mysqli_fetch_assoc($query)){
                                    ?>
                                    <option value="<?php echo $rows['name'] ?>"><?php echo $rows['name'] ?></option>
                                    <?php
                                }

                                ?>
                            </select>
                        </div>
                                </td>

                                
                                
                                <td>
                                <div class="form-group">
                                    <input type="submit" class="btn btn-primary" name="searchsubmit" value="Search">
                                </div>
                                </td>
                            </tr>
                        </table>
                                                                                     
                    </form>

                    <!-- //check stock through product name.. -->

                    <form action="" method="POST" class="d-print-none">
                        <h4 class="mt-2 text-primary">Check Product Through Sub Category</h4>
                        <table class="table">
                            <tr>
                                <td>
                                <div class="form-group">
                            <select name="name" id="name" class="form-control">
                                <option>Select Sub Category</option>
                                <?php
                                $query=mysqli_query($conn,"select * from subcategories");
                                while($rows=mysqli_fetch_assoc($query)){
                                    ?>
                                    <option value="<?php echo $rows['sub'] ?>"><?php echo $rows['sub'] ?></option>
                                    <?php
                                }

                                ?>
                            </select>
                        </div>
                                </td>

                                
                                
                                <td>
                                <div class="form-group">
                                    <input type="submit" class="btn btn-primary" name="searchStock" value="Search">
                                </div>
                                </td>
                            </tr>
                        </table>
                                                                                     
                    </form>
                    <!-- //check stock through product name.. -->

                    <!-- //check product through brand.. -->
                    <form action="" method="POST" class="d-print-none">
                        <h4 class="mt-2 text-primary">Check Product Menufecturer</h4>
                        <table class="table">
                            <tr>
                                <td>
                                <div class="form-group">
                            <select name="name" id="name" class="form-control">
                                <option>Select Menufecturer</option>
                                <?php
                                $query=mysqli_query($conn,"select * from brands");
                                while($rows=mysqli_fetch_assoc($query)){
                                    ?>
                                    <option value="<?php echo $rows['name'] ?>"><?php echo $rows['name'] ?></option>
                                    <?php
                                }

                                ?>
                            </select>
                        </div>
                                </td>

                                
                                
                                <td>
                                <div class="form-group">
                                    <input type="submit" class="btn btn-primary" name="searchBrand" value="Search">
                                </div>
                                </td>
                            </tr>
                        </table>
                                                                                     
                    </form>
                    <!-- //check product through brand.. -->
 <?php


if(isset($_REQUEST['searchBrand'])){
   $name = $_REQUEST['name'];
   $sql = "SELECT * FROM product WHERE manufacturer='$name'";
   $result = $conn->query($sql);
   if($result->num_rows > 0){
     $_SESSION['name']=$name;
    echo '
    <table>
 <tr>
   <td><a href="brandbill.php?manufacturer='."$name".'" class="btn btn-danger mt-2">Print </a></td>
 </tr>
 </table>
 <p class=" bg-dark text-white p-2 mt-4">Details</p>
 
     <table class="table">
     <thead>
       <tr>
         <th scope="col">ID</th>
         <th scope="col">Product Name</th>
         <th scope="col">Quantity</th>
       </tr>
     </thead>
         <tbody>';
         while($row = $result->fetch_assoc()){
           echo '<tr>
           <th scope="row">'.$row["id"].'</th>
           <td>'.$row["product_name"].'</td>
           <td>'.$row["alter_quantity"].'</td>
             </tr>';
           }
           echo '</tbody>
     </table>';
 } else {
   echo "<div class='alert alert-warning col-sm-6 ml-5 mt-2' role='alert'> No Records Found ! </div>";
 }
}

 if(isset($_REQUEST['searchsubmit'])){
    $name = $_REQUEST['name'];
    $sql = "SELECT * FROM product WHERE catgories='$name'";
    $result = $conn->query($sql);
    if($result->num_rows > 0){
      $_SESSION['name']=$name;
     echo '
     <table>
  <tr>
    <td><a href="brandbill.php?catgories='."$name".'" class="btn btn-danger mt-2">Print </a></td>
  </tr>
  </table>
  <p class=" bg-dark text-white p-2 mt-4">Details</p>
  
      <table class="table">
      <thead>
        <tr>
          <th scope="col">ID</th>
          <th scope="col">Product Name</th>
          <th scope="col">Quantity</th>
        </tr>
      </thead>
          <tbody>';
          while($row = $result->fetch_assoc()){
            echo '<tr>
            <th scope="row">'.$row["id"].'</th>
            <td>'.$row["product_name"].'</td>
            <td>'.$row["alter_quantity"].'</td>
              </tr>';
            }
            echo '</tbody>
      </table>';
  } else {
    echo "<div class='alert alert-warning col-sm-6 ml-5 mt-2' role='alert'> No Records Found ! </div>";
  }
 }

 //through product name

 if(isset($_REQUEST['searchStock'])){
    $name = $_REQUEST['name'];
    $sql = "SELECT * FROM product WHERE subcategories='$name'";
    $result = $conn->query($sql);
    if($result->num_rows > 0){
      $_SESSION['name']=$name;
     echo '
     <table>
  <tr>
    <td><a href="brandbill.php?subcategories='."$name".'" class="btn btn-danger mt-2">Print </a></td>
  </tr>
  </table>
  <p class=" bg-dark text-white p-2 mt-4">Details</p>
  
      <table class="table">
      <thead>
        <tr>
          <th scope="col">ID</th>
          <th scope="col">Product Name</th>
          <th scope="col">Quantity</th>
        </tr>
      </thead>
          <tbody>';
          $total=0;
          $i=0;
          while($row = $result->fetch_assoc()){
              $i++;
            $quantity=$row['alter_quantity'];
            $total=$total+$quantity;
            $_SESSION['total']=$total;
          }
            echo '<tr>
            <th scope="row">'.$i.'</th>
            <td>'.$name.'</td>
            <td>'.$total.'</td>
              </tr>';
            
            echo '</tbody>
      </table>';
  } else {
      
    echo "<div class='alert alert-warning col-sm-6 ml-5 mt-2' role='alert'> No Records Found ! </div>";
  }
 }
  ?>

  
               

    <hr>
              <div class="card-body table-responsive">
                    <table id="table" class="table table-bordered pt-2">
                       
                    </table>
              </div>
            </div>
            



            </div>
            <!-- flex-item -->
        </div>
        <!-- /flex-container -->
    </div>
            </div>
            <!-- flex-item -->
        </div>
        <!-- /flex-container -->
    </div>
</div>
        
        </div>
      
    </div>




    </div>






 
<?php 
include 'footer.php';

?>