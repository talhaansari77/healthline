<?php
include_once "connection.php";


if (isset($_POST["id"])) {
$sql = "DELETE FROM sale_product_details WHERE bill_id= " . $_POST["id"];
$conn->query($sql);
$sql = "DELETE FROM sale_items WHERE bill_id= " . $_POST["id"];
$conn->query($sql);
}

if (isset($_GET["bill_no"])) {
    $sql = "DELETE FROM sale_product_details WHERE bill_id= " . $_GET["bill_no"];
    $conn->query($sql);
    $sql = "DELETE FROM sale_items WHERE bill_id= " . $_GET["bill_no"];
    $conn->query($sql);

    echo "<script>window.location = 'customerview.php?idv=".$_GET["idv"]."'</script>";
}


$sql1 = "SELECT * FROM `sale_product_details` where `status` != 'returned' ORDER BY `id` DESC";
$result1 = $conn->query($sql1);

if ($result1->num_rows > 0) {
    while ($row = $result1->fetch_assoc()) {

?>

        <tr>
            <td><?php echo $row["id"] ?></td>
            <td><?php echo $row["customer"] ?></td>
            <td><?php echo $row["paid"] ?></td>
            <td><?php echo $row["remaining"] ?></td>
            <td><?php echo $row["grand_total"] ?></td>
            <td><?php echo $row["status"] ?></td>
            <td><?php echo $row["date"] ?></td>
            <td>
                <a href="bill_viewp.php?bill_no=<?php echo $row['bill_id'] ?>" class="btn btn-primary">
                    <i class="fas fa-eye"></i>
                </a>
                <button id="del_bill" data-sid="<?php echo $row['bill_id'] ?>" class="btn btn-danger " data-toggle="modal" data-target="#Delete"><i class="fas fa-trash"></i></button>
                <a href="bill_view.php?bill_no=<?php echo $row['bill_id'] ?>" class="btn btn-success">
                    <i class="fas fa-print"></i>
                </a>
            </td>
        </tr>
<?php
    }
}
?>