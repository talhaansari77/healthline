<?php
    include 'connection.php';
    if(isset($_POST['delete']))
    {
        $del_id=$_POST['deleteid'];
        $sqls="delete from stock where bill_id='$del_id'";
        mysqli_query($conn,$sqls);
        $sqli="delete from products_detail where bill_id='$del_id'";
        mysqli_query($conn,$sqli);
        $sql="delete from items where bill_id='$del_id'";
        mysqli_query($conn,$sql);
        ?>
        <script>
            window.location="purchase.php";
        </script>
        <?php
    }
    
?>