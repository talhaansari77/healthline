<?php

// include_once("header.php");
include_once("connection.php");

$bill_no = "";

if (isset($_GET["bill_no"])) {


    $id = $_GET["bill_no"];
    // echo $_POST["formData"];
    $sql = "SELECT * FROM sale_items WHERE bill_id=" . $id;

    $result = $conn->query($sql);
    if ($result->num_rows <= 0) {
        echo "<script>window.location = 'bills_view_all.php?msg=no'</script>";
    } else {
        $bill_no = $id;
    }


    // var for total

    $rowid = 0;
    $totalprice = 0;
    $totalqty = 0;
    $grandtotal = 0;
}

?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
<table class="table ">
        <tr>
            <th>
                <h1>
                    <center>Health Line : Pharmacy</center>
                </h1>
            </th>
        </tr>
        <tr>
            <th>
                <center>
                    Bill Reference: <?php echo $bill_no?>
                </center>
            </th>
        </tr>
        


    </table>
        <!-- <div class="container"> -->
            <!-- <h2>Bill # <?php echo $bill_no ?>
                &nbsp;
                <a href="sale.php?ed_rc=<?php echo $bill_no ?>" class="btn btn-primary">Edit</a>
            </h2> -->



            <!-- here the table -->
            <table class='table table-striped'>
                <thead>
                    <tr>

                        <th>#</th>
                        <th>Product Name</th>
                        <th>Quantity</th>
                        <th>Price</th>
                        <th>Total</th>
                        <!-- <th>Action</th> -->
                    </tr>
                </thead>
                <tbody id="fromdb">

                    <?php

                    $sql1 = "SELECT * FROM `sale_items` WHERE `bill_id` = " . $bill_no;
                    $result1 = $conn->query($sql1);

                    if ($result1->num_rows > 0) {
                        while ($row = $result1->fetch_assoc()) {

                            $totalprice += intval($row["price"]);
                            $totalqty += intval($row["quantity"]);
                            $grandtotal += intval($row["total"]);
                            $rowid += 1;
                    ?>
                            <tr>
                                <td><?php echo $rowid ?></td>
                                <td><?php echo $row["item_name"] ?></td>
                                <td><?php echo $row["quantity"] ?></td>
                                <td><?php echo $row["price"] ?></td>
                                <td><?php echo $row["total"] ?></td>

                            </tr>
                    <?php
                        }
                    }
                    ?>

                    <tr>

                        <th>------</th>
                        <th>------</th>
                        <th><?php echo $totalqty ?></th>
                        <th><?php echo $totalprice ?> .Rs</th>
                        <th><?php echo $grandtotal ?> .Rs</th>

                        <!-- <th>Action</th> -->
                    </tr>

                </tbody>
            </table>
          
        <!-- </div> -->




<?php
include_once("footer.php");
?>

<script>
    window.print();
</script>