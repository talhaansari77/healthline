<?php

include 'connection.php';
define("TITLE", "Purchase");
define("PAGE", "Purchase");
include 'header.php';

// readding stock
$result = $conn->query("SELECT * FROM items WHERE bill_id NOT IN (SELECT bill_id FROM products_detail)");
if($result->num_rows > 0){
  while($row = $result->fetch_assoc()){
    $p1 = $row["item_name"];
    $p2 = $row["quantity"];
    $p3 = $row["bill_id"];
    $conn->query("UPDATE product SET opening_stock=opening_stock - '$p2' WHERE product_name='$p1'");
    $conn->query("DELETE FROM items where bill_id='$p3'");

  }
}





$total = 0;
$current_bill = "";

if (isset($_GET["ed_rc"])) {


  $id = $_GET["ed_rc"];
  // echo $_POST["formData"];
  $sql = "SELECT * FROM items WHERE bill_id=" . $id;

  $result = $conn->query($sql);
  if ($result->num_rows > 0) {

    $rec = $result->fetch_assoc();
    $current_bill = $rec["bill_no"];
  }
  $current_bill = $_GET["ed_rc"];
} else {
  $current_bill = date("Ymdhis");
}


?>

<div class="body-section">
  <div class="container mt-5">
<!-- error msg -->
<?php
    if (isset($_GET["msg"])) {
    ?>
      <div class="alert alert-danger alert-dismissible fade show" role="alert">
        Please Fill The Form <b>Correctly</b>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>


    <?php
    }
    ?>




    <!-- top row for showing bill No# -->
    <div class="row">
      <div class="col-12 col-md-6 order-md-1 order-last">
        Bill#
        <div>
          <!-- bill no -->
          <h4 class="bill_no" style="float: left;">
            <u><?php echo $current_bill ?></u>
            <a href="purchase.php" class="btn btn-primary">New</a>
            <a href="billS_view_allp.php?bill_no=<?php echo $current_bill ?>" class="btn btn-danger">Bills</a>
          </h4>
        </div>

      </div>
    </div>


    <section class="section">
      <div class="card">
        <form action="product_details.php" method="POST" id="main_form">
          <div class="card-header">
            <div class="container">
              <div class="row">
                <!-- <div class="col-lg-12 mt-5">
                            
                            <h2 style="float: right;">Total: <?php //echo $total_expense 
                                                              ?></h2>


                        </div> -->
                <div class="col-lg-12 ">


                  <div class="modal-header">
                    <div class="col-lg-2" style="margin-left: 3rem;">
                      <label class="form-label" id="">Supplier Name</label>
                      <select class="form-control px-2" onchange="get_old_price(), get_old_disc()" name="cus_name" id="cus_name" required="">
                        <optgroup label="Select Supplier">
                          <?php
                          $sqls = mysqli_query($conn, "select * from supplier");
                          while ($rows = mysqli_fetch_assoc($sqls)) {
                          ?>
                            <option value="<?php echo $rows['name']; ?>">
                              <?php echo $rows['name']; ?>
                            </option>
                          <?php
                          }

                          ?>
                        </optgroup>
                      </select>
                    </div>
                    <fieldset>
                      <legend><small>Total</small></legend>
                      <h4 style="float: right;" id="billtotal">0 </h4>

                    </fieldset>

                  </div>

                  <!-- bill no here -->
                  <input type="hidden" name="bill_no" id="bill_no" value="<?php echo $current_bill ?>">

                  <div class="row m-5 mb-0" id="datafromback">



                    <div class="col-lg-3">
                      <label class="form-label" id="">Product Name</label>
                      <select class="form-select" onchange="get_old_price(),get_batch()" id="pname" name="pname">
                        <optgroup label="Select Product">
                          <?php
                          $sql = "SELECT * FROM product ";
                          $result = $conn->query($sql);
                          if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                          ?>
                              <option value="<?php echo $row['product_name'] . "," . $row['id'] ?>"><?php echo $row['product_name'] ?></option>
                          <?php

                            }
                          }
                          ?>
                        </optgroup>
                      </select>
                    </div>

                    <!-- get batch name -->
                    <div class="col-lg-3">
                      <label class="form-label" id="">Batch #</label>
                      <select class="form-select" onchange="get_old_price()" id="batchno" name="batchno">
                        <optgroup label="Select Product">
                          <?php
                          $sql = "SELECT * FROM product ";
                          $result = $conn->query($sql);
                          if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                          ?>
                              <option value="<?php echo $row['batchno'] ?>">
                                <?php echo $row['batchno'] ?>
                              </option>
                          <?php

                            }
                          }
                          ?>
                        </optgroup>
                      </select>
                    </div>

                    <div class="col-lg-3">
                      <label class="form-label" id="">Quantity</label>
                      <input class="form-control" onkeyup="mulqtyprice()" min="1" pattern="[1-9][0-9]*" type="number" value="1" name="pqty" id="pqty">

                    </div>


                    <div class="col-lg-3">
                      <label class="form-label" id="">Price</label>
                      <input class="form-control" min="0" onkeyup="mulqtyprice()" pattern="[1-9][0-9]*" type="number" name="pprice" id="pprice">

                    </div>



                  </div>

                  <div class="row" style="margin: 0 3rem 0 3rem;" id="old_pprice">



                    <div class="col-lg-3 ">
                      <!-- <label for="">This is product</label> -->
                    </div>
                    <div class="col-lg-3  text-danger">
                      <label for="">???</label>
                    </div>
                    <div class="col-lg-3  text-danger">
                      <label for="">???</label>
                    </div>
                    <div class="col-lg-3 text-danger">
                      <label for="">???</label>
                    </div>

                  </div>

                  <div class="row" style="margin-left: 3rem;margin-right:3rem">
                    <div class="col-lg-3"></div>
                    <div class="col-lg-3"></div>
                    <div class="col-lg-3"></div>
                    <div class="col-lg-3">
                      <label class="form-label" id="">Sub Total</label>
                      <input type="number" readonly class="form-control" id="subtotal" name="subtotal" value="">
                    </div>
                  </div>






                  <div class="row m-5 ">
                    <div class="form-action-buttons col-lg-12">
                      <label class="form-label"></label>
                      <a id="cus_form" onclick="add_bill_items()" style="float: right;" class="btn btn-primary" style="width: 200px;">Add</a>
                    </div>
                  </div>

                </div>

              </div>
            </div>
          </div>
          <!-- here the table -->
          <table class='table table-striped' style="margin-top: 3rem;">
            <thead class="">
              <tr>
                <!-- <th>Customer Name</th> -->
                <th>Product Name</th>
                <th>Price</th>
                <th>Quantity</th>
                <th>Sub-Total</th>
                <th>Action</th>
              </tr>
            </thead>


            <tbody id="data_reload">
              <?php

              $sql1 = "SELECT * FROM `items` WHERE `bill_id` = " . $current_bill;
              $result1 = $conn->query($sql1);

              if ($result1->num_rows > 0) {
                while ($row = $result1->fetch_assoc()) {
                  $total += floatval($row["total"]);

              ?>

                  <tr>
                    <!-- <td><?php //echo $row["supplier"] 
                              ?></td> -->
                    <td><?php echo $row["item_name"] ?></td>
                    <td><?php echo $row["price"] ?></td>
                    <td><?php echo $row["quantity"] ?></td>
                    <td><?php echo $row["total"] ?></td>
                    <td>
                      <a href="ed_itp.php?id=<?php echo $row['id'] . "&name=" . preg_replace("/\s+/", "", $row['item_name']) . "&price=" . $row['price'] . "&qty=" . $row['quantity'] . "&bill_no=" . $row['bill_id'] ?>" class="btn btn-primary">
                        <i class="fas fa-pen"></i>
                      </a>
                      <a href="del_itp.php?id=<?php echo $row['id'] . "&bill_no=" . $row['bill_id'] . "&name=" . $row["item_name"] . "&qty=" . $row["quantity"] ?>" class="btn btn-danger">
                        <i class="fas fa-trash"></i>
                      </a>

                    </td>
                  </tr>
              <?php
                }
              }
              ?>
              <tr>
                <!-- <td>------</td> -->
                <td>------</td>
                <td>------</td>
                <td>------</td>
                <td><?php echo $total ?></td>
                <td>------</td>
              </tr>
              <input type="hidden" value="<?php echo $total ?>" id="sub2" name="sub2">
            </tbody>

          </table>


          <div class="row" style="margin-left: 3rem;margin-right:3rem">
            <div class="col-lg-3">
              <label class="form-label" id="">Discount %</label>
              &nbsp;&nbsp;
              <!-- old discount -->
              <span class="text-danger fw-bold">Old</span>
              <label id="old_disc" class="text-danger fw-bold">??? </label><span class="text-danger fw-bold">%</span>
              <input class="form-control" min="0" pattern="[1-9][0-9]*" onkeyup="makediscount()" type="number" name="discount" id="discount">
            </div>
            <div class="col-lg-3">
              <label class="form-label" id="">GST Tax</label>
              <input class="form-control" min="0" pattern="[1-9][0-9]*" onkeyup="addTax()" type="number" name="gst" id="gst">

            </div>
            <div class="col-lg-3">
              <label class="form-label" id="">Discount Total</label>
              <input class="form-control" min="0" readonly pattern="[1-9][0-9]*" type="number" name="distotal" id="distotal">

            </div>
            <div class="col-lg-3">
              <label class="form-label" id="">Grand Total</label>
              <input class="form-control" min="0" readonly pattern="[1-9][0-9]*" type="number" name="grandtotal" id="grandtotal">

            </div>


          </div>

          <div class="row " style="margin-left: 3rem;margin-right:3rem">
            <div class="col-lg-3">
              <label class="form-label" id="">Status</label>
              <select class="form-control mx-auto" name="status" id="status_id" required="">

                <option value="paid">Paid</option>
                <option value="unpaid">UnPaid</option>

              </select>
            </div>
            <div class="col-lg-3">
              <label class="form-label" id="">Payment</label>
              <input class="form-control" min="0" pattern="[1-9][0-9]*" type="number" name="paid" id="paid" placeholder="Amount">
            </div>
            <div class="col-lg-3">
              <label class="form-label" id="">Bill Maker</label>
              <input class="form-control" value=" <?php echo $_SESSION['username'] ?> " readonly type="text" name="salesman" id="salesman" placeholder="SalesMan">

            </div>
            <div class="col-lg-3">
              <input type="submit" name="submit" value="Submit" class="btn btn-success" style="float: right;margin-top:2rem">
              <!-- <input type="submit" onclick="return confirm('Are You Sure! Press Ok To Return Sale')" name="return" value="Sale Return" class="btn btn-danger" style="float: right;margin-top:2rem"> -->

            </div>


          </div>
        </form>

      </div>

    </section>
  </div>
</div>

<?php
include_once "footer.php";

?>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/jautocalc@1.3.1/dist/jautocalc.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.repeater/1.2.1/jquery.repeater.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.repeater/1.2.1/jquery.repeater.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert-dev.js"></script>

<script src="js_by_GENOS_1.js"></script>
<script>

function get_batch(){
    product = $('#pname').find(":selected").val();
    // price = $('#pprice').val();
    qty = $('#pqty').val();
    $.ajax({
      url: "get_batch.php",
      type: "POST",
      data: {
        name: product,
        qty: qty,
      },
      success: function(data) {
        $("#datafromback").html(data);
        mulqtyprice();
      }
    });
  }
  function get_old_disc() {
    let name = $("#cus_name").val();

    $.ajax({
      url: "get_oldp_disc.php",
      type: "POST",
      data: {
        name: name
      },
      success: function(data) {
        $("#old_disc").text(data);
      }
    });

  }

  function get_old_price() {
    let name = $("#cus_name").val();
    let pname = $("#pname").val();

    $.ajax({
      url: "get_oldp_price.php",
      type: "POST",
      data: {
        name: name,
        pname: pname
      },
      success: function(data) {
        $("#old_pprice").html(data);
        // console.log(data);
      }
    });

  }
  get_batch();
  get_old_disc();
  get_old_price();
</script>