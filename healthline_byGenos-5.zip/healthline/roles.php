<?php
define("TITLE", "Roles");
define("PAGE", "Roles");
include 'connection.php';
include 'header.php';


?>


<div class="body-section">
    <div class="container">
        <div class="card">
            <div class="card-header border-0">
                <h3 class="card-title">Roles</h3>
                <hr>
                <div class="container mt-1">
                    <!-- Button trigger modal -->
                    <div class="row">
                        <div class="col-lg-9">
                        </div>
                        <div class="col-lg-3">


                            <button type="button" id="button-addon2" data-bs-toggle="modal" data-bs-target="#exampleModal" class="btn btn-lg float-right mb-3">
                                <i class="fas fa-plus"></i> Add Role
                            </button>
                            <!--Modal-->
                            <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header bg-light">
                                            <h4 class="modal-title " id="exampleModalLabel">Role Detail</h4>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                            <form method="POST">





                                                <table>
                                                    <tr>
                                                        <td>
                                                            <div class="form-group">
                                                                <label class="form-label">Role Name</label>
                                                                <input type="text" class="form-control" placeholder="Role Name" name="rname">
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <label class="form-label mt-2">Permissions</label>
                                                        </td>

                                                    </tr>

                                                    <tr>
                                                        <td>

                                                            <div class="form-check mt-2">

                                                                <input class="form-check-input" type="checkbox" name="category">
                                                                <label class="form-check-label">
                                                                    Category
                                                                </label>
                                                            </div>
                                                        </td>

                                                        <td>
                                                            <div class="form-check mt-2">
                                                                <input class="form-check-input" type="checkbox" name="subcategory">
                                                                <label class="form-check-label">
                                                                    Sub Category
                                                                </label>
                                                            </div>
                                                        </td>

                                                    </tr>

                                                    <tr>
                                                        <td>

                                                            <div class="form-check mt-2">

                                                                <input class="form-check-input" type="checkbox" name="sale">
                                                                <label class="form-check-label">
                                                                    Sale
                                                                </label>
                                                            </div>
                                                        </td>

                                                        <td>
                                                            <div class="form-check mt-2">
                                                                <input class="form-check-input" type="checkbox" name="purchase">
                                                                <label class="form-check-label">
                                                                    Purchase
                                                                </label>
                                                            </div>
                                                        </td>

                                                    </tr>
                                                    <tr>
                                                        <td>

                                                            <div class="form-check mt-2">

                                                                <input class="form-check-input" type="checkbox" name="usermanagement">
                                                                <label class="form-check-label">
                                                                    User Menufecturer
                                                                </label>
                                                            </div>
                                                        </td>

                                                        <td>
                                                            <div class="form-check mt-2">
                                                                <input class="form-check-input" type="checkbox" name="stock">
                                                                <label class="form-check-label">
                                                                    Stock
                                                                </label>
                                                            </div>
                                                        </td>

                                                    </tr>

                                                    <tr>
                                                        <td>

                                                            <div class="form-check mt-2">

                                                                <input class="form-check-input" type="checkbox" name="dashboard">
                                                                <label class="form-check-label">
                                                                    Dashboard
                                                                </label>
                                                            </div>
                                                        </td>

                                                        <td>
                                                            <div class="form-check mt-2">
                                                                <input class="form-check-input" type="checkbox" name="report">
                                                                <label class="form-check-label">
                                                                    Reports
                                                                </label>
                                                            </div>
                                                        </td>

                                                    </tr>
                                                    <tr>
                                                        <td>

                                                            <div class="form-check mt-2">

                                                                <input class="form-check-input" type="checkbox" name="supplier">
                                                                <label class="form-check-label">
                                                                    Supplier
                                                                </label>
                                                            </div>
                                                        </td>

                                                        <td>
                                                            <div class="form-check mt-2">
                                                                <input class="form-check-input" type="checkbox" name="customer">
                                                                <label class="form-check-label">
                                                                    Customer
                                                                </label>
                                                            </div>
                                                        </td>

                                                    </tr>
                                                    <tr>
                                                        <td>

                                                            <div class="form-check mt-2">

                                                                <input class="form-check-input" type="checkbox" name="projection">
                                                                <label class="form-check-label">
                                                                    Projection
                                                                </label>
                                                            </div>
                                                        </td>

                                                        <td>
                                                            <div class="form-check mt-2">
                                                                <input class="form-check-input" type="checkbox" name="product">
                                                                <label class="form-check-label">
                                                                    Product
                                                                </label>
                                                            </div>
                                                        </td>

                                                    </tr>
                                                </table>



                                                <div class="modal-footer">
                                                    <button type="submit" class="btn" id="button-addon2" name="add">Add</button>
                                                </div>
                                            </form>
                                        </div>

                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>


                    <div class="card-body table-responsive p-0">
                        <div class="row">
                            <div class="col-lg-12">
                                <table id="table" class="table pt-2">

                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Role Name</th>
                                            <th>Operations</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                        <?php
                                        $result = $conn->query("SELECT * FROM `roles`");
                                        while ($row = $result->fetch_assoc()) {
                                        ?>
                                            <tr>
                                                <td><?php echo $row['id'] ?></td>
                                                <td><?php echo $row['role_name'] ?></td>

                                                <td>
                                                    <button type="button" class="btn btn-success btn-sm editbtn"><i class="fas fa-edit"></i></button>
                                                    <input type="hidden" class="delete_id_value" value="<?php echo $row['id']; ?>">
                                                    <a href="javascript:void(0)" type="button" class="delete_btn_ajax btn btn-sm btn-danger"><i class="fas fa-trash"></i></a>
                                                </td>
                                            </tr>

                                        <?php
                                        }

                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>


                    </div>
                </div>




            </div>
            <!-- flex-item -->
        </div>
        <!-- /flex-container -->
    </div>
</div>
<!-- flex-item -->
</div>
<!-- /flex-container -->
</div>
</div>

<!-- ============================================================== -->
<!-- End Container fluid  -->
<!-- ============================================================== -->
</div>
<!-- ============================================================== -->
<!-- End Page wrapper  -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- footer -->
<!-- ============================================================== -->
<!--  <footer class="footer fixed">
            © 2020 Elegent Admin by <a href="https://www.wrappixel.com/">wrappixel.com</a>
        </footer> -->
<!-- ============================================================== -->
<!-- End footer -->
<!-- ============================================================== -->
</div>
<!-- ============================================================== -->
<!-- End Wrapper -->
<!-- ============================================================== -->
<!-- ============================================================== -->


<!-- Edit Modal -->
<div class="modal fade" id="myModalEdit" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Permission</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form method="POST">
                    <input type="hidden" name="update_id" id="update_id">


                    <?php
                    // $srolen = $valid_user['role_name'];
                    // $edit = mysqli_query($conn, "select * from roles where role_name='$srolen' limit 1");
                    // while ($rows = mysqli_fetch_assoc($edit)) {
                    ?>
                        <table>
                            <tr>
                                <td>
                                    <div class="form-group">
                                        <label class="form-label">Role Name</label>
                                        <input type="text" class="form-control" placeholder="Role Name" id="name" name="name">
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <label class="form-label mt-2">Permissions</label>
                                </td>

                            </tr>

                            <tr>
                                <td>

                                    <div class="form-check mt-2">

                                        <input class="form-check-input" type="checkbox" name="category" >
                                        <label class="form-check-label">
                                            Category
                                        </label>
                                    </div>
                                </td>

                                <td>
                                    <div class="form-check mt-2">
                                        <input class="form-check-input" type="checkbox" name="subcategory">
                                        <label class="form-check-label">
                                            Sub Category
                                        </label>
                                    </div>
                                </td>

                            </tr>

                            <tr>
                                <td>

                                    <div class="form-check mt-2">

                                        <input class="form-check-input" type="checkbox" name="sale">
                                        <label class="form-check-label">
                                            Sale
                                        </label>
                                    </div>
                                </td>

                                <td>
                                    <div class="form-check mt-2">
                                        <input class="form-check-input" type="checkbox" name="purchase">
                                        <label class="form-check-label">
                                            Purchase
                                        </label>
                                    </div>
                                </td>

                            </tr>
                            <tr>
                                <td>

                                    <div class="form-check mt-2">

                                        <input class="form-check-input" type="checkbox" name="usermanagement">
                                        <label class="form-check-label">
                                            User Menufecturer
                                        </label>
                                    </div>
                                </td>

                                <td>
                                    <div class="form-check mt-2">
                                        <input class="form-check-input" type="checkbox" name="stock">
                                        <label class="form-check-label">
                                            Stock
                                        </label>
                                    </div>
                                </td>

                            </tr>

                            <tr>
                                <td>

                                    <div class="form-check mt-2">

                                        <input class="form-check-input" type="checkbox" name="dashboard">
                                        <label class="form-check-label">
                                            Dashboard
                                        </label>
                                    </div>
                                </td>

                                <td>
                                    <div class="form-check mt-2">
                                        <input class="form-check-input" type="checkbox" name="report">
                                        <label class="form-check-label">
                                            Reports
                                        </label>
                                    </div>
                                </td>

                            </tr>
                            <tr>
                                <td>

                                    <div class="form-check mt-2">

                                        <input class="form-check-input" type="checkbox" name="supplier">
                                        <label class="form-check-label">
                                            Supplier
                                        </label>
                                    </div>
                                </td>

                                <td>
                                    <div class="form-check mt-2">
                                        <input class="form-check-input" type="checkbox" name="customer">
                                        <label class="form-check-label">
                                            Customer
                                        </label>
                                    </div>
                                </td>

                            </tr>
                            <tr>
                                <td>

                                    <div class="form-check mt-2">

                                        <input class="form-check-input" type="checkbox" name="projection">
                                        <label class="form-check-label">
                                            Projection
                                        </label>
                                    </div>
                                </td>

                                <td>
                                    <div class="form-check mt-2">
                                        <input class="form-check-input" type="checkbox" name="product">
                                        <label class="form-check-label">
                                            Product
                                        </label>
                                    </div>
                                </td>

                            </tr>
                        </table>
                    <?php
                    // }
                    ?>


                    <button type="submit" class="btn btn-success mt-2 float-end" name="edit">Edit</button>
                </form>
            </div>

        </div>
    </div>
</div>
<!-- Edit Modal END -->
<!--delete-->
<script>
    $(document).ready(function() {
        $(".delete_btn_ajax").click(function(e) {
            e.preventDefault();
            var deleteid = $(this).closest('tr').find('.delete_id_value').val();
            // alert(deleteid);
            swal({
                    title: "Are you sure?",
                    text: "Once deleted, you will not be able to recover this Data!",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                })
                .then((willDelete) => {
                    if (willDelete) {
                        $.ajax({
                            type: "POST",
                            url: "deletecategory.php",
                            data: {
                                "delete_btn_set": 1,
                                "deleteid": deleteid,
                            },
                            success: function(response) {
                                swal("Deleted!", "Your Data is Deleted", "success", {
                                    button: "Ok!",
                                }).then((result) => {
                                    location.reload();
                                });

                            }
                        });
                    }
                });

        });
    });
</script>





</div>







<script>
    // $('.editbtn').on('click', function() {
    //     $('#myModalEdit').modal('show');
    // });
    $(document).ready(function() {
        $('.editbtn').on('click', function() {
            $('#myModalEdit').modal('show');

            $tr = $(this).closest('tr');

            var data = $tr.children('td').map(function() {
                return $(this).text();
            }).get();

            console.log(data);
            $('#update_id').val(data[0]);
            $('#name').val(data[1]);

            // $('#status').val(data[2]);
        });
    });
</script>




<?php


include 'footer.php';

if (isset($_POST['add'])) {
    $name = $_POST['rname'];
    $category = isset($_POST['category']);
    $subcategory = isset($_POST['subcategory']);
    // $unit = isset($_POST['unit']);
    $product = isset($_POST['product']);
    $sale = isset($_POST['sale']);
    $purchase = isset($_POST['purchase']);
    $usermanagement = isset($_POST['usermanagement']);
    $stock = isset($_POST['stock']);
    $dashboard = isset($_POST['dashboard']);
    $report = isset($_POST['report']);
    $supplier = isset($_POST['supplier']);
    $customer = isset($_POST['customer']);
    $projection = isset($_POST['projection']);

    // foreach ($permission as $list) {
    $result = mysqli_query($conn, "INSERT INTO `roles` (`id`, `role_name`, `category`, `subcategory`, `product`, `sale`, `purchase`, `user_management`, `stock`, `dashboard`, `report`, `supplier`, `customer`,`projection`,`status`) 
        VALUES (NULL, '$name', '$category', '$subcategory', '$product', '$sale', '$purchase', '$usermanagement', '$stock', '$dashboard', '$report', '$supplier', '$customer','$projection', 'active')");

    $result_name = mysqli_query($conn, "insert into rolesname (role_name) values('$name')");
    if ($result) {
?>
        <script>
            window.location = "<?php echo $app_url . '/roles.php' ?>";
        </script>

    <?php
    }
    // }
}


//edit
if (isset($_POST['edit'])) {
    $id = $_POST['update_id'];
    $name = $_POST['name'];
    $category = isset($_POST['category']);
    $subcategory = isset($_POST['subcategory']);
    // $unit = isset($_POST['unit']);
    $product = isset($_POST['product']);
    $sale = isset($_POST['sale']);
    $purchase = isset($_POST['purchase']);
    $usermanagement = isset($_POST['usermanagement']);
    $stock = isset($_POST['stock']);
    $dashboard = isset($_POST['dashboard']);
    $report = isset($_POST['report']);
    $supplier = isset($_POST['supplier']);
    $customer = isset($_POST['customer']);
    $projection = isset($_POST['projection']);

    $updatequery = "UPDATE `roles` SET `role_name` = '$name', `category` = '$category', `subcategory` = '$subcategory', `product` = '$product', `sale` = '$sale', `purchase` = '$purchase', `stock` = '$stock', `dashboard` = '$dashboard', `report` = '$report', `supplier` = '$supplier', `customer` = '$customer', `projection` = '$projection' WHERE `roles`.`id` ='$id'";
    $uquery = mysqli_query($conn, $updatequery);
    if ($uquery) {
    ?>
        <script>
            window.location = "<?php echo $app_url . '/roles.php' ?>";
        </script>

    <?php
    } else {
    ?>
        <script>
            alert('Update Failed');
        </script>

<?php
    }
}

?>