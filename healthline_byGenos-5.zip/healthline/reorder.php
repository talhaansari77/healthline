<?php 
define("TITLE","Stock");
define("PAGE","Stock");
include 'connection.php';
include 'header.php';

?>


<div class="body-section">
<div class="container">
         <div class="card">
              <div class="card-header border-0">
                <h3 class="card-title">Re-Order Level</h3>
                <hr>
      <div class="container mt-1">
              <!-- Button trigger modal -->
              <div class="row mb-3">
                  <div class="col-lg-9">
                    <div class="input-group ">
  
                    </div>
                  </div>
                  
        </div>

  
              <div class="card-body table-responsive">
                  <div class="row">
                  <div class="col-lg-12">
                <table id="table" class="table table-striped pt-3">
                  
                  <thead class="table-dark">
                     <tr>
                          <th>#</th>
                          <th>Name</th>
                          <th>Re-Order Level</th>
                          
                                                
                     </tr>
                         </thead>
                           <tbody>
                              <?php
                                $query=mysqli_query($conn,"select * from product order by product_name ASC");
                               while($row = $query->fetch_assoc()){

                               
                                  ?>  
                               <tr>
                                  <td><?php echo $row["id"] ?></td>
                                  <td><?php echo $row["product_name"] ?></td>
                                  <td><?php echo $row["reorder_lvl"] ?></td>
                                </tr>
                                  <?php  }?>               
                            </tbody>
                </table>
                </div>
                </div>


               
              </div>
            </div>
            



            </div>
            <!-- flex-item -->
        </div>
        <!-- /flex-container -->
    </div>
            </div>
            <!-- flex-item -->
        </div>
        <!-- /flex-container -->
    </div>
</div>
               
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- footer -->
        <!-- ============================================================== -->
       <!--  <footer class="footer fixed">
            © 2020 Elegent Admin by <a href="https://www.wrappixel.com/">wrappixel.com</a>
        </footer> -->
        <!-- ============================================================== -->
        <!-- End footer -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <div class="modal fade" id="myModalEdit" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Edit Stock</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <div class="container">

                                   
<form  method="POST">
<input type="hidden" name="update_id" id="update_id" />
<div class="form-group">
<label class="form-label" for="pname">Stock Name</label>
<input type="text" class="form-control" placeholder="Stock Name" name="pname" id="pname">
</div>
<div class="form-group">
<label class="form-label" for="cat">Category</label>
<select name="cat" class="form-select" id="cat">
<option disabled>Select Category</option>

            </select>
</div>
<div class="form-group">
    <label class="form-label" for="unit">Unit</label>
    <select name="unit" class="form-select" id="unit">
            <option disabled>Select Unit</option>
          
            </select>
</div>

                        
    
</form>
</div>
        
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn " id="button-addon2">Edit</button>
      </div>
    </div>
  </div>
</div>

        <!--delete-->
<div class="modal fade" id="myModalDelete" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Delete Supplier</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <div class="container">

      <p>Are you sure want to delete the record?</p>
                <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
        <button type="button" class="btn " id="button-addon2">Yes</button>
      </div>
            </form>
</div>
        
      </div>
     
    </div>
  </div>
</div>





    </div>






<?php 


include 'footer.php';

?>