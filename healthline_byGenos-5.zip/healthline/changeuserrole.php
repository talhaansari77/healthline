<?php 
include_once "connection.php";

$data = $_POST["rolid"];
$role = explode(",", $data)[0];
$id = explode(",", $data)[1];


$conn->query("UPDATE `login` SET `role`= '$role' WHERE `id`='$id'");





?>