<?php 
include_once "connection.php" ;
$filter_name = "";
if(isset($_GET["catgories"])){
    $catgories = $_GET["catgories"];
    $filter_name = $_GET["catgories"];
    $result = $conn->query("SELECT * FROM `product` WHERE `catgories`= '$catgories'");

}
if(isset($_GET["subcategories"])){
    $subcategories = $_GET["subcategories"];
    $filter_name = $_GET["subcategories"];
    $result = $conn->query("SELECT * FROM `product` WHERE `subcategories`= '$subcategories'");

}
if(isset($_GET["manufacturer"])){
    $manufacturer = $_GET["manufacturer"];
    $filter_name = $_GET["manufacturer"];
    $result = $conn->query("SELECT * FROM `product` WHERE `manufacturer`= '$manufacturer'");

}
?>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Details</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
</head>

<body>


    <table class="table ">
        <tr>
            <th>
                <h1>
                    <center>Health Line : Pharmacy</center>
                </h1>
            </th>
        </tr>
        <tr>
            <th>
                <center>
                Product Details :<?php echo $filter_name?>
                </center>
            </th>
        </tr>
        


    </table>
    <table class="table table-bordered">
        <tr>
            <!-- <td></td> -->
            <th>No#</th>
            <th>Name</th>
            <th>Quantity</th>
        </tr>
        <?php
       

        while ($row = $result->fetch_assoc()) {
        ?>
            <tr>
                <td> <?php echo $row["id"] ?> </td>
                <td> <?php echo $row["product_name"] ?> </td>
                <td> <?php echo $row["opening_stock"] ?> </td>
           

            </tr>
        <?php
        }
        ?>

    </table>
    
</body>

</html>

<script>
    // window.print();
</script>